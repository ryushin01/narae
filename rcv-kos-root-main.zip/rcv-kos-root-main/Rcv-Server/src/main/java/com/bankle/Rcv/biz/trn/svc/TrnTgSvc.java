package com.bankle.Rcv.biz.trn.svc;

import com.bankle.Rcv.biz.trn.vo.TrnTgSvo;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.wooriApi.socket.ins.commonSvc.InsCmnSvc;
import com.bankle.common.wooriApi.socket.ins.commonSvc.vo.InsCmnSvo;
import com.bankle.common.wooriApi.socket.ins.recSvc.Rec6200F2Svc;
import com.bankle.common.wooriApi.socket.ins.recSvc.Rec6200W2Svc;
import com.bankle.common.wooriApi.socket.ins.recSvc.vo.Rec6200F2Svo;
import com.bankle.common.wooriApi.socket.ins.recSvc.vo.Rec6200W2Svo;
import com.bankle.common.wooriApi.socket.ins.socketData.*;
import com.bankle.common.wooriApi.socket.woori.commonSvc.WooriCmnSvc;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.WooriCmnSvo;
import com.bankle.common.wooriApi.socket.woori.recSvc.*;
import com.bankle.common.wooriApi.socket.woori.recSvc.vo.*;
import com.bankle.common.wooriApi.socket.woori.socketData.*;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;


@Slf4j
@Service
@RequiredArgsConstructor
public class TrnTgSvc {

    private final String DB_TG_DSC = "W1000,W2000,W3000";
    private final String FA_TG_DSC = "F1000,F2000,F3000,F5000";
    private final String STD_TG_DSC = "A100,A200,A300,A410,A500,A600,A710,A800,A900,B100,B200,B300,B400,B500,B600,B710,B800,Q110,Q210";
    private final int DB_STD_HEADER_LEN = 104;
    private final WooriCmnSvc wooriCmnSvc;
    private final RecA100Svc recA100Svc;
    private final RecB200Svc recB200Svc;
    private final RecB600Svc recB600Svc;
    private final RecA200Svc recA200Svc;
    private final RecA300Svc recA300Svc;
    private final RecB400Svc recB400Svc;
    private final RecA800Svc recA800Svc;
    private final Rec6200F2Svc rec6200F2Svc;
    private final Rec6200W2Svc rec6200W2Svc;

    @Transactional
    public Map<String, Object> setDataFaStd(HttpServletRequest httpServletRequest) {

        log.debug("====================================================================================================");
        log.debug(">>> setData FA FA Start !!!");
        log.debug("====================================================================================================");
        String TG_DSC_FA = ""; // 전문 구분
        String STD_YN = "N";
        Map<String, Object> rsltMap = new HashMap<String, Object>();
        int len = httpServletRequest.getContentLength();
        if (len > 24) {  // Polling 전문 제외
            try {
                //------------------------------------------------
                // 초기 설정 및 전문 구분 코드 변환
                //------------------------------------------------
                InputStream input = null;
                InputStream is = httpServletRequest.getInputStream();
                byte[] data = new byte[len];
                is.read(data, 0, len);
                String strReqData = new String(data, "MS949");
                String TG_DSC = strReqData.substring(4, 8);
                TG_DSC_FA = TG_DSC;
                //------------------------------------------------
                // 전문 오류 및 표준화 여부 확인
                //------------------------------------------------
                if (!FA_TG_DSC.contains(TG_DSC_FA)) {
                    if (!STD_TG_DSC.contains(TG_DSC_FA)) {
                        STD_YN = "X";
                        log.error("표준화여부 [" + STD_YN + "]   보험사 [" + "FA" + "]   전문구분 [" + TG_DSC_FA + "]\n전문내용 [" + strReqData + "]");
                    } else {
                        STD_YN = "Y";
                        log.debug("표준화여부 [" + STD_YN + "]   보험사 [" + "FA" + "]   전문구분 [" + TG_DSC_FA + "]\n전문내용 [" + strReqData + "]");
                    }  // 표준화 전문
                }
                //------------------------------------------------
                // 수신전문 저장
                //------------------------------------------------
                if (!"X".equals(STD_YN)) {
                    log.debug("수신전문 저장 시작!!!!!!!!!!");
                    input = new ByteArrayInputStream(data);
                    TrnTgSvo.TrnRcvTgInVo trnRcvTgInVo = new TrnTgSvo.TrnRcvTgInVo();
                    trnRcvTgInVo.setTgDsc(TG_DSC_FA);
                    trnRcvTgInVo.setStdYn(STD_YN);
                    trnRcvTgInVo.setInputStream(input);
                    trnRcvTgInVo.setInsGbn("FA");
                    this.receiveTg(trnRcvTgInVo);
                    rsltMap.put("message", "success");
                } else {
                    rsltMap.put("message", "fail");
                }
            } catch (Exception Ex) {
                Ex.printStackTrace();
                rsltMap.put("Message", "fail");
            }
        }
        log.debug("====================================================================================================");
        log.debug(">>> setData FA STD End !!!");
        log.debug("====================================================================================================");
        return rsltMap;
    }

    @Transactional
    public Map<String, Object> setDataFaAsk(HttpServletRequest httpServletRequest) {

            log.debug("====================================================================================================");
            log.debug(">>> setData FA Start !!!");
            log.debug("====================================================================================================");
            Map<String, Object> rsltMap = new HashMap<String, Object>();
            int len = httpServletRequest.getContentLength();
            if (len > 24) {  // Polling 전문 제외
                try {
                    //------------------------------------------------
                    // 초기 설정
                    //------------------------------------------------
                    InputStream input = null;
                    String TG_DSC_FA = ""; // 전문 구분
                    String STD_YN = "N";   // 표준화 전문 여부
                    InputStream is = httpServletRequest.getInputStream();
                    byte[] data = new byte[len];
                    is.read(data, 0, len);
                    log.debug("setDataFa data > " + data.toString());
                    String strReqData = new String(data, "MS949");
                    //------------------------------------------------
                    // 전문 구분 코드 변환
                    //------------------------------------------------
                    String TG_DSC = strReqData.substring(4, 8);
                    if ("6110".equals(TG_DSC)) {
                        TG_DSC_FA = "F1000";
                    } else if ("6200".equals(TG_DSC)) {
                        TG_DSC_FA = "F2000";
                    } else if ("6310".equals(TG_DSC)) {
                        TG_DSC_FA = "F3000";
                    } else if ("6510".equals(TG_DSC)) {
                        TG_DSC_FA = "F5000";
                    } else {
                        TG_DSC_FA = TG_DSC;
                    }
                    log.debug("====>  TG_DSC [" + TG_DSC + "]   FA_TG_DSC [" + FA_TG_DSC + "]   Check Value [" + FA_TG_DSC.indexOf(TG_DSC) + "]");
                    //------------------------------------------------
                    // 전문 오류 및 표준화 여부 확인
                    //------------------------------------------------
                    if (!FA_TG_DSC.contains(TG_DSC_FA)) {
                        if (!STD_TG_DSC.contains(TG_DSC_FA)) {
                            STD_YN = "X";
                            log.error("표준화여부 [" + STD_YN + "]   보험사 [" + "FA" + "]   전문구분 [" + TG_DSC_FA + "]\n전문내용 [" + strReqData + "]");
                        } else {
                            STD_YN = "Y";
                            log.debug("표준화여부 [" + STD_YN + "]   보험사 [" + "FA" + "]   전문구분 [" + TG_DSC_FA + "]\n전문내용 [" + strReqData + "]");
                        }
                    }
                    //------------------------------------------------
                    // 수신전문 저장
                    //------------------------------------------------
                    if (!"X".equals(STD_YN)) {
                        log.debug("수신전문 저장 시작!!!!!!!!!!");
                        input = new ByteArrayInputStream(data);
                        TrnTgSvo.TrnRcvTgInVo trnRcvTgInVo = new TrnTgSvo.TrnRcvTgInVo();
                        trnRcvTgInVo.setInputStream(input);
                        trnRcvTgInVo.setStdYn(STD_YN);
                        trnRcvTgInVo.setTgDsc(TG_DSC_FA);
                        trnRcvTgInVo.setTrnLen(len);
                        trnRcvTgInVo.setInsGbn("FA");
                        receiveTg(trnRcvTgInVo);
                        rsltMap.put("message", "success");
                    } else {
                        rsltMap.put("message", "fail");
                    }
                } catch (Exception Ex) {
                    Ex.printStackTrace();
                    rsltMap.put("message", "fail");
                }
            }
            log.debug("====================================================================================================");
            log.debug(">>> setData FA End!!!");
            log.debug("====================================================================================================");
            return rsltMap;
    }

    @Transactional
    public Map<String, Object> setDataDb(HttpServletRequest httpServletRequest) {
        log.debug("====================================================================================================");
        log.debug(">>> setData DB Start !!!");
        log.debug("====================================================================================================");
        String TG_DSC_DB = ""; // 전문 구분
        String STD_YN = "N";
        Map<String, Object> rsltMap = new HashMap<String, Object>();
        int len = httpServletRequest.getContentLength();
        if (len > 24) {  // Polling 전문 제외
            try {
                //------------------------------------------------
                // 초기 설정
                //------------------------------------------------
                InputStream input = null;
                InputStream is = httpServletRequest.getInputStream();
                byte[] data = new byte[len];
                is.read(data, 0, len);
                String strReqData = new String(data, "MS949");
                //------------------------------------------------
                // 전문 구분 코드 변환
                //------------------------------------------------
                int lenByte = data.length;
                String TG_DSC = strReqData.substring(8, 13).trim();
                TG_DSC_DB = TG_DSC;

                //------------------------------------------------
                // 전문 오류 및 표준화 여부 확인
                //------------------------------------------------
                if (!DB_TG_DSC.contains(TG_DSC_DB)) {

                    if (!STD_TG_DSC.contains(TG_DSC_DB)) {
                        STD_YN = "X";
                        log.error("표준화여부 [" + STD_YN + "]   보험사 [" + "DB" + "]   전문구분 [" + TG_DSC_DB + "]\n전문내용 [" + strReqData + "]");
                    } else {
                        STD_YN = "Y";
                        log.debug("표준화여부 [" + STD_YN + "]   보험사 [" + "DB" + "]   전문구분 [" + TG_DSC_DB + "]\n전문내용 [" + strReqData + "]");
                    }  // 표준화 전문
                }

                if ("Y".equals(STD_YN)) {
                    byte[] dbStdData = new byte[lenByte - DB_STD_HEADER_LEN];
                    //String wooriTgNo = (new String(data, "MS949")).substring(49, 57) + "     ";  // 13 자리
                    String wooriTgNo = "0000000000000";
                    log.debug("=====>> wooriTgNo [" + wooriTgNo + "]");
                    byte[] byteWooriTgNo = wooriTgNo.getBytes("MS949");
                    log.debug("=====>> byteWooriTgNo size [" + byteWooriTgNo.length + "]");
                    System.arraycopy(data, DB_STD_HEADER_LEN, dbStdData, 0, dbStdData.length);
                    System.arraycopy(byteWooriTgNo, 0, dbStdData, 11, byteWooriTgNo.length);  // 우리은행 전문번호를 표준화공통헤더 LO_NO에 삽입
                    input = new ByteArrayInputStream(dbStdData);
                    //strReqData = new String(dbStdData, "MS949");
                } else {
                    input = new ByteArrayInputStream(data);
                    //strReqData = new String(data, "MS949");
                }

                //------------------------------------------------
                // 수신전문 저장
                //------------------------------------------------
                if (!"X".equals(STD_YN)) {
                    log.debug("수신전문 저장 시작!!!!!!!!!!");
                    TrnTgSvo.TrnRcvTgInVo trnRcvTgInVo = new TrnTgSvo.TrnRcvTgInVo();
                    trnRcvTgInVo.setTgDsc(TG_DSC_DB);
                    trnRcvTgInVo.setStdYn(STD_YN);
                    trnRcvTgInVo.setInputStream(input);
                    trnRcvTgInVo.setInsGbn("DB");
                    this.receiveTg(trnRcvTgInVo);
                    rsltMap.put("message", "success");
                } else {
                    rsltMap.put("message", "fail");
                }
            } catch (Exception Ex) {
                Ex.printStackTrace();
                rsltMap.put("Message", "fail");
            }
        }
        log.debug("====================================================================================================");
        log.debug(">>> setData DB End !!!");
        log.debug("====================================================================================================");
        return rsltMap;
    }

    @Transactional
    public void receiveTg(TrnTgSvo.TrnRcvTgInVo trnRcvTgInVo) throws Exception {
        log.debug("receiveTg(TrnTgSvo.trnTgInVo trnTgInVo) " + trnRcvTgInVo);

        if ("N".equals(trnRcvTgInVo.getStdYn())) {
            switch (trnRcvTgInVo.getTgDsc()) {
                case "F2000" -> {
                    T6200F2 t6200F2 = new T6200F2();
                    t6200F2.readDataStream(trnRcvTgInVo.getInputStream());
                    rec6200F2Svc.receive(Rec6200F2Svo.recInVo.builder()
                            .tgSqn(t6200F2.getKOS_TG_SND_NO().trim())
                            .t6200F2(t6200F2)
                            .loanNo(t6200F2.getLN_APRV_NO().substring(0,11).trim())
                            .build());

                }
                case "W2000" -> {
                    T6200W2 t6200W2 = new T6200W2();
                    t6200W2.readDataStream(trnRcvTgInVo.getInputStream());
                    InsCmnSvo.insCmnInVo insCmnInVo = new InsCmnSvo.insCmnInVo();
                    insCmnInVo.setTgSqn(t6200W2.getBNK_TG_NO());
                    insCmnInVo.setLoanNo(t6200W2.getLN_APRV_NO());
                    insCmnInVo.setTgDsc(t6200W2.getTG_DSC());
                    insCmnInVo.setTrDsc("100");
                    insCmnInVo.setBnkCd("020");
                    insCmnInVo.setReqDtm(LocalDateTime.now());
                    insCmnInVo.setReqTgCnts(t6200W2.dataToString());
                    insCmnInVo.setReqTgLog(t6200W2.print());
                    insCmnInVo.setReqTgFnYn("Y");
                    insCmnInVo.setResTgFnYn("N");
                    //insCmnSvc.insReceive(insCmnInVo);
                    rec6200W2Svc.receive(Rec6200W2Svo.recInVo.builder()
                            .tgSqn(t6200W2.getKOS_TG_NO().trim())
                            .t6200W2(t6200W2)
                            .loanNo(t6200W2.getLN_APRV_NO().substring(0,11).trim())
                            .build());
                }
            }
        } else {
            String tgDscPrefix = trnRcvTgInVo.getTgDsc().toString().substring(0, 2);
            String tgDsc = trnRcvTgInVo.getTgDsc();
            log.debug("표준 전문 SET DATA 시작");
            log.debug("tgDsc/tgDscPrefix: " + tgDscPrefix + "/" + tgDsc);
            switch (tgDscPrefix) {
                case "A1" -> {
                    A1X0 data = new A1X0();
                    data.readDataExternal(trnRcvTgInVo.getInputStream());
                    String trnName = "지급요청내역 등록/변경";
                    recA100Svc.receive(RecA100Svo.receiveVo.builder()
                            .trSeq(data.getTR_SQ())
                            .trnKnd(trnRcvTgInVo.getTgDsc())
                            .trnName(trnName)
                            .reqData(data.dataToString())
                            .reqDataLog(data.print())
                            .reqYn("Y")
                            .approvalNum(data.getAPPROVAL_NUM())
                            .reptMembNo(data.getLO_NO())
                            .loanNo(data.getAPPROVAL_NUM())
                            .membNo(data.getLO_NO())
                            .tgDsc(trnRcvTgInVo.getInsGbn())
                            .a1X0(data)
                            .build());
                }
                case "A2" -> {
                    A2X0 data = new A2X0();
                    data.readDataExternal(trnRcvTgInVo.getInputStream());
                    String trnName = "상환지급요청";

                    recA200Svc.receive(RecA200Svo.receiveVo.builder()
                            .trSeq(data.getTR_SQ())
                            .trnKnd(trnRcvTgInVo.getTgDsc())
                            .trnName(trnName)
                            .reqData(data.dataToString())
                            .reqDataLog(data.print())
                            .reqYn("Y")
                            .approvalNum(data.getAPPROVAL_NUM())
                            .reptMembNo(data.getLO_NO())
                            .loanNo(data.getAPPROVAL_NUM())
                            .membNo(data.getLO_NO())
                            .tgDsc(trnRcvTgInVo.getInsGbn())
                            .a2X0(data)
                            .build());

                }
                case "A3" -> {
                    A3X0 data = new A3X0();
                    data.readDataExternal(trnRcvTgInVo.getInputStream());
                    String trnName = "";
                    switch (data.getTR_TP().trim()) {
                        //case "01" -> trnName = "거래서류 완료 / 매도인(임대) 지급 요청";
                        case "02" -> trnName = "상환 영수증 전체 등록";
                        case "03" -> trnName = "등기신청번호 등록 완료";
                        case "04" -> trnName = "완료서류 BPR 등록";
                        case "10" -> trnName = "서비스완료 등록";
                       //case "11" -> trnName = "차주 지급 요청";
                        case "70" -> trnName = "이전등기 접수번호 통지";
                        case "71" -> trnName = "잔금처리 일시 통지";
                        case "72" -> trnName = "주민등록 초본";
                        case "73" -> trnName = "이전등기 필증 인증번호 등록 완료 통지";
                        case "74" -> trnName = "이전등기 신청 eForm 작성ID, 작성번호";
                        case "80" -> trnName = "영수증 등록 시간 초과 통지";
                        case "81" -> trnName = "접수번호 등록 시간 초과 통지";
                        //default -> trnName = "서류 전문 구분 코드 없음";
                    }
                    if (StringUtils.hasText(trnName)) {
                        recA300Svc.receive(RecA300Svo.receiveVo.builder()
                                .trSeq(data.getTR_SQ())
                                .trnKnd(trnRcvTgInVo.getTgDsc())
                                .trnName(trnName)
                                .reqData(data.dataToString())
                                .reqDataLog(data.print())
                                .reqYn("Y")
                                .approvalNum(data.getAPPROVAL_NUM())
                                .reptMembNo(data.getLO_NO())
                                .loanNo(data.getAPPROVAL_NUM())
                                .membNo(data.getLO_NO())
                                .tgDsc(trnRcvTgInVo.getInsGbn())
                                .gubun(data.getTR_TP().trim())
                                .a3X0(data)
                                .build());
                    }
                }
                case "A8" -> {
                    A8X0 data = new A8X0();
                    data.readDataExternal(trnRcvTgInVo.getInputStream());
                    String trnName = "";
                    switch (data.getPROC_DVSN().trim()) {
                        case "1" -> trnName = "이전등기 수임보고";
                        case "2" -> trnName = "담당자 등록";
                        case "3" -> trnName = "담당자 변경";
                        case "10" -> trnName = "매칭완료";
                        default -> trnName = "이전등기 처리 코드 없음";
                    }
                    recA800Svc.receive(RecA800Svo.receiveVo.builder()
                            .trSeq(data.getTR_SQ())
                            .trnKnd(trnRcvTgInVo.getTgDsc())
                            .trnName(trnName)
                            .reqData(data.dataToString())
                            .reqDataLog(data.print())
                            .reqYn("Y")
                            .approvalNum(data.getAPPROVAL_NUM())
                            .reptMembNo(data.getLO_NO())
                            .loanNo(data.getAPPROVAL_NUM())
                            .membNo(data.getLO_NO())
                            .tgDsc(trnRcvTgInVo.getInsGbn())
                            .gubun(data.getPROC_DVSN().trim())
                            .a8X0(data)
                            .build());
                }
                case "B2" -> {
                    B2X0 data = new B2X0();
                    data.readDataExternal(trnRcvTgInVo.getInputStream());
                    log.debug(data.print());
                    String trnName = "법무사 업무 할당 내역 요청";
                    recB200Svc.receive(RecB200Svo.receiveVo.builder()
                            .trSeq(data.getTR_SQ())
                            .trnKnd(trnRcvTgInVo.getTgDsc())
                            .trnName(trnName)
                            .reqData(data.dataToString())
                            .reqDataLog(data.print())
                            .reqYn("Y")
                            .approvalNum(data.getAPPROVAL_NUM())
                            .reptMembNo(data.getLO_NO())
                            .loanNo(data.getAPPROVAL_NUM())
                            .membNo(data.getLO_NO())
                            .tgDsc(trnRcvTgInVo.getInsGbn())
                            .gubun(data.getLEG_BANK_CODE_9())
                            .build());
                }
                case "B4" -> {
                    B4X0 data = new B4X0();
                    data.readDataExternal(trnRcvTgInVo.getInputStream());
                    String trnName = "이미지파일 서류 전송 정보";
                    switch (data.getTR_TP_CD().trim()) {
                        case "1" -> trnName = "이미지파일 서류전송";
                        case "2" -> trnName = "이미지파일 서류전송";
                        case "3" -> trnName = "이미지파일 서류전송";
                        case "4" -> trnName = "이미지파일 서류전송";
                        case "5" -> trnName = "이미지파일 서류전송";
                        case "6" -> trnName = "이미지파일 서류전송";
                        case "7" -> trnName = "이미지파일 서류전송";
                        case "8" -> trnName = "이미지파일 서류전송";
                        case "A" -> trnName = "이미지파일 서류전송";
                        case "B" -> trnName = "이미지파일 서류전송";
                        case "C" -> trnName = "이미지파일 서류전송";
                        case "E" -> trnName = "이미지파일 서류전송";
                        case "F" -> trnName = "이미지파일 서류전송";
                        case "G" -> trnName = "이미지파일 서류전송";
                    }
               recB400Svc.receive(RecB400Svo.receiveVo.builder()
                            .trSeq(data.getTR_SQ())
                            .trnKnd(trnRcvTgInVo.getTgDsc())
                            .trnName(trnName)
                            .reqData(data.dataToString())
                            .reqDataLog(data.print())
                            .reqYn("Y")
                            .approvalNum(data.getAPPROVAL_NUM())
                            .reptMembNo(data.getLO_NO())
                            .loanNo(data.getAPPROVAL_NUM())
                            .membNo(data.getLO_NO())
                            .tgDsc(trnRcvTgInVo.getInsGbn())
                            .gubun(data.getTR_TP_CD().trim())
                            .imgFileName(data.getIMG_FILE_NAME())
                            .b4X0(data)
                            .build());
                }
                case "B6" -> {
                    B6X0 data = new B6X0();
                    data.readDataExternal(trnRcvTgInVo.getInputStream());
                    String trnName = "등기접수번호 등록";
                    recB600Svc.receive(RecB600Svo.receiveVo.builder()
                            .trSeq(data.getTR_SQ())
                            .trnKnd(trnRcvTgInVo.getTgDsc())
                            .trnName(trnName)
                            .reqData(data.dataToString())
                            .reqDataLog(data.print())
                            .reqYn("Y")
                            .approvalNum(data.getAPPROVAL_NUM())
                            .reptMembNo(data.getLO_NO())
                            .loanNo(data.getAPPROVAL_NUM())
                            .membNo(data.getLO_NO())
                            .tgDsc(trnRcvTgInVo.getInsGbn())
                            .b6X0(data)
                            .build());
                }
            }
        }
    }
}
