package com.bankle.common.wooriApi.socket.woori.socketData;

import com.bankle.common.utils.CommUtil;
import com.bankle.common.utils.StringUtil;
import lombok.extern.slf4j.Slf4j;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

@Slf4j
public class GetSetData {

    private int             cntColumn = 0;	    // Layout Column Count
    String[]                arrName   = null;   // Layout Column Name
    int   []                arrLength = null;   // Layout Column Length
    String[]                arrType   = null;   // Layout Column Type
    HashMap<String, byte[]> mapTLGM   = null;   // 전문 Layout 내용
    HashMap<String, String> mapTYPE   = null;   // 전문 Layout 타입

	public String getData(byte[] byteArray) {
        try {
            if (byteArray == null) {
                return "";
            }
            //return CommUtil.rpad(new String(byteArray), byteArray.length, " ");
            return CommUtil.rpad(new String(byteArray, "MS949"), byteArray.length, "");
        } catch (Exception e) {
            log.error(e.getMessage());
            return "";
        }
    }

    /**
     * EUC-Kr --> JAVA String 객체(유니코드) --> UTF-8 로 변경
     * @param byteArray
     * @return
     * @throws UnsupportedEncodingException
     */
    public String getUTF8Data(byte[] byteArray) throws UnsupportedEncodingException {
        if (byteArray == null)
            return "";
        //EUC-KR ---> UTF8
        String str = new String(byteArray, "UTF-8");
        return CommUtil.rpad(str, byteArray.length, " ");
    }

    public String getMS949Data(byte[] byteArray) throws UnsupportedEncodingException {
        if (byteArray == null)
            return "";
        //UTF8 ---> MS949
        String str = new String(byteArray, "MS949").trim();
        return CommUtil.rpad(str, byteArray.length, " ");
    }

    public void setData (byte[] byteArray, String strValue, String type) {

        if (StringUtil.isEmpty(strValue)) strValue = " ";
        int    byteLen  = byteArray.length;
        byte[] bytes    = null;

        if ("K".equals(type)) {
            try {
                bytes = strValue.getBytes("MS949");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                bytes = strValue.getBytes();
            }
        } else {
            bytes = strValue.getBytes();
        }

        if (!"N".equals(type)) {

            // 실제데이터값의 바이트배열길이
            int endIdx = 0;

            // 실제데이터 바이트배열 설정
            if (byteLen < bytes.length) endIdx = byteLen;      // 실제데이터배열이 필드 배열보다 클경우
            else                        endIdx = bytes.length; // 필드의 배열이 실제데이터배열보다 작을 경우

            // 필드배열에 실제데이터배열값으로 채운다.
            for (int i = 0; i < endIdx; i++) {
                byteArray[i] = bytes[i];
            }

            // 실제데이터값이 채워지지 않은 배열은 공백으로 채운다.
            for (int j = endIdx; j < byteLen; j++) {
                byteArray[j] = ' ';
            }
        } else {
            strValue = StringUtil.lpad(new String(bytes), byteLen, "0");
            bytes    = strValue.getBytes();

            //System.arraycopy(bytes, 0, byteArray, 0, byteLen);
            for (int i = 0; i < byteLen; i++) {
                byteArray[i] = bytes[i];
            }
        }
    }

    // 필드값들을 설정하고 빈배열을 공백으로 채운다.
	public void setData(byte[] byteArray, String str) {
        // 문자열 값이 널이면 전부 공백으로 채우기 위해
        if (str == null)
            str = "";

        // 필드에 채울 문자열을 바이트배열로 변환
        byte[] bytes = null;
        try {
            bytes = str.getBytes("MS949");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

     // 실제데이터값의 바이트배열길이
        int endIdx = 0;

        // 실제데이터 바이트배열 설정
        if (byteArray.length < bytes.length)
        	endIdx = byteArray.length; // 실제데이터배열이 필드 배열보다 클경우
        else
        	endIdx = bytes.length; // 필드의 배열이 실제데이터배열보다 작을 경우
        
        // 필드배열에 실제데이터배열값으로 채운다.
        for (int i = 0; i < endIdx; i++) {
            byteArray[i] = bytes[i];
        }
        
		// 실제데이터값이 채워지지 않은 배열은 공백으로 채운다.
		for (int j = endIdx; j < byteArray.length; j++) {
		    byteArray[j] = ' ';
		}
    }
    
	// 필드값들을 설정하고 빈배열을 0으로 채운다.
	public void setDataNum(byte[] byteArray, String str) {
		// 문자열 값이 널이면 전부 공백으로 채우기 위해
        if (str == null)
            str = "0";

        // 필드에 채울 문자열을 바이트배열로 변환
        byte[] bytes = null;
        try {
            bytes = str.getBytes("MS949");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        // 실제데이터값의 바이트배열길이
        int startIdx = 0;

        // 실제데이터 바이트배열 설정
        if (byteArray.length >= bytes.length)
        	startIdx = byteArray.length-bytes.length; // 필드의 배열이 실제데이터배열보다 크거나 같을 경우
        else
        	startIdx = 0; // 필드의 배열이 실제데이터배열보다 작을 경우

        // 실제데이터값이 채워지지 않은 배열은 공백으로 채운다.
        for (int i = 0; i < startIdx; i++) {
            byteArray[i] = '0';
        }
        
        // 필드배열에 실제데이터배열값으로 채운다.
        for (int j = startIdx; j < byteArray.length; j++) {
            byteArray[j] = bytes[j-startIdx];
        }
    }
    public String getOrgnData(String varName) throws Exception {
        return getData(varName, "N");
    }

    public int    getLength(String varName) { return ((byte[])mapTLGM.get(varName)).length; }
    public String getType  (String varName) { return          mapTYPE.get(varName);         }
    public byte[] getByte  (String varName) { return  (byte[])mapTLGM.get(varName);         }
    public String getData(String varName, String utf8YN) throws Exception {

        byte[] byteData = getByte(varName);
        String valTP    = StringUtil.nvl(getType(varName));
        String str      = "";

        if (byteData != null) {

            if ("K".equals(valTP)) {

                if ("Y".equals(utf8YN)) { str = new String(byteData, "UTF-8"); }
                else                    { str = new String(byteData, "MS949"); }
            } else if ("N".equals(valTP)) {
                str = StringUtil.nvl(new String(byteData)).trim();
                if ("".equals(str)) { str = "0";}
                str = StringUtil.lpad(str, byteData.length, "0");
            } else {
                str = new String(byteData);
            }
        }

        return str;
    }
}
