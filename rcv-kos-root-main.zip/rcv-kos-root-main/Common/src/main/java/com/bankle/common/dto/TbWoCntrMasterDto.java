package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoCntrMaster}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbWoCntrMasterDto implements Serializable {
    @Size(max = 11)
    String loanNo;
    @NotNull
    @Size(max = 10)
    String bizNo;
    @NotNull
    @Size(max = 4)
    String isrnGbCd;
    @Size(max = 6)
    String bnkBrnchCd;
    @Size(max = 3)
    String bnkGbCd;
    @Size(max = 50)
    String bnkBrnchNm;
    @Size(max = 50)
    String bnkDrctrNm;
    @Size(max = 14)
    String bnkBrnchPhno;
    @Size(max = 2)
    String lndKndCd;
    @Size(max = 2)
    String statCd;
    @Size(max = 3)
    String lndStatCd;
    @Size(max = 2)
    String rgstrGbCd;
    @Size(max = 200)
    String lndPrdtNm;
    @Size(max = 50)
    String dbtrNm;
    @Size(max = 13)
    String dbtrBirthDt;
    @Size(max = 300)
    String dbtrAddr;
    @Size(max = 14)
    String dbtrHpno;
    @Size(max = 50)
    String pwpsNm;
    @Size(max = 13)
    String pwpsBirthDt;
    @Size(max = 14)
    String pwpsHpno;
    BigDecimal execPlnAmt;
    @Size(max = 13)
    String execPlnDt;
    BigDecimal execAmt;
    @Size(max = 13)
    String execDt;
    BigDecimal slPrc;
    BigDecimal isrnEntrAmt;
    @Size(max = 3)
    String lwyrDiffBankCd1;
    @Size(max = 3)
    String lwyrDiffBankCd2;
    @Size(max = 3)
    String lwyrDiffBankCd3;
    @Size(max = 3)
    String lwyrDiffBankCd4;
    @Size(max = 3)
    String lwyrDiffBankCd5;
    @Size(max = 3)
    String lwyrDiffBankCd6;
    @Size(max = 3)
    String lwyrDiffBankCd7;
    @Size(max = 3)
    String lwyrDiffBankCd8;
    @Size(max = 3)
    String lwyrDiffBankCd9;
    @Size(max = 3)
    String lwyrDiffBankCd10;
    @Size(max = 300)
    String ersuClsMsg;
    @Size(max = 10)
    String ebtsLwyrBizno;
    @Size(max = 60)
    String regoNm;
    LocalDateTime rgstrAcptDtm;
    @Size(max = 27)
    String imgKey;
    @Size(max = 1)
    String kndCd;
    @Size(max = 200)
    String lndThngAddr;
    @Size(max = 20)
    String ccrstAcptNum;
    @Size(max = 1)
    String clsctSctrtBprRegYn;
    @Size(max = 1)
    String ccrstBprRegYn;
    @Size(max = 1)
    String blncFpymnRcpt;
    @Size(max = 1)
    String regifBprRegYn;
    @Size(max = 10)
    String elregBizNo;
    @Size(max = 200)
    String rdnmInclAddr;
    @Size(max = 200)
    String rdnmStndAddr;
    @Size(max = 11)
    String grpNo;
    String rmk;
    @Size(max = 2)
    String insDvsn;
    Long trnInCnt;
    @Size(max = 1)
    String refndAcctRegYn;
    @Size(max = 8)
    String refndAcctRegDate;
    @Size(max = 1)
    String eltnSecuredYn;
    @Size(max = 1)
    String execAmtChangYn;
    @Size(max = 1)
    String estmRegYn;
    @Size(max = 1)
    String rgstrRegYn;
    @Size(max = 1)
    String payRegYn;
    @Size(max = 1)
    String estmCnfmYn;
    @Size(max = 1)
    String lndAmtPayYn;
    @Size(max = 1)
    String revisionCheckYn;
    @Size(max = 1)
    String estbsCntrFnYn;
    @Size(max = 1)
    String slCntrctEane;
    @Size(max = 50)
    String slCntrctFlnm;
    @Size(max = 1)
    String mvhhdSbmtYn;
    @Size(max = 1)
    String rrcpSbmtYn;
    @Size(max = 1)
    String rtalSbmtYn;
    @Size(max = 1)
    String cndtCntrYn;
    @Size(max = 1)
    String rgstrAcptSbmtYn;
    @Size(max = 1)
    String cnvntLwyrYn;
    @Size(max = 13)
    String rschWkDdlnReqDt;
    @Size(max = 100)
    String sscptAskDt;
    @Size(max = 1)
    String rrcpCnfmReqYn;
    @Size(max = 1)
    String mvhhdCnfmReqYn;
    @Size(max = 3)
    String rvsnCntrctChrgTrgtYn;
    @Size(max = 3)
    String stndAplYn;
    @Size(max = 3)
    String befDbsmtCnclCd;
    @Size(max = 3)
    String elregYn;
    @Size(max = 20)
    String bnkTtlReqNo;
    @Size(max = 2)
    String fndUseCd;
    @Size(max = 3)
    String offRgstrYn;
    @Size(max = 3)
    String a300Send;
    @Size(max = 1)
    private String lndHndgSlfDsc;
    @Size(max = 50)
    private String slmnCmpyNm;
    @Size(max = 50)
    private String slmnNm;
    @Size(max = 14)
    private String slmnPhno;
    @Size(max = 2)
    private String slmnLndProc;
    @Size(max = 10)
    private String srMembNo;
    private BigDecimal trAmt;
    @Size(max = 50)
    private String sellerNm1;
    @Size(max = 6)
    private String sellerBirthDt1;
    @Size(max = 50)
    private String sellerNm2;
    @Size(max = 6)
    private String sellerBirthDt2;
    private BigDecimal ownLoanMaxAmt;
    private BigDecimal ownLoanPlnAmt;
    @Size(max = 50)
    private String ownLoanBankNm1;
    @Size(max = 50)
    private String ownLoanBankNm2;
    @Size(max = 50)
    private String ownLoanBankNm3;
    @Size(max = 50)
    private String ownLoanBankNm4;
    @Size(max = 50)
    private String ownLoanBankNm5;
    @Size(max = 50)
    private String cnsgnNm;
    @Size(max = 50)
    private String trstNm;
    @Size(max = 50)
    private String bnfrNm;
    @Size(max = 50)
    private String nowLshDrNm;
    @Size(max = 50)
    private String rsrvItmB;
    @Size(max = 20)
    String oblMLnAprvNo;
    Integer oblTotCnt;
    Integer oblGrpRnkNo;
    @NotNull
    LocalDateTime crtDtm;
    @NotNull
    @Size(max = 12)
    String crtMembNo;
    @NotNull
    LocalDateTime chgDtm;
    @NotNull
    @Size(max = 12)
    String chgMembNo;
    private BigDecimal docAmt;
    private BigDecimal debtDcAmt;
    private BigDecimal etcAmt;
    @Size(max = 14)
    private String uptUnqNo;
}