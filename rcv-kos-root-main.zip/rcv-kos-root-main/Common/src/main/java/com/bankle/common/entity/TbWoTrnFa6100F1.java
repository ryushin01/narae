package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_TRN_FA_6100_F1")
public class TbWoTrnFa6100F1 {
    @EmbeddedId
    private TbWoTrnFa6100F1Id id;

    @Column(name = "TG_LEN", precision = 4)
    private BigDecimal tgLen;

    @Size(max = 4)
    @Column(name = "TG_DSC", length = 4)
    private String tgDsc;

    @Size(max = 8)
    @Column(name = "BNK_TG_NO", length = 8)
    private String bnkTgNo;

    @Size(max = 8)
    @Column(name = "FA_TG_NO", length = 8)
    private String faTgNo;

    @Size(max = 14)
    @Column(name = "KOS_TG_SND_NO", length = 14)
    private String kosTgSndNo;

    @Column(name = "TG_SND_DTM")
    private LocalDateTime tgSndDtm;

    @Column(name = "TG_RCV_DTM")
    private LocalDateTime tgRcvDtm;

    @Size(max = 3)
    @Column(name = "RES_CD", length = 3)
    private String resCd;

    @Size(max = 35)
    @Column(name = "RSRV_ITM_H", length = 35)
    private String rsrvItmH;

    @Size(max = 20)
    @Column(name = "BNK_TTL_REQ_NO", length = 20)
    private String bnkTtlReqNo;

    @Size(max = 1)
    @Column(name = "TTL_ARD_ENTR_EANE", length = 1)
    private String ttlArdEntrEane;

    @Size(max = 1)
    @Column(name = "TTL_ENTRCMPY", length = 1)
    private String ttlEntrcmpy;

    @Size(max = 15)
    @Column(name = "TTL_SCRT_NO", length = 15)
    private String ttlScrtNo;

    @Size(max = 2)
    @Column(name = "LND_DSC", length = 2)
    private String lndDsc;

    @Size(max = 2)
    @Column(name = "LND_KND_CD", length = 2)
    private String lndKndCd;

    @Size(max = 2)
    @Column(name = "FND_USE_CD", length = 2)
    private String fndUseCd;

    @Size(max = 9)
    @Column(name = "BNK_LND_PRDT_CD", length = 9)
    private String bnkLndPrdtCd;

    @Size(max = 200)
    @Column(name = "BNK_LND_PRDT_NM", length = 200)
    private String bnkLndPrdtNm;

    @Size(max = 2)
    @Column(name = "GRNT_DSC", length = 2)
    private String grntDsc;

    @Size(max = 1)
    @Column(name = "STND_APL_YN", length = 1)
    private String stndAplYn;

    @Size(max = 1)
    @Column(name = "RRCP_CNFM_REQ_YN", length = 1)
    private String rrcpCnfmReqYn;

    @Size(max = 1)
    @Column(name = "MVHR_CNFM_REQ_YN", length = 1)
    private String mvhrCnfmReqYn;

    @Size(max = 1)
    @Column(name = "BF_SRVTRGT_REQ_YN", length = 1)
    private String bfSrvtrgtReqYn;

    @Size(max = 1)
    @Column(name = "AF_SRVTRGT_REQ_YN", length = 1)
    private String afSrvtrgtReqYn;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_1", length = 14)
    private String rgstrUnqNo1;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_2", length = 14)
    private String rgstrUnqNo2;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_3", length = 14)
    private String rgstrUnqNo3;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_4", length = 14)
    private String rgstrUnqNo4;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_5", length = 14)
    private String rgstrUnqNo5;

    @Size(max = 1)
    @Column(name = "RLES_DSC", length = 1)
    private String rlesDsc;

    @Size(max = 2)
    @Column(name = "TRGT_RLES_DSC", length = 2)
    private String trgtRlesDsc;

    @Size(max = 300)
    @Column(name = "TRGT_RLES_ADDR", length = 300)
    private String trgtRlesAddr;

    @Size(max = 8)
    @Column(name = "SSCPT_ASK_DT", length = 8)
    private String sscptAskDt;

    @Size(max = 8)
    @Column(name = "LND_PLN_DT", length = 8)
    private String lndPlnDt;

    @Size(max = 8)
    @Column(name = "LND_EXPRD_DT", length = 8)
    private String lndExprdDt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "SL_PRC", nullable = false, precision = 15)
    private BigDecimal slPrc;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "ISRN_ENTR_AMT", nullable = false, precision = 15)
    private BigDecimal isrnEntrAmt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "LND_PRD", nullable = false, precision = 3)
    private BigDecimal lndPrd;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "LND_AMT", nullable = false, precision = 15)
    private BigDecimal lndAmt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "BNK_FXCLT_RGSTR_RNK", nullable = false, precision = 1)
    private BigDecimal bnkFxcltRgstrRnk;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "BNK_FXCLT_BND_MAX_AMT", nullable = false, precision = 15)
    private BigDecimal bnkFxcltBndMaxAmt;

    @Size(max = 50)
    @Column(name = "DBTR_NM", length = 50)
    private String dbtrNm;

    @Size(max = 13)
    @Column(name = "DBTR_BIRTH_DT", length = 13)
    private String dbtrBirthDt;

    @Size(max = 300)
    @Column(name = "DBTR_ADDR", length = 300)
    private String dbtrAddr;

    @Size(max = 14)
    @Column(name = "DBTR_PHNO", length = 14)
    private String dbtrPhno;

    @Size(max = 14)
    @Column(name = "DBTR_HPNO", length = 14)
    private String dbtrHpno;

    @Size(max = 50)
    @Column(name = "PWPS_NM", length = 50)
    private String pwpsNm;

    @Size(max = 13)
    @Column(name = "PWPS_BIRTH_DT", length = 13)
    private String pwpsBirthDt;

    @Size(max = 300)
    @Column(name = "PWPS_ADDR", length = 300)
    private String pwpsAddr;

    @Size(max = 14)
    @Column(name = "PWPS_PHNO", length = 14)
    private String pwpsPhno;

    @Size(max = 14)
    @Column(name = "PWPS_HPNO", length = 14)
    private String pwpsHpno;

    @Size(max = 200)
    @Column(name = "RMK_FCT", length = 200)
    private String rmkFct;

    @Size(max = 1)
    @Column(name = "LND_HNDG_SLF_DSC", length = 1)
    private String lndHndgSlfDsc;

    @Size(max = 50)
    @Column(name = "BNK_BRNCH_NM", length = 50)
    private String bnkBrnchNm;

    @Size(max = 50)
    @Column(name = "BNK_DRCTR_NM", length = 50)
    private String bnkDrctrNm;

    @Size(max = 14)
    @Column(name = "BNK_BRNCH_PHNO", length = 14)
    private String bnkBrnchPhno;

    @Size(max = 14)
    @Column(name = "BNK_DRCTR_HP", length = 14)
    private String bnkDrctrHp;

    @Size(max = 14)
    @Column(name = "BNK_BRNCH_FAX", length = 14)
    private String bnkBrnchFax;

    @Size(max = 100)
    @Column(name = "BNK_BRNCH_ADDR", length = 100)
    private String bnkBrnchAddr;

    @Size(max = 50)
    @Column(name = "SLMN_CMPY_NM", length = 50)
    private String slmnCmpyNm;

    @Size(max = 50)
    @Column(name = "SLMN_NM", length = 50)
    private String slmnNm;

    @Size(max = 14)
    @Column(name = "SLMN_PHNO", length = 14)
    private String slmnPhno;

    @Size(max = 50)
    @Column(name = "LWFM_NM", length = 50)
    private String lwfmNm;

    @Size(max = 12)
    @Column(name = "LWFM_BIZNO", length = 12)
    private String lwfmBizno;

    @Size(max = 1)
    @Column(name = "DBTR_WDNG_PLN_YN", length = 1)
    private String dbtrWdngPlnYn;

    @Size(max = 1)
    @Column(name = "RRCP_CNFM_YN", length = 1)
    private String rrcpCnfmYn;

    @Size(max = 50)
    @Column(name = "SPUS_NM", length = 50)
    private String spusNm;

    @Size(max = 8)
    @Column(name = "WDNG_PLN_DT", length = 8)
    private String wdngPlnDt;

    @Size(max = 8)
    @Column(name = "RSCH_WK_DDLN_REQ_DT", length = 8)
    private String rschWkDdlnReqDt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "ISRN_PRMM", nullable = false, precision = 11)
    private BigDecimal isrnPrmm;

    @Size(max = 20)
    @Column(name = "RFR_LN_APRV_NO", length = 20)
    private String rfrLnAprvNo;

    @Size(max = 1)
    @Column(name = "RGSTR_MTD_DSC", length = 1)
    private String rgstrMtdDsc;

    @Size(max = 20)
    @Column(name = "RGSTR_REQ_NO", length = 20)
    private String rgstrReqNo;

    @Size(max = 1)
    @Column(name = "ODPRT_RPY_EANE", length = 1)
    private String odprtRpyEane;

    @Size(max = 50)
    @Column(name = "ELTN_ESTBS_LWYR_NM", length = 50)
    private String eltnEstbsLwyrNm;

    @Size(max = 12)
    @Column(name = "ELTN_ESTBS_LWYR_BIZNO", length = 12)
    private String eltnEstbsLwyrBizno;

    @Size(max = 1)
    @Column(name = "ELTN_RPY_LOA_APL_YN", length = 1)
    private String eltnRpyLoaAplYn;

    @Size(max = 16)
    @Column(name = "ELTN_RPY_LOA_SQN", length = 16)
    private String eltnRpyLoaSqn;

    @Size(max = 6)
    @Column(name = "ELTN_RPY_LOA_CTFC_NO", length = 6)
    private String eltnRpyLoaCtfcNo;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "WHL_RPY_CNT", nullable = false, precision = 2)
    private BigDecimal whlRpyCnt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "WHL_RPY_AMT", nullable = false, precision = 15)
    private BigDecimal whlRpyAmt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "EBNK_RPY_TOT_AMT", nullable = false, precision = 15)
    private BigDecimal ebnkRpyTotAmt;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "DFBNK_RPY_TOT_AMT", nullable = false, precision = 15)
    private BigDecimal dfbnkRpyTotAmt;

    @Size(max = 2)
    @Column(name = "RPY_TRGT_RNK_NO_1", length = 2)
    private String rpyTrgtRnkNo1;

    @Size(max = 8)
    @Column(name = "RPY_TRGT_ACPT_DT_1", length = 8)
    private String rpyTrgtAcptDt1;

    @Size(max = 6)
    @Column(name = "RPY_TRGT_ACPT_NO_1", length = 6)
    private String rpyTrgtAcptNo1;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "RPY_TRGT_BND_AMT_1", nullable = false, precision = 15)
    private BigDecimal rpyTrgtBndAmt1;

    @Size(max = 2)
    @Column(name = "RPY_TRGT_RNK_NO_2", length = 2)
    private String rpyTrgtRnkNo2;

    @Size(max = 8)
    @Column(name = "RPY_TRGT_ACPT_DT_2", length = 8)
    private String rpyTrgtAcptDt2;

    @Size(max = 6)
    @Column(name = "RPY_TRGT_ACPT_NO_2", length = 6)
    private String rpyTrgtAcptNo2;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "RPY_TRGT_BND_AMT_2", nullable = false, precision = 15)
    private BigDecimal rpyTrgtBndAmt2;

    @Size(max = 2)
    @Column(name = "RPY_TRGT_RNK_NO_3", length = 2)
    private String rpyTrgtRnkNo3;

    @Size(max = 8)
    @Column(name = "RPY_TRGT_ACPT_DT_3", length = 8)
    private String rpyTrgtAcptDt3;

    @Size(max = 6)
    @Column(name = "RPY_TRGT_ACPT_NO_3", length = 6)
    private String rpyTrgtAcptNo3;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "RPY_TRGT_BND_AMT_3", nullable = false, precision = 15)
    private BigDecimal rpyTrgtBndAmt3;

    @Size(max = 2)
    @Column(name = "RPY_TRGT_RNK_NO_4", length = 2)
    private String rpyTrgtRnkNo4;

    @Size(max = 8)
    @Column(name = "RPY_TRGT_ACPT_DT_4", length = 8)
    private String rpyTrgtAcptDt4;

    @Size(max = 6)
    @Column(name = "RPY_TRGT_ACPT_NO_4", length = 6)
    private String rpyTrgtAcptNo4;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "RPY_TRGT_BND_AMT_4", nullable = false, precision = 15)
    private BigDecimal rpyTrgtBndAmt4;

    @Size(max = 2)
    @Column(name = "RPY_TRGT_RNK_NO_5", length = 2)
    private String rpyTrgtRnkNo5;

    @Size(max = 8)
    @Column(name = "RPY_TRGT_ACPT_DT_5", length = 8)
    private String rpyTrgtAcptDt5;

    @Size(max = 6)
    @Column(name = "RPY_TRGT_ACPT_NO_5", length = 6)
    private String rpyTrgtAcptNo5;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "RPY_TRGT_BND_AMT_5", nullable = false, precision = 15)
    private BigDecimal rpyTrgtBndAmt5;

    @Size(max = 1)
    @Column(name = "AFRGSTR_SCRT_YN", length = 1)
    private String afrgstrScrtYn;

    @Size(max = 2)
    @Column(name = "SLMN_LND_PROC", length = 2)
    private String slmnLndProc;

    @Size(max = 10)
    @Column(name = "SR_MEMB_NO", length = 10)
    private String srMembNo;

    @ColumnDefault("0")
    @Column(name = "TR_AMT", precision = 15)
    private BigDecimal trAmt;

    @Size(max = 50)
    @Column(name = "SLL_NM_1", length = 50)
    private String sllNm1;

    @Size(max = 6)
    @Column(name = "SLL_BR_DAY_1", length = 6)
    private String sllBrDay1;

    @Size(max = 50)
    @Column(name = "SLL_NM_2", length = 50)
    private String sllNm2;

    @Size(max = 6)
    @Column(name = "SLL_BR_DAY_2", length = 6)
    private String sllBrDay2;

    @ColumnDefault("0")
    @Column(name = "OWN_LOAN_MAX_AMT", precision = 15)
    private BigDecimal ownLoanMaxAmt;

    @ColumnDefault("0")
    @Column(name = "OWN_LOAN_PLN_AMT", precision = 15)
    private BigDecimal ownLoanPlnAmt;

    @Size(max = 50)
    @Column(name = "OWN_LOAN_BNK_NM_1", length = 50)
    private String ownLoanBnkNm1;

    @Size(max = 50)
    @Column(name = "OWN_LOAN_BNK_NM_2", length = 50)
    private String ownLoanBnkNm2;

    @Size(max = 50)
    @Column(name = "OWN_LOAN_BNK_NM_3", length = 50)
    private String ownLoanBnkNm3;

    @Size(max = 50)
    @Column(name = "OWN_LOAN_BNK_NM_4", length = 50)
    private String ownLoanBnkNm4;

    @Size(max = 50)
    @Column(name = "OWN_LOAN_BNK_NM_5", length = 50)
    private String ownLoanBnkNm5;

    @Size(max = 50)
    @Column(name = "CNSGN_NM", length = 50)
    private String cnsgnNm;

    @Size(max = 50)
    @Column(name = "TRST_NM", length = 50)
    private String trstNm;

    @Size(max = 50)
    @Column(name = "BNFR_NM", length = 50)
    private String bnfrNm;

    @Size(max = 50)
    @Column(name = "NOW_LESS_NM", length = 50)
    private String nowLessNm;

    @Size(max = 50)
    @Column(name = "RSRV_ITM_B", length = 50)
    private String rsrvItmB;

    @Column(name = "REG_DTM")
    private LocalDateTime regDtm;

    @Size(max = 20)
    @Column(name = "OBL_M_LN_APRV_NO", length = 20)
    private String oblMLnAprvNo;

    @ColumnDefault("0")
    @Column(name = "OBL_TOT_CNT")
    private Integer oblTotCnt;

    @ColumnDefault("0")
    @Column(name = "OBL_GRP_RNK_NO")
    private Integer oblGrpRnkNo;

    @Size(max = 20)
    @Column(name = "LN_APRV_NO2", length = 20)
    private String lnAprvNo2;

}