package com.bankle.common.wooriApi.socket.ins.socketData;

import java.io.InputStream;

public class T6100F1 extends GetSetData {

    final String DATE_FORMAT = "yyyyMMddHHmmss";
    final int cntColumn = 0;
    String[] arrName = null;   // Layout Column Name

    byte[] TG_LEN = new byte[4];
    byte[] TG_DSC = new byte[4];
    byte[] BNK_TG_NO = new byte[8];
    byte[] FA_TG_NO = new byte[8];
    byte[] KOS_TG_SND_NO = new byte[14];
    byte[] TG_SND_DTM = new byte[14];
    byte[] TG_RCV_DTM = new byte[14];
    byte[] RES_CD = new byte[3];
    byte[] RSRV_ITM_H = new byte[35];
    byte[] BNK_TTL_REQ_NO = new byte[20];
    byte[] LN_APRV_NO = new byte[20];
    byte[] TTL_ARD_ENTR_EANE = new byte[1];
    byte[] TTL_ENTRCMPY = new byte[1];
    byte[] TTL_SCRT_NO = new byte[15];
    byte[] LND_DSC = new byte[2];
    byte[] LND_KND_CD = new byte[2];
    byte[] FND_USE_CD = new byte[2];
    byte[] BNK_LND_PRDT_CD = new byte[9];
    byte[] BNK_LND_PRDT_NM = new byte[200];
    byte[] GRNT_DSC = new byte[2];
    byte[] STND_APL_YN = new byte[1];
    byte[] RRCP_CNFM_REQ_YN = new byte[1];
    byte[] MVHR_CNFM_REQ_YN = new byte[1];
    byte[] BF_SRVTRGT_REQ_YN = new byte[1];
    byte[] AF_SRVTRGT_REQ_YN = new byte[1];
    byte[] RGSTR_UNQ_NO_1 = new byte[14];
    byte[] RGSTR_UNQ_NO_2 = new byte[14];
    byte[] RGSTR_UNQ_NO_3 = new byte[14];
    byte[] RGSTR_UNQ_NO_4 = new byte[14];
    byte[] RGSTR_UNQ_NO_5 = new byte[14];
    byte[] RLES_DSC = new byte[1];
    byte[] TRGT_RLES_DSC = new byte[2];
    byte[] TRGT_RLES_ADDR = new byte[300];
    byte[] SSCPT_ASK_DT = new byte[8];
    byte[] LND_PLN_DT = new byte[8];
    byte[] LND_EXPRD_DT = new byte[8];
    byte[] SL_PRC = new byte[15];
    byte[] ISRN_ENTR_AMT = new byte[15];
    byte[] LND_PRD = new byte[3];
    byte[] LND_AMT = new byte[15];
    byte[] BNK_FXCLT_RGSTR_RNK = new byte[1];
    byte[] BNK_FXCLT_BND_MAX_AMT = new byte[15];
    byte[] DBTR_NM = new byte[50];
    byte[] DBTR_BIRTH_DT = new byte[13];
    byte[] DBTR_ADDR = new byte[300];
    byte[] DBTR_PHNO = new byte[14];
    byte[] DBTR_HPNO = new byte[14];
    byte[] PWPS_NM = new byte[50];
    byte[] PWPS_BIRTH_DT = new byte[13];
    byte[] PWPS_ADDR = new byte[300];
    byte[] PWPS_PHNO = new byte[14];
    byte[] PWPS_HPNO = new byte[14];
    byte[] RMK_FCT = new byte[200];
    byte[] LND_HNDG_SLF_DSC = new byte[1];
    byte[] BNK_BRNCH_NM = new byte[50];
    byte[] BNK_DRCTR_NM = new byte[50];
    byte[] BNK_BRNCH_PHNO = new byte[14];
    byte[] BNK_DRCTR_HP = new byte[14];
    byte[] BNK_BRNCH_FAX = new byte[14];
    byte[] BNK_BRNCH_ADDR = new byte[100];
    byte[] SLMN_CMPY_NM = new byte[50];
    byte[] SLMN_NM = new byte[50];
    byte[] SLMN_PHNO = new byte[14];
    byte[] LWFM_NM = new byte[50];
    byte[] LWFM_BIZNO = new byte[12];
    byte[] DBTR_WDNG_PLN_YN = new byte[1];
    byte[] RRCP_CNFM_YN = new byte[1];
    byte[] SPUS_NM = new byte[50];
    byte[] WDNG_PLN_DT = new byte[8];
    byte[] RSCH_WK_DDLN_REQ_DT = new byte[8];
    byte[] ISRN_PRMM = new byte[11];
    byte[] RFR_LN_APRV_NO = new byte[20];
    byte[] RGSTR_MTD_DSC = new byte[1];
    byte[] RGSTR_REQ_NO = new byte[20];
    byte[] ODPRT_RPY_EANE = new byte[1];
    byte[] ELTN_ESTBS_LWYR_NM = new byte[50];
    byte[] ELTN_ESTBS_LWYR_BIZNO = new byte[12];
    byte[] ELTN_RPY_LOA_APL_YN = new byte[1];
    byte[] ELTN_RPY_LOA_SQN = new byte[16];
    byte[] ELTN_RPY_LOA_CTFC_NO = new byte[6];
    byte[] WHL_RPY_CNT = new byte[2];
    byte[] WHL_RPY_AMT = new byte[15];
    byte[] EBNK_RPY_TOT_AMT = new byte[15];
    byte[] DFBNK_RPY_TOT_AMT = new byte[15];
    byte[] RPY_TRGT_RNK_NO_1 = new byte[2];
    byte[] RPY_TRGT_ACPT_DT_1 = new byte[8];
    byte[] RPY_TRGT_ACPT_NO_1 = new byte[6];
    byte[] RPY_TRGT_BND_AMT_1 = new byte[15];
    byte[] RPY_TRGT_RNK_NO_2 = new byte[2];
    byte[] RPY_TRGT_ACPT_DT_2 = new byte[8];
    byte[] RPY_TRGT_ACPT_NO_2 = new byte[6];
    byte[] RPY_TRGT_BND_AMT_2 = new byte[15];
    byte[] RPY_TRGT_RNK_NO_3 = new byte[2];
    byte[] RPY_TRGT_ACPT_DT_3 = new byte[8];
    byte[] RPY_TRGT_ACPT_NO_3 = new byte[6];
    byte[] RPY_TRGT_BND_AMT_3 = new byte[15];
    byte[] RPY_TRGT_RNK_NO_4 = new byte[2];
    byte[] RPY_TRGT_ACPT_DT_4 = new byte[8];
    byte[] RPY_TRGT_ACPT_NO_4 = new byte[6];
    byte[] RPY_TRGT_BND_AMT_4 = new byte[15];
    byte[] RPY_TRGT_RNK_NO_5 = new byte[2];
    byte[] RPY_TRGT_ACPT_DT_5 = new byte[8];
    byte[] RPY_TRGT_ACPT_NO_5 = new byte[6];
    byte[] RPY_TRGT_BND_AMT_5 = new byte[15];
    byte[] AFRGSTR_SCRT_YN = new byte[1];
    byte[] RSRV_ITM_B = new byte[50];


    public T6100F1() {
        setData(this.TG_LEN, "");
        setData(this.TG_DSC, "");
        setData(this.BNK_TG_NO, "");
        setData(this.FA_TG_NO, "");
        setData(this.KOS_TG_SND_NO, "");
        setData(this.TG_SND_DTM, "");
        setData(this.TG_RCV_DTM, "");
        setData(this.RES_CD, "");
        setData(this.RSRV_ITM_H, "");
        setData(this.BNK_TTL_REQ_NO, "");
        setData(this.TTL_ARD_ENTR_EANE, "");
        setData(this.TTL_ENTRCMPY, "");
        setData(this.TTL_SCRT_NO, "");
        setData(this.LND_DSC, "");
        setData(this.LND_KND_CD, "");
        setData(this.FND_USE_CD, "");
        setData(this.BNK_LND_PRDT_CD, "");
        setData(this.BNK_LND_PRDT_NM, "");
        setData(this.GRNT_DSC, "");
        setData(this.STND_APL_YN, "");
        setData(this.RRCP_CNFM_REQ_YN, "");
        setData(this.MVHR_CNFM_REQ_YN, "");
        setData(this.BF_SRVTRGT_REQ_YN, "");
        setData(this.AF_SRVTRGT_REQ_YN, "");
        setData(this.RGSTR_UNQ_NO_1, "");
        setData(this.RGSTR_UNQ_NO_2, "");
        setData(this.RGSTR_UNQ_NO_3, "");
        setData(this.RGSTR_UNQ_NO_4, "");
        setData(this.RGSTR_UNQ_NO_5, "");
        setData(this.RLES_DSC, "");
        setData(this.TRGT_RLES_DSC, "");
        setData(this.TRGT_RLES_ADDR, "");
        setData(this.SSCPT_ASK_DT, "");
        setData(this.LND_PLN_DT, "");
        setData(this.LND_EXPRD_DT, "");
        setData(this.SL_PRC, "");
        setData(this.ISRN_ENTR_AMT, "");
        setData(this.LND_PRD, "");
        setData(this.LND_AMT, "");
        setData(this.BNK_FXCLT_RGSTR_RNK, "");
        setData(this.BNK_FXCLT_BND_MAX_AMT, "");
        setData(this.DBTR_NM, "");
        setData(this.DBTR_BIRTH_DT, "");
        setData(this.DBTR_ADDR, "");
        setData(this.DBTR_PHNO, "");
        setData(this.DBTR_HPNO, "");
        setData(this.PWPS_NM, "");
        setData(this.PWPS_BIRTH_DT, "");
        setData(this.PWPS_ADDR, "");
        setData(this.PWPS_PHNO, "");
        setData(this.PWPS_HPNO, "");
        setData(this.RMK_FCT, "");
        setData(this.LND_HNDG_SLF_DSC, "");
        setData(this.BNK_BRNCH_NM, "");
        setData(this.BNK_DRCTR_NM, "");
        setData(this.BNK_BRNCH_PHNO, "");
        setData(this.BNK_DRCTR_HP, "");
        setData(this.BNK_BRNCH_FAX, "");
        setData(this.BNK_BRNCH_ADDR, "");
        setData(this.SLMN_CMPY_NM, "");
        setData(this.SLMN_NM, "");
        setData(this.SLMN_PHNO, "");
        setData(this.LWFM_NM, "");
        setData(this.LWFM_BIZNO, "");
        setData(this.DBTR_WDNG_PLN_YN, "");
        setData(this.RRCP_CNFM_YN, "");
        setData(this.SPUS_NM, "");
        setData(this.WDNG_PLN_DT, "");
        setData(this.RSCH_WK_DDLN_REQ_DT, "");
        setData(this.ISRN_PRMM, "");
        setData(this.RFR_LN_APRV_NO, "");
        setData(this.RGSTR_MTD_DSC, "");
        setData(this.RGSTR_REQ_NO, "");
        setData(this.ODPRT_RPY_EANE, "");
        setData(this.ELTN_ESTBS_LWYR_NM, "");
        setData(this.ELTN_ESTBS_LWYR_BIZNO, "");
        setData(this.ELTN_RPY_LOA_APL_YN, "");
        setData(this.ELTN_RPY_LOA_SQN, "");
        setData(this.ELTN_RPY_LOA_CTFC_NO, "");
        setData(this.WHL_RPY_CNT, "");
        setData(this.WHL_RPY_AMT, "");
        setData(this.EBNK_RPY_TOT_AMT, "");
        setData(this.DFBNK_RPY_TOT_AMT, "");
        setData(this.RPY_TRGT_RNK_NO_1, "");
        setData(this.RPY_TRGT_ACPT_DT_1, "");
        setData(this.RPY_TRGT_ACPT_NO_1, "");
        setData(this.RPY_TRGT_BND_AMT_1, "");
        setData(this.RPY_TRGT_RNK_NO_2, "");
        setData(this.RPY_TRGT_ACPT_DT_2, "");
        setData(this.RPY_TRGT_ACPT_NO_2, "");
        setData(this.RPY_TRGT_BND_AMT_2, "");
        setData(this.RPY_TRGT_RNK_NO_3, "");
        setData(this.RPY_TRGT_ACPT_DT_3, "");
        setData(this.RPY_TRGT_ACPT_NO_3, "");
        setData(this.RPY_TRGT_BND_AMT_3, "");
        setData(this.RPY_TRGT_RNK_NO_4, "");
        setData(this.RPY_TRGT_ACPT_DT_4, "");
        setData(this.RPY_TRGT_ACPT_NO_4, "");
        setData(this.RPY_TRGT_BND_AMT_4, "");
        setData(this.RPY_TRGT_RNK_NO_5, "");
        setData(this.RPY_TRGT_ACPT_DT_5, "");
        setData(this.RPY_TRGT_ACPT_NO_5, "");
        setData(this.RPY_TRGT_BND_AMT_5, "");
        setData(this.AFRGSTR_SCRT_YN, "");
        setData(this.RSRV_ITM_B, "");
    }

    public String getTG_LEN() {
        return getData(TG_LEN);
    }

    public String getTG_DSC() {
        return getData(TG_DSC);
    }

    public String getBNK_TG_NO() {
        return getData(BNK_TG_NO);
    }


    public String getFA_TG_NO() {
        return getData(FA_TG_NO);
    }

    public String getKOS_TG_SND_NO() {
        return getData(KOS_TG_SND_NO);
    }

    public String getTG_SND_DTM() {
        return getData(TG_SND_DTM);
    }


    public String getTG_RCV_DTM() {
        return getData(TG_RCV_DTM);
    }


    public String getRES_CD() {
        return getData(RES_CD);
    }

    public String getRSRV_ITM_H() {
        return getData(RSRV_ITM_H);
    }

    public String getBNK_TTL_REQ_NO() {
        return getData(BNK_TTL_REQ_NO);
    }

    public String getLN_APRV_NO() {
        return getData(LN_APRV_NO);
    }

    public String getTTL_ARD_ENTR_EANE() {
        return getData(TTL_ARD_ENTR_EANE);
    }

    public String getTTL_ENTRCMPY() {
        return getData(TTL_ENTRCMPY);
    }

    public String getTTL_SCRT_NO() {
        return getData(TTL_SCRT_NO);
    }

    public String getLND_DSC() {
        return getData(LND_DSC);
    }

    public String getLND_KND_CD() {
        return getData(LND_KND_CD);
    }


    public String getFND_USE_CD() {
        return getData(FND_USE_CD);
    }

    public String getBNK_LND_PRDT_CD() {
        return getData(BNK_LND_PRDT_CD);
    }


    public String getBNK_LND_PRDT_NM() {
        return getData(BNK_LND_PRDT_NM);
    }

    public String getGRNT_DSC() {
        return getData(GRNT_DSC);
    }

    public String getSTND_APL_YN() {
        return getData(STND_APL_YN);
    }

    public String getRRCP_CNFM_REQ_YN() {
        return getData(RRCP_CNFM_REQ_YN);
    }

    public String getMVHR_CNFM_REQ_YN() {
        return getData(MVHR_CNFM_REQ_YN);
    }

    public String getBF_SRVTRGT_REQ_YN() {
        return getData(BF_SRVTRGT_REQ_YN);
    }

    public String getAF_SRVTRGT_REQ_YN() {
        return getData(BF_SRVTRGT_REQ_YN);
    }

    public String getRGSTR_UNQ_NO_1() {
        return getData(RGSTR_UNQ_NO_1);
    }

    public String getRGSTR_UNQ_NO_2() {
        return getData(RGSTR_UNQ_NO_2);
    }


    public String getRGSTR_UNQ_NO_3() {
        return getData(RGSTR_UNQ_NO_3);
    }


    public String getRGSTR_UNQ_NO_4() {
        return getData(RGSTR_UNQ_NO_4);
    }


    public String getRGSTR_UNQ_NO_5() {
        return getData(RGSTR_UNQ_NO_5);
    }

    public String getRLES_DSC() {
        return getData(RLES_DSC);
    }

    public String getTRGT_RLES_DSC() {
        return getData(TRGT_RLES_DSC);
    }

    public String getTRGT_RLES_ADDR() {
        return getData(TRGT_RLES_ADDR);
    }

    public String getSSCPT_ASK_DT() {
        return getData(SSCPT_ASK_DT);
    }


    public String getLND_PLN_DT() {
        return getData(LND_PLN_DT);
    }

    public String getLND_EXPRD_DT() {
        return getData(LND_EXPRD_DT);
    }


    public String getSL_PRC() {
        return getData(SL_PRC);
    }


    public String getISRN_ENTR_AMT() {
        return getData(ISRN_ENTR_AMT);
    }

    public String getLND_PRD() {
        return getData(LND_PRD);
    }

    public String getLND_AMT() {
        return getData(LND_AMT);
    }

    public String getBNK_FXCLT_RGSTR_RNK() {
        return getData(BNK_FXCLT_RGSTR_RNK);
    }

    public String getBNK_FXCLT_BND_MAX_AMT() {
        return getData(BNK_FXCLT_BND_MAX_AMT);
    }

    public String getDBTR_NM() {
        return getData(DBTR_NM);
    }

    public String getDBTR_BIRTH_DT() {
        return getData(DBTR_BIRTH_DT);
    }

    public String getDBTR_ADDR() {
        return getData(DBTR_ADDR);
    }

    public String getDBTR_PHNO() {
        return getData(DBTR_PHNO);
    }


    public String getDBTR_HPNO() {
        return getData(DBTR_HPNO);
    }

    public String getPWPS_NM() {
        return getData(PWPS_NM);
    }


    public String getPWPS_BIRTH_DT() {
        return getData(PWPS_BIRTH_DT);
    }


    public String getPWPS_ADDR() {
        return getData(PWPS_ADDR);
    }


    public String getPWPS_PHNO() {
        return getData(PWPS_PHNO);
    }


    public String getPWPS_HPNO() {
        return getData(PWPS_HPNO);
    }

    public String getRMK_FCT() {
        return getData(RMK_FCT);
    }


    public String getLND_HNDG_SLF_DSC() {
        return getData(LND_HNDG_SLF_DSC);
    }


    public String getBNK_BRNCH_NM() {
        return getData(BNK_BRNCH_NM);
    }


    public String getBNK_DRCTR_NM() {
        return getData(BNK_DRCTR_NM);
    }


    public String getBNK_BRNCH_PHNO() {
        return getData(BNK_BRNCH_PHNO);
    }


    public String getBNK_DRCTR_HP() {
        return getData(BNK_DRCTR_HP);
    }


    public String getBNK_BRNCH_FAX() {
        return getData(BNK_BRNCH_FAX);
    }


    public String getBNK_BRNCH_ADDR() {
        return getData(BNK_BRNCH_ADDR);
    }


    public String getSLMN_CMPY_NM() {
        return getData(SLMN_CMPY_NM);
    }


    public String getSLMN_NM() {
        return getData(SLMN_NM);
    }

    public String getSLMN_PHNO() {
        return getData(SLMN_PHNO);
    }

    public String getLWFM_NM() {
        return getData(LWFM_NM);
    }

    public String getLWFM_BIZNO() {
        return getData(LWFM_BIZNO);
    }

    public String getDBTR_WDNG_PLN_YN() {
        return getData(DBTR_WDNG_PLN_YN);
    }

    public String getRRCP_CNFM_YN() {
        return getData(RRCP_CNFM_YN);
    }

    public String getSPUS_NM() {
        return getData(SPUS_NM);

    }

    public String getWDNG_PLN_DT() {
        return getData(WDNG_PLN_DT);
    }

    public String getRSCH_WK_DDLN_REQ_DT() {
        return getData(RSCH_WK_DDLN_REQ_DT);
    }

    public String getISRN_PRMM() {
        return getData(ISRN_PRMM);
    }

    public String getRFR_LN_APRV_NO() {
        return getData(RFR_LN_APRV_NO);
    }

    public String getRGSTR_MTD_DSC() {
        return getData(RGSTR_MTD_DSC);
    }

    public String getRGSTR_REQ_NO() {
        return getData(RGSTR_REQ_NO);
    }

    public String getODPRT_RPY_EANE() {
        return getData(ODPRT_RPY_EANE);
    }

    public String getELTN_ESTBS_LWYR_NM() {
        return getData(ELTN_ESTBS_LWYR_NM);
    }

    public String getELTN_ESTBS_LWYR_BIZNO() {
        return getData(ELTN_ESTBS_LWYR_BIZNO);
    }

    public String getELTN_RPY_LOA_APL_YN() {
        return getData(ELTN_RPY_LOA_APL_YN);
    }


    public String getELTN_RPY_LOA_SQN() {
        return getData(ELTN_RPY_LOA_SQN);
    }

    public String getELTN_RPY_LOA_CTFC_NO() {
        return getData(ELTN_RPY_LOA_CTFC_NO);
    }

    public String getWHL_RPY_CNT() {
        return getData(WHL_RPY_CNT);
    }

    public String getWHL_RPY_AMT() {
        return getData(WHL_RPY_AMT);
    }

    public String getEBNK_RPY_TOT_AMT() {
        return getData(EBNK_RPY_TOT_AMT);
    }

    public String getDFBNK_RPY_TOT_AMT() {
        return getData(DFBNK_RPY_TOT_AMT);
    }

    public String getRPY_TRGT_RNK_NO_1() {
        return getData(RPY_TRGT_RNK_NO_1);
    }


    public String getRPY_TRGT_ACPT_DT_1() {
        return getData(RPY_TRGT_ACPT_DT_1);
    }

    public String getRPY_TRGT_ACPT_NO_1() {
        return getData(RPY_TRGT_ACPT_NO_1);
    }

    public String getRPY_TRGT_BND_AMT_1() {
        return getData(RPY_TRGT_BND_AMT_1);
    }

    public String getRPY_TRGT_RNK_NO_2() {
        return getData(RPY_TRGT_RNK_NO_1);
    }


    public String getRPY_TRGT_ACPT_DT_2() {
        return getData(RPY_TRGT_ACPT_DT_1);
    }

    public String getRPY_TRGT_ACPT_NO_2() {
        return getData(RPY_TRGT_ACPT_NO_1);
    }

    public String getRPY_TRGT_BND_AMT_2() {
        return getData(RPY_TRGT_BND_AMT_1);
    }

    public String getRPY_TRGT_RNK_NO_3() {
        return getData(RPY_TRGT_RNK_NO_1);
    }


    public String getRPY_TRGT_ACPT_DT_3() {
        return getData(RPY_TRGT_ACPT_DT_1);
    }

    public String getRPY_TRGT_ACPT_NO_3() {
        return getData(RPY_TRGT_ACPT_NO_1);
    }

    public String getRPY_TRGT_BND_AMT_3() {
        return getData(RPY_TRGT_BND_AMT_1);
    }

    public String getRPY_TRGT_RNK_NO_4() {
        return getData(RPY_TRGT_RNK_NO_1);
    }


    public String getRPY_TRGT_ACPT_DT_4() {
        return getData(RPY_TRGT_ACPT_DT_1);
    }

    public String getRPY_TRGT_ACPT_NO_4() {
        return getData(RPY_TRGT_ACPT_NO_1);
    }

    public String getRPY_TRGT_BND_AMT_4() {
        return getData(RPY_TRGT_BND_AMT_1);
    }

    public String getRPY_TRGT_RNK_NO_5() {
        return getData(RPY_TRGT_RNK_NO_1);
    }


    public String getRPY_TRGT_ACPT_DT_5() {
        return getData(RPY_TRGT_ACPT_DT_1);
    }

    public String getRPY_TRGT_ACPT_NO_5() {
        return getData(RPY_TRGT_ACPT_NO_1);
    }

    public String getRPY_TRGT_BND_AMT_5() {
        return getData(RPY_TRGT_BND_AMT_1);
    }

    public String getAFRGSTR_SCRT_YN() {
        return getData(AFRGSTR_SCRT_YN);
    }

    public String getRSRV_ITM_B() {
        return getData(RSRV_ITM_B);
    }

    public void setTG_LEN(String TG_LEN) {
        setData(this.TG_LEN, TG_LEN, "N");
    }

    public void setTG_DSC(String TG_DSC) {
        setData(this.TG_DSC, TG_DSC, "S");
    }

    public void setBNK_TG_NO(String BNK_TG_NO) {
        setData(this.BNK_TG_NO, BNK_TG_NO, "S");
    }

    public void setFA_TG_NO(String FA_TG_NO) {
        setData(this.FA_TG_NO, FA_TG_NO, "S");
    }

    public void setKOS_TG_SND_NO(String KOS_TG_SND_NO) {
        setData(this.KOS_TG_SND_NO, KOS_TG_SND_NO, "S");
    }

    public void setTG_SND_DTM(String TG_SND_DTM) {
        setData(this.TG_SND_DTM, TG_SND_DTM, "S");
    }

    public void setTG_RCV_DTM(String TG_RCV_DTM) {
        setData(this.TG_RCV_DTM, TG_RCV_DTM, "S");
    }

    public void setRES_CD(String RES_CD) {
        setData(this.RES_CD, RES_CD, "S");
    }

    public void setRSRV_ITM_H(String RSRV_ITM_H) {
        setData(this.RSRV_ITM_H, RSRV_ITM_H, "S");
    }

    public void setBNK_TTL_REQ_NO(String BNK_TTL_REQ_NO) {
        setData(this.BNK_TTL_REQ_NO, BNK_TTL_REQ_NO, "S");
    }

    public void setLN_APRV_NO(String LN_APRV_NO) {
        setData(this.LN_APRV_NO, LN_APRV_NO, "S");
    }

    public void setTTL_ARD_ENTR_EANE(String TTL_ARD_ENTR_EANE) {
        setData(this.TTL_ARD_ENTR_EANE, TTL_ARD_ENTR_EANE, "S");
    }

    public void setTTL_ENTRCMPY(String TTL_ENTRCMPY) {
        setData(this.TTL_ENTRCMPY, TTL_ENTRCMPY, "S");
    }

    public void setTTL_SCRT_NO(String TTL_SCRT_NO) {
        setData(this.TTL_SCRT_NO, TTL_SCRT_NO, "S");
    }

    public void setLND_DSC(String LND_DSC) {
        setData(this.LND_DSC, LND_DSC, "S");
    }

    public void setLND_KND_CD(String LND_KIND_CD) {
        setData(this.LND_KND_CD, LND_KIND_CD, "S");
    }

    public void setFND_USE_CD(String FND_USE_CD) {
        setData(this.FND_USE_CD, FND_USE_CD, "S");
    }

    public void setBNK_LND_PRDT_CD(String LND_PRDT_CD) {
        setData(this.BNK_LND_PRDT_CD, LND_PRDT_CD, "S");
    }

    public void setBNK_LND_PRDT_NM(String BNK_LND_PRDT_NM) {
        setData(this.BNK_LND_PRDT_NM, BNK_LND_PRDT_NM, "K");
    }

    public void setGRNT_DSC(String GRNT_DSC) {
        setData(this.GRNT_DSC, GRNT_DSC, "S");
    }

    public void setSTND_APL_YN(String STND_APL_YN) {
        setData(this.STND_APL_YN, STND_APL_YN, "S");
    }

    public void setRRCP_CNFM_REQ_YN(String RRCP_CNFM_REQ_YN) {
        setData(this.RRCP_CNFM_REQ_YN, RRCP_CNFM_REQ_YN, "S");
    }

    public void setMVHR_CNFM_REQ_YN(String MVHR_CNFM_REQ_YN) {
        setData(this.MVHR_CNFM_REQ_YN, MVHR_CNFM_REQ_YN, "S");
    }

    public void setBF_SRVTRGT_REQ_YN(String BF_SRVTRGT_REQ_YN) {
        setData(this.BF_SRVTRGT_REQ_YN, BF_SRVTRGT_REQ_YN, "S");
    }

    public void setAF_SRVTRGT_REQ_YN(String AF_SRVTRGT_REQ_YN) {
        setData(this.AF_SRVTRGT_REQ_YN, AF_SRVTRGT_REQ_YN, "S");
    }

    public void setRGSTR_UNQ_NO_1(String RGSTR_UNQ_NO_1) {
        setData(this.RGSTR_UNQ_NO_1, RGSTR_UNQ_NO_1, "S");
    }

    public void setRGSTR_UNQ_NO_2(String RGSTR_UNQ_NO_2) {
        setData(this.RGSTR_UNQ_NO_2, RGSTR_UNQ_NO_2, "S");
    }

    public void setRGSTR_UNQ_NO_3(String RGSTR_UNQ_NO_3) {
        setData(this.RGSTR_UNQ_NO_3, RGSTR_UNQ_NO_3, "S");
    }

    public void setRGSTR_UNQ_NO_4(String RGSTR_UNQ_NO_4) {
        setData(this.RGSTR_UNQ_NO_4, RGSTR_UNQ_NO_4, "S");
    }

    public void setRGSTR_UNQ_NO_5(String RGSTR_UNQ_NO_5) {
        setData(this.RGSTR_UNQ_NO_5, RGSTR_UNQ_NO_5, "S");
    }

    public void setRLES_DSC(String RLES_DSC) {
        setData(this.RLES_DSC, RLES_DSC, "S");
    }

    public void setTRGT_RLES_DSC(String TRGT_RLES_DSC) {
        setData(this.TRGT_RLES_DSC, TRGT_RLES_DSC, "S");
    }

    public void setTRGT_RLES_ADDR(String TRGT_RLES_ADDR) {
        setData(this.TRGT_RLES_ADDR, TRGT_RLES_ADDR, "K");
    }

    public void setSSCPT_ASK_DT(String SSCPT_ASK_DT) {
        setData(this.SSCPT_ASK_DT, SSCPT_ASK_DT, "S");
    }

    public void setLND_PLN_DT(String LND_PLN_DT) {
        setData(this.LND_PLN_DT, LND_PLN_DT, "S");
    }

    public void setLND_EXPRD_DT(String LND_EXPRD_DT) {
        setData(this.LND_EXPRD_DT, LND_EXPRD_DT, "S");
    }

    public void setSL_PRC(String SL_PRC) {
        //setData(this.SL_PRC, SL_PRC);
        setData(this.SL_PRC, SL_PRC, "N");
    }

    public void setISRN_ENTR_AMT(String ISRN_ENTR_AMT) {
        setData(this.ISRN_ENTR_AMT, ISRN_ENTR_AMT, "N");
    }

    public void setLND_PRD(String LND_PRD) {
        setData(this.LND_PRD, LND_PRD, "N");
    }

    public void setLND_AMT(String LND_AMT) {
        //setData(this.LND_AMT, LND_AMT);
        setData(this.LND_AMT, LND_AMT, "N");

    }

    public void setBNK_FXCLT_RGSTR_RNK(String BNK_FXCLT_RGSTR_RNK) {
        //setData(this.BNK_FXCLT_RGSTR_RNK, BNK_FXCLT_RGSTR_RNK);
        setData(this.BNK_FXCLT_RGSTR_RNK, BNK_FXCLT_RGSTR_RNK, "N");
    }

    public void setBNK_FXCLT_BND_MAX_AMT(String BNK_FXCLT_BND_MAX_AMT) {
        //setData(this.BNK_FXCLT_BND_MAX_AMT, BNK_FXCLT_BND_MAX_AMT);
        setData(this.BNK_FXCLT_BND_MAX_AMT, BNK_FXCLT_BND_MAX_AMT, "N");
    }

    public void setDBTR_NM(String DBTR_NM) {
        setData(this.DBTR_NM, DBTR_NM, "K");
    }

    public void setDBTR_BIRTH_DT(String DBTR_BIRTH_DT) {
        setData(this.DBTR_BIRTH_DT, DBTR_BIRTH_DT, "S");
    }

    public void setDBTR_ADDR(String DBTR_ADDR) {
        setData(this.DBTR_ADDR, DBTR_ADDR, "K");
    }

    public void setDBTR_PHNO(String DBTR_PHNO) {
        setData(this.DBTR_PHNO, DBTR_PHNO, "S");
    }

    public void setDBTR_HPNO(String DBTR_HPNO) {
        setData(this.DBTR_HPNO, DBTR_HPNO, "S");
    }

    public void setPWPS_NM(String PWPS_NM) {
        setData(this.PWPS_NM, PWPS_NM, "K");
    }

    public void setPWPS_BIRTH_DT(String PWPS_BIRTH_DT) {
        setData(this.PWPS_BIRTH_DT, PWPS_BIRTH_DT, "S");
    }

    public void setPWPS_ADDR(String PWPS_ADDR) {
        setData(this.PWPS_ADDR, PWPS_ADDR, "K");
    }

    public void setPWPS_PHNO(String PWPS_PHNO) {
        setData(this.PWPS_PHNO, PWPS_PHNO, "S");
    }

    public void setPWPS_HPNO(String PWPS_HPNO) {
        setData(this.PWPS_HPNO, PWPS_HPNO, "S");
    }

    public void setRMK_FCT(String RMK_FCT) {
        setData(this.RMK_FCT, RMK_FCT, "K");
    }

    public void setLND_HNDG_SLF_DSC(String LND_HNDG_SLF_DSC) {
        setData(this.LND_HNDG_SLF_DSC, LND_HNDG_SLF_DSC, "S");
    }

    public void setBNK_BRNCH_NM(String BNK_BRNCH_NM) {
        setData(this.BNK_BRNCH_NM, BNK_BRNCH_NM, "K");
    }

    public void setBNK_DRCTR_NM(String BNK_DRCTR_NM) {
        setData(this.BNK_DRCTR_NM, BNK_DRCTR_NM, "K");
    }

    public void setBNK_BRNCH_PHNO(String BNK_BRNCH_PHNO) {
        setData(this.BNK_BRNCH_PHNO, BNK_BRNCH_PHNO, "S");
    }

    public void setBNK_DRCTR_HP(String BNK_DRCTR_HP) {
        setData(this.BNK_DRCTR_HP, BNK_DRCTR_HP, "S");
    }

    public void setBNK_BRNCH_FAX(String BNK_BRNCH_FAX) {
        setData(this.BNK_BRNCH_FAX, BNK_BRNCH_FAX, "S");
    }

    public void setBNK_BRNCH_ADDR(String BNK_BRNCH_ADDR) {
        setData(this.BNK_BRNCH_ADDR, BNK_BRNCH_ADDR, "K");
    }

    public void setSLMN_CMPY_NM(String SLMN_CMPY_NM) {
        setData(this.SLMN_CMPY_NM, SLMN_CMPY_NM, "K");
    }

    public void setSLMN_NM(String SLMN_NM) {
        setData(this.SLMN_NM, SLMN_NM, "K");
    }

    public void setSLMN_PHNO(String SLMN_PHNO) {
        setData(this.SLMN_PHNO, SLMN_PHNO, "S");
    }

    public void setLWFM_NM(String LWFM_NM) {
        setData(this.LWFM_NM, LWFM_NM, "K");
    }

    public void setLWFM_BIZNO(String LWFM_BIZNO) {
        setData(this.LWFM_BIZNO, LWFM_BIZNO, "S");
    }

    public void setDBTR_WDNG_PLN_YN(String DBTR_WDNG_PLN_YN) {
        setData(this.DBTR_WDNG_PLN_YN, DBTR_WDNG_PLN_YN, "S");
    }

    public void setRRCP_CNFM_YN(String RRCP_CNFM_YN) {
        setData(this.RRCP_CNFM_YN, RRCP_CNFM_YN, "S");
    }

    public void setSPUS_NM(String SPUS_NM) {
        setData(this.SPUS_NM, SPUS_NM, "K");
    }

    public void setWDNG_PLN_DT(String WDNG_PLN_DT) {
        setData(this.WDNG_PLN_DT, WDNG_PLN_DT, "S");
    }

    public void setRSCH_WK_DDLN_REQ_DT(String RSCH_WK_DDLN_REQ_DT) {
        setData(this.RSCH_WK_DDLN_REQ_DT, RSCH_WK_DDLN_REQ_DT, "S");
    }

    public void setISRN_PRMM(String ISRN_PRMM) {
        setData(this.ISRN_PRMM, ISRN_PRMM, "N");
    }

    public void setRFR_LN_APRV_NO(String RFR_LN_APRV_NO) {
        setData(this.RFR_LN_APRV_NO, RFR_LN_APRV_NO, "S");
    }

    public void setRGSTR_MTD_DSC(String RGSTR_MTD_DSC) {
        setData(this.RGSTR_MTD_DSC, RGSTR_MTD_DSC, "S");
    }

    public void setRGSTR_REQ_NO(String RGSTR_REQ_NO) {
        setData(this.RGSTR_REQ_NO, RGSTR_REQ_NO, "S");
    }

    public void setODPRT_RPY_EANE(String ODPRT_RPY_EANE) {
        setData(this.ODPRT_RPY_EANE, ODPRT_RPY_EANE, "S");
    }

    public void setELTN_ESTBS_LWYR_NM(String ELTN_ESTBS_LWYR_NM) {
        setData(this.ELTN_ESTBS_LWYR_NM, ELTN_ESTBS_LWYR_NM, "K");
    }

    public void setELTN_ESTBS_LWYR_BIZNO(String ELTN_ESTBS_LWYR_BIZNO) {
        setData(this.ELTN_ESTBS_LWYR_BIZNO, ELTN_ESTBS_LWYR_BIZNO, "S");
    }

    public void setELTN_RPY_LOA_APL_YN(String ELTN_RPY_LOA_APL_YN) {
        setData(this.ELTN_RPY_LOA_APL_YN, ELTN_RPY_LOA_APL_YN, "S");
    }

    public void setELTN_RPY_LOA_SQN(String ELTN_RPY_LOA_SQN) {
        setData(this.ELTN_RPY_LOA_SQN, ELTN_RPY_LOA_SQN, "S");
    }

    public void setELTN_RPY_LOA_CTFC_NO(String ELTN_RPY_LOA_CTFC_NO) {
        setData(this.ELTN_RPY_LOA_CTFC_NO, ELTN_RPY_LOA_CTFC_NO, "S");
    }

    public void setDFBNK_RPY_TOT_AMT(String DFBNK_RPY_TOT_AMT) {
        setData(this.DFBNK_RPY_TOT_AMT, DFBNK_RPY_TOT_AMT, "N");
    }

    public void setWHL_RPY_CNT(String WHL_RPY_CNT) {
        setData(this.WHL_RPY_CNT, WHL_RPY_CNT, "N");
    }

    public void setWHL_RPY_AMT(String WHL_RPY_AMT) {
        setData(this.WHL_RPY_AMT, WHL_RPY_AMT, "N");
    }

    public void setEBNK_RPY_TOT_AMT(String EBNK_RPY_TOT_AMT) {
        setData(this.EBNK_RPY_TOT_AMT, EBNK_RPY_TOT_AMT, "N");
    }

    public void setRPY_TRGT_RNK_NO_1(String RPY_TRGT_RNK_NO_1) {
        setData(this.RPY_TRGT_RNK_NO_1, RPY_TRGT_RNK_NO_1, "S");
    }

    public void setRPY_TRGT_ACPT_DT_1(String RPY_TRGT_ACPT_DT_1) {
        setData(this.RPY_TRGT_ACPT_DT_1, RPY_TRGT_ACPT_DT_1, "S");
    }

    public void setRPY_TRGT_ACPT_NO_1(String RPY_TRGT_ACPT_NO_1) {
        setData(this.RPY_TRGT_ACPT_NO_1, RPY_TRGT_ACPT_NO_1, "S");
    }

    public void setRPY_TRGT_BND_AMT_1(String RPY_TRGT_BND_AMT_1) {
        setData(this.RPY_TRGT_BND_AMT_1, RPY_TRGT_BND_AMT_1, "N");
    }

    public void setRPY_TRGT_RNK_NO_2(String RPY_TRGT_RNK_NO_2) {
        setData(this.RPY_TRGT_RNK_NO_2, RPY_TRGT_RNK_NO_2, "S");
    }

    public void setRPY_TRGT_ACPT_DT_2(String RPY_TRGT_ACPT_DT_2) {
        setData(this.RPY_TRGT_ACPT_DT_2, RPY_TRGT_ACPT_DT_2, "S");
    }

    public void setRPY_TRGT_ACPT_NO_2(String RPY_TRGT_ACPT_NO_2) {
        setData(this.RPY_TRGT_ACPT_NO_2, RPY_TRGT_ACPT_NO_2, "S");
    }

    public void setRPY_TRGT_BND_AMT_2(String RPY_TRGT_BND_AMT_2) {
        setData(this.RPY_TRGT_BND_AMT_2, RPY_TRGT_BND_AMT_2, "N");
    }

    public void setRPY_TRGT_RNK_NO_3(String RPY_TRGT_RNK_NO_3) {
        setData(this.RPY_TRGT_RNK_NO_3, RPY_TRGT_RNK_NO_3, "S");
    }

    public void setRPY_TRGT_ACPT_DT_3(String RPY_TRGT_ACPT_DT_3) {
        setData(this.RPY_TRGT_ACPT_DT_3, RPY_TRGT_ACPT_DT_3, "S");
    }

    public void setRPY_TRGT_ACPT_NO_3(String RPY_TRGT_ACPT_NO_3) {
        setData(this.RPY_TRGT_ACPT_NO_3, RPY_TRGT_ACPT_NO_3, "S");
    }

    public void setRPY_TRGT_BND_AMT_3(String RPY_TRGT_BND_AMT_3) {
        setData(this.RPY_TRGT_BND_AMT_3, RPY_TRGT_BND_AMT_3, "N");
    }

    public void setRPY_TRGT_RNK_NO_4(String RPY_TRGT_RNK_NO_4) {
        setData(this.RPY_TRGT_RNK_NO_4, RPY_TRGT_RNK_NO_4, "S");
    }

    public void setRPY_TRGT_ACPT_DT_4(String RPY_TRGT_ACPT_DT_4) {
        setData(this.RPY_TRGT_ACPT_DT_4, RPY_TRGT_ACPT_DT_4, "S");
    }

    public void setRPY_TRGT_ACPT_NO_4(String RPY_TRGT_ACPT_NO_4) {
        setData(this.RPY_TRGT_ACPT_NO_4, RPY_TRGT_ACPT_NO_4, "S");
    }

    public void setRPY_TRGT_BND_AMT_4(String RPY_TRGT_BND_AMT_4) {
        setData(this.RPY_TRGT_BND_AMT_4, RPY_TRGT_BND_AMT_4, "N");
    }

    public void setRPY_TRGT_RNK_NO_5(String RPY_TRGT_RNK_NO_5) {
        setData(this.RPY_TRGT_RNK_NO_5, RPY_TRGT_RNK_NO_5, "S");
    }

    public void setRPY_TRGT_ACPT_DT_5(String RPY_TRGT_ACPT_DT_5) {
        setData(this.RPY_TRGT_ACPT_DT_5, RPY_TRGT_ACPT_DT_5, "S");
    }

    public void setRPY_TRGT_ACPT_NO_5(String RPY_TRGT_ACPT_NO_5) {
        setData(this.RPY_TRGT_ACPT_NO_5, RPY_TRGT_ACPT_NO_5, "S");
    }

    public void setRPY_TRGT_BND_AMT_5(String RPY_TRGT_BND_AMT_5) {
        setData(this.RPY_TRGT_BND_AMT_5, RPY_TRGT_BND_AMT_5, "N");
    }

    public void setAFRGSTR_SCRT_YN(String AFRGSTR_SCRT_YN) {
        setData(this.AFRGSTR_SCRT_YN, AFRGSTR_SCRT_YN, "S");
    }

    public void setRSRV_ITM_B(String RSRV_ITM_B) {
        setData(this.RSRV_ITM_B, RSRV_ITM_B, "S");
    }


    public String dataToString() {
        return getData(TG_LEN) + getData(TG_DSC) + getData(BNK_TG_NO) + getData(FA_TG_NO) + getData(KOS_TG_SND_NO) +
                getData(TG_SND_DTM) + getData(TG_RCV_DTM) + getData(RES_CD) + getData(RSRV_ITM_H) + getData(BNK_TTL_REQ_NO) +
                getData(LN_APRV_NO) + getData(TTL_ARD_ENTR_EANE) + getData(TTL_ENTRCMPY) + getData(TTL_SCRT_NO) + getData(LND_DSC) +
                getData(LND_KND_CD) + getData(FND_USE_CD) + getData(BNK_LND_PRDT_CD) + getData(BNK_LND_PRDT_NM) + getData(GRNT_DSC) +
                getData(STND_APL_YN) + getData(RRCP_CNFM_REQ_YN) + getData(MVHR_CNFM_REQ_YN) + getData(BF_SRVTRGT_REQ_YN) + getData(AF_SRVTRGT_REQ_YN) +
                getData(RGSTR_UNQ_NO_1) + getData(RGSTR_UNQ_NO_2) + getData(RGSTR_UNQ_NO_3) + getData(RGSTR_UNQ_NO_4) + getData(RGSTR_UNQ_NO_5) +
                getData(RLES_DSC) + getData(TRGT_RLES_DSC) + getData(TRGT_RLES_ADDR) + getData(SSCPT_ASK_DT) + getData(LND_PLN_DT) +
                getData(LND_EXPRD_DT) + getData(SL_PRC) + getData(ISRN_ENTR_AMT) + getData(LND_PRD) + getData(LND_AMT) +
                getData(BNK_FXCLT_RGSTR_RNK) + getData(BNK_FXCLT_BND_MAX_AMT) + getData(DBTR_NM) + getData(DBTR_BIRTH_DT) + getData(DBTR_ADDR) +
                getData(DBTR_PHNO) + getData(DBTR_HPNO) + getData(PWPS_NM) + getData(PWPS_BIRTH_DT) + getData(PWPS_ADDR) +
                getData(PWPS_PHNO) + getData(PWPS_HPNO) + getData(RMK_FCT) + getData(LND_HNDG_SLF_DSC) + getData(BNK_BRNCH_NM) +
                getData(BNK_DRCTR_NM) + getData(BNK_BRNCH_PHNO) + getData(BNK_DRCTR_HP) + getData(BNK_BRNCH_FAX) + getData(BNK_BRNCH_ADDR) +
                getData(SLMN_CMPY_NM) + getData(SLMN_NM) + getData(SLMN_PHNO) + getData(LWFM_NM) + getData(LWFM_BIZNO) +
                getData(DBTR_WDNG_PLN_YN) + getData(RRCP_CNFM_YN) + getData(SPUS_NM) + getData(WDNG_PLN_DT) + getData(RSCH_WK_DDLN_REQ_DT) +
                getData(ISRN_PRMM) + getData(RFR_LN_APRV_NO) + getData(RGSTR_MTD_DSC) + getData(RGSTR_REQ_NO) + getData(ODPRT_RPY_EANE) +
                getData(ELTN_ESTBS_LWYR_NM) + getData(ELTN_ESTBS_LWYR_BIZNO) + getData(ELTN_RPY_LOA_APL_YN) + getData(ELTN_RPY_LOA_SQN) +
                getData(ELTN_RPY_LOA_CTFC_NO) + getData(WHL_RPY_CNT) + getData(WHL_RPY_AMT) + getData(EBNK_RPY_TOT_AMT) + getData(DFBNK_RPY_TOT_AMT) +
                getData(RPY_TRGT_RNK_NO_1) + getData(RPY_TRGT_ACPT_DT_1) + getData(RPY_TRGT_ACPT_NO_1) + getData(RPY_TRGT_BND_AMT_1) + getData(RPY_TRGT_RNK_NO_2) +
                getData(RPY_TRGT_ACPT_DT_2) + getData(RPY_TRGT_ACPT_NO_2) + getData(RPY_TRGT_BND_AMT_2) + getData(RPY_TRGT_RNK_NO_3) +
                getData(RPY_TRGT_ACPT_DT_3) + getData(RPY_TRGT_ACPT_NO_3) + getData(RPY_TRGT_BND_AMT_3) + getData(RPY_TRGT_RNK_NO_4) + getData(RPY_TRGT_ACPT_DT_4) +
                getData(RPY_TRGT_ACPT_NO_4) + getData(RPY_TRGT_BND_AMT_4) + getData(RPY_TRGT_RNK_NO_5) + getData(RPY_TRGT_ACPT_DT_5) + getData(RPY_TRGT_ACPT_NO_5) +
                getData(RPY_TRGT_BND_AMT_5) + getData(AFRGSTR_SCRT_YN) + getData(RSRV_ITM_B)
                ;
    }


    public String print() {

        StringBuffer sb = new StringBuffer();

        sb.append("TG_LEN        	 	: " + "\tSize " + TG_LEN.length + " : " + getData(TG_LEN) + "\n");
        sb.append("TG_DSC               : " + "\tSize " + TG_DSC.length + " : " + getData(TG_DSC) + "\n");
        sb.append("BNK_TG_NO            : " + "\tSize " + BNK_TG_NO.length + " : " + getData(BNK_TG_NO) + "\n");
        sb.append("FA_TG_NO             : " + "\tSize " + FA_TG_NO.length + " : " + getData(FA_TG_NO) + "\n");
        sb.append("KOS_TG_SND_NO        : " + "\tSize " + KOS_TG_SND_NO.length + " : " + getData(KOS_TG_SND_NO) + "\n");
        sb.append("TG_SND_DTM           : " + "\tSize " + TG_SND_DTM.length + " : " + getData(TG_SND_DTM) + "\n");
        sb.append("TG_RCV_DTM           : " + "\tSize " + TG_RCV_DTM.length + " : " + getData(TG_RCV_DTM) + "\n");
        sb.append("RES_CD               : " + "\tSize " + RES_CD.length + " : " + getData(RES_CD) + "\n");
        sb.append("RSRV_ITM_H           : " + "\tSize " + RSRV_ITM_H.length + " : " + getData(RSRV_ITM_H) + "\n");
        sb.append("BNK_TTL_REQ_NO       : " + "\tSize " + BNK_TTL_REQ_NO.length + " : " + getData(BNK_TTL_REQ_NO) + "\n");
        sb.append("LN_APRV_NO           : " + "\tSize " + LN_APRV_NO.length + " : " + getData(LN_APRV_NO) + "\n");
        sb.append("TTL_ARD_ENTR_EANE    : " + "\tSize " + TTL_ARD_ENTR_EANE.length + " : " + getData(TTL_ARD_ENTR_EANE) + "\n");
        sb.append("TTL_ENTRCMPY         : " + "\tSize " + TTL_ENTRCMPY.length + " : " + getData(TTL_ENTRCMPY) + "\n");
        sb.append("TTL_SCRT_NO          : " + "\tSize " + TTL_SCRT_NO.length + " : " + getData(TTL_SCRT_NO) + "\n");
        sb.append("LND_DSC              : " + "\tSize " + LND_DSC.length + " : " + getData(LND_DSC) + "\n");
        sb.append("LND_KND_CD           : " + "\tSize " + LND_KND_CD.length + " : " + getData(LND_KND_CD) + "\n");
        sb.append("FND_USE_CD           : " + "\tSize " + FND_USE_CD.length + " : " + getData(FND_USE_CD) + "\n");
        sb.append("BNK_LND_PRDT_CD      : " + "\tSize " + BNK_LND_PRDT_CD.length + " : " + getData(BNK_LND_PRDT_CD) + "\n");
        sb.append("BNK_LND_PRDT_NM      : " + "\tSize " + BNK_LND_PRDT_NM.length + " : " + getData(BNK_LND_PRDT_NM) + "\n");
        sb.append("GRNT_DSC             : " + "\tSize " + GRNT_DSC.length + " : " + getData(GRNT_DSC) + "\n");
        sb.append("STND_APL_YN          : " + "\tSize " + STND_APL_YN.length + " : " + getData(STND_APL_YN) + "\n");
        sb.append("RRCP_CNFM_REQ_YN     : " + "\tSize " + RRCP_CNFM_REQ_YN.length + " : " + getData(RRCP_CNFM_REQ_YN) + "\n");
        sb.append("MVHR_CNFM_REQ_YN     : " + "\tSize " + MVHR_CNFM_REQ_YN.length + " : " + getData(MVHR_CNFM_REQ_YN) + "\n");
        sb.append("BF_SRVTRGT_REQ_YN    : " + "\tSize " + BF_SRVTRGT_REQ_YN.length + " : " + getData(BF_SRVTRGT_REQ_YN) + "\n");
        sb.append("AF_SRVTRGT_REQ_YN    : " + "\tSize " + AF_SRVTRGT_REQ_YN.length + " : " + getData(AF_SRVTRGT_REQ_YN) + "\n");
        sb.append("RGSTR_UNQ_NO_1       : " + "\tSize " + RGSTR_UNQ_NO_1.length + " : " + getData(RGSTR_UNQ_NO_1) + "\n");
        sb.append("RGSTR_UNQ_NO_2       : " + "\tSize " + RGSTR_UNQ_NO_2.length + " : " + getData(RGSTR_UNQ_NO_2) + "\n");
        sb.append("RGSTR_UNQ_NO_3       : " + "\tSize " + RGSTR_UNQ_NO_3.length + " : " + getData(RGSTR_UNQ_NO_3) + "\n");
        sb.append("RGSTR_UNQ_NO_4       : " + "\tSize " + RGSTR_UNQ_NO_4.length + " : " + getData(RGSTR_UNQ_NO_4) + "\n");
        sb.append("RGSTR_UNQ_NO_5       : " + "\tSize " + RGSTR_UNQ_NO_5.length + " : " + getData(RGSTR_UNQ_NO_5) + "\n");
        sb.append("RLES_DSC             : " + "\tSize " + RLES_DSC.length + " : " + getData(RLES_DSC) + "\n");
        sb.append("TRGT_RLES_DSC        : " + "\tSize " + TRGT_RLES_DSC.length + " : " + getData(TRGT_RLES_DSC) + "\n");
        sb.append("TRGT_RLES_ADDR       : " + "\tSize " + TRGT_RLES_ADDR.length + " : " + getData(TRGT_RLES_ADDR) + "\n");
        sb.append("SSCPT_ASK_DT         : " + "\tSize " + SSCPT_ASK_DT.length + " : " + getData(SSCPT_ASK_DT) + "\n");
        sb.append("LND_PLN_DT           : " + "\tSize " + LND_PLN_DT.length + " : " + getData(LND_PLN_DT) + "\n");
        sb.append("LND_EXPRD_DT         : " + "\tSize " + LND_EXPRD_DT.length + " : " + getData(LND_EXPRD_DT) + "\n");
        sb.append("SL_PRC               : " + "\tSize " + SL_PRC.length + " : " + getData(SL_PRC) + "\n");
        sb.append("ISRN_ENTR_AMT        : " + "\tSize " + ISRN_ENTR_AMT.length + " : " + getData(ISRN_ENTR_AMT) + "\n");
        sb.append("LND_PRD              : " + "\tSize " + LND_PRD.length + " : " + getData(LND_PRD) + "\n");
        sb.append("LND_AMT              : " + "\tSize " + LND_AMT.length + " : " + getData(LND_AMT) + "\n");
        sb.append("BNK_FXCLT_RGSTR_RNK  : " + "\tSize " + BNK_FXCLT_RGSTR_RNK.length + " : " + getData(BNK_FXCLT_RGSTR_RNK) + "\n");
        sb.append("BNK_FXCLT_BND_MAX_AMT: " + "\tSize " + BNK_FXCLT_BND_MAX_AMT.length + " : " + getData(BNK_FXCLT_BND_MAX_AMT) + "\n");
        sb.append("DBTR_NM              : " + "\tSize " + DBTR_NM.length + " : " + getData(DBTR_NM) + "\n");
        sb.append("DBTR_BIRTH_DT        : " + "\tSize " + DBTR_BIRTH_DT.length + " : " + getData(DBTR_BIRTH_DT) + "\n");
        sb.append("DBTR_ADDR            : " + "\tSize " + DBTR_ADDR.length + " : " + getData(DBTR_ADDR) + "\n");
        sb.append("DBTR_PHNO            : " + "\tSize " + DBTR_PHNO.length + " : " + getData(DBTR_PHNO) + "\n");
        sb.append("DBTR_HPNO            : " + "\tSize " + DBTR_HPNO.length + " : " + getData(DBTR_HPNO) + "\n");
        sb.append("PWPS_NM              : " + "\tSize " + PWPS_NM.length + " : " + getData(PWPS_NM) + "\n");
        sb.append("PWPS_BIRTH_DT        : " + "\tSize " + PWPS_BIRTH_DT.length + " : " + getData(PWPS_BIRTH_DT) + "\n");
        sb.append("PWPS_ADDR            : " + "\tSize " + PWPS_ADDR.length + " : " + getData(PWPS_ADDR) + "\n");
        sb.append("PWPS_PHNO            : " + "\tSize " + PWPS_PHNO.length + " : " + getData(PWPS_PHNO) + "\n");
        sb.append("PWPS_HPNO            : " + "\tSize " + PWPS_HPNO.length + " : " + getData(PWPS_HPNO) + "\n");
        sb.append("RMK_FCT              : " + "\tSize " + RMK_FCT.length + " : " + getData(RMK_FCT) + "\n");
        sb.append("LND_HNDG_SLF_DSC     : " + "\tSize " + LND_HNDG_SLF_DSC.length + " : " + getData(LND_HNDG_SLF_DSC) + "\n");
        sb.append("BNK_BRNCH_NM         : " + "\tSize " + BNK_BRNCH_NM.length + " : " + getData(BNK_BRNCH_NM) + "\n");
        sb.append("BNK_DRCTR_NM         : " + "\tSize " + BNK_DRCTR_NM.length + " : " + getData(BNK_DRCTR_NM) + "\n");
        sb.append("BNK_BRNCH_PHNO       : " + "\tSize " + BNK_BRNCH_PHNO.length + " : " + getData(BNK_BRNCH_PHNO) + "\n");
        sb.append("BNK_DRCTR_HP         : " + "\tSize " + BNK_DRCTR_HP.length + " : " + getData(BNK_DRCTR_HP) + "\n");
        sb.append("BNK_BRNCH_FAX        : " + "\tSize " + BNK_BRNCH_FAX.length + " : " + getData(BNK_BRNCH_FAX) + "\n");
        sb.append("BNK_BRNCH_ADDR       : " + "\tSize " + BNK_BRNCH_ADDR.length + " : " + getData(BNK_BRNCH_ADDR) + "\n");
        sb.append("SLMN_CMPY_NM         : " + "\tSize " + SLMN_CMPY_NM.length + " : " + getData(SLMN_CMPY_NM) + "\n");
        sb.append("SLMN_NM              : " + "\tSize " + SLMN_NM.length + " : " + getData(SLMN_NM) + "\n");
        sb.append("SLMN_PHNO            : " + "\tSize " + SLMN_PHNO.length + " : " + getData(SLMN_PHNO) + "\n");
        sb.append("LWFM_NM              : " + "\tSize " + LWFM_NM.length + " : " + getData(LWFM_NM) + "\n");
        sb.append("LWFM_BIZNO           : " + "\tSize " + LWFM_BIZNO.length + " : " + getData(LWFM_BIZNO) + "\n");
        sb.append("DBTR_WDNG_PLN_YN     : " + "\tSize " + DBTR_WDNG_PLN_YN.length + " : " + getData(DBTR_WDNG_PLN_YN) + "\n");
        sb.append("RRCP_CNFM_YN         : " + "\tSize " + RRCP_CNFM_YN.length + " : " + getData(RRCP_CNFM_YN) + "\n");
        sb.append("SPUS_NM              : " + "\tSize " + SPUS_NM.length + " : " + getData(SPUS_NM) + "\n");
        sb.append("WDNG_PLN_DT          : " + "\tSize " + WDNG_PLN_DT.length + " : " + getData(WDNG_PLN_DT) + "\n");
        sb.append("RSCH_WK_DDLN_REQ_DT  : " + "\tSize " + RSCH_WK_DDLN_REQ_DT.length + " : " + getData(RSCH_WK_DDLN_REQ_DT) + "\n");
        sb.append("ISRN_PRMM            : " + "\tSize " + ISRN_PRMM.length + " : " + getData(ISRN_PRMM) + "\n");
        sb.append("RFR_LN_APRV_NO       : " + "\tSize " + RFR_LN_APRV_NO.length + " : " + getData(RFR_LN_APRV_NO) + "\n");
        sb.append("RGSTR_MTD_DSC        : " + "\tSize " + RGSTR_MTD_DSC.length + " : " + getData(RGSTR_MTD_DSC) + "\n");
        sb.append("RGSTR_REQ_NO         : " + "\tSize " + RGSTR_REQ_NO.length + " : " + getData(RGSTR_REQ_NO) + "\n");
        sb.append("ODPRT_RPY_EANE       : " + "\tSize " + ODPRT_RPY_EANE.length + " : " + getData(ODPRT_RPY_EANE) + "\n");
        sb.append("ELTN_ESTBS_LWYR_NM   : " + "\tSize " + ELTN_ESTBS_LWYR_NM.length + " : " + getData(ELTN_ESTBS_LWYR_NM) + "\n");
        sb.append("ELTN_ESTBS_LWYR_BIZNO: " + "\tSize " + ELTN_ESTBS_LWYR_BIZNO.length + " : " + getData(ELTN_ESTBS_LWYR_BIZNO) + "\n");
        sb.append("ELTN_RPY_LOA_APL_YN  : " + "\tSize " + ELTN_RPY_LOA_APL_YN.length + " : " + getData(ELTN_RPY_LOA_APL_YN) + "\n");
        sb.append("ELTN_RPY_LOA_SQN     : " + "\tSize " + ELTN_RPY_LOA_SQN.length + " : " + getData(ELTN_RPY_LOA_SQN) + "\n");
        sb.append("ELTN_RPY_LOA_CTFC_NO : " + "\tSize " + ELTN_RPY_LOA_CTFC_NO.length + " : " + getData(ELTN_RPY_LOA_CTFC_NO) + "\n");
        sb.append("WHL_RPY_CNT          : " + "\tSize " + WHL_RPY_CNT.length + " : " + getData(WHL_RPY_CNT) + "\n");
        sb.append("WHL_RPY_AMT          : " + "\tSize " + WHL_RPY_AMT.length + " : " + getData(WHL_RPY_AMT) + "\n");
        sb.append("EBNK_RPY_TOT_AMT     : " + "\tSize " + EBNK_RPY_TOT_AMT.length + " : " + getData(EBNK_RPY_TOT_AMT) + "\n");
        sb.append("DFBNK_RPY_TOT_AMT    : " + "\tSize " + DFBNK_RPY_TOT_AMT.length + " : " + getData(DFBNK_RPY_TOT_AMT) + "\n");
        sb.append("RPY_TRGT_RNK_NO_1    : " + "\tSize " + RPY_TRGT_RNK_NO_1.length + " : " + getData(RPY_TRGT_RNK_NO_1) + "\n");
        sb.append("RPY_TRGT_ACPT_DT_1   : " + "\tSize " + RPY_TRGT_ACPT_DT_1.length + " : " + getData(RPY_TRGT_ACPT_DT_1) + "\n");
        sb.append("RPY_TRGT_ACPT_NO_1   : " + "\tSize " + RPY_TRGT_ACPT_NO_1.length + " : " + getData(RPY_TRGT_ACPT_NO_1) + "\n");
        sb.append("RPY_TRGT_BND_AMT_1   : " + "\tSize " + RPY_TRGT_BND_AMT_1.length + " : " + getData(RPY_TRGT_BND_AMT_1) + "\n");
        sb.append("RPY_TRGT_RNK_NO_2    : " + "\tSize " + RPY_TRGT_RNK_NO_2.length + " : " + getData(RPY_TRGT_RNK_NO_2) + "\n");
        sb.append("RPY_TRGT_ACPT_DT_2   : " + "\tSize " + RPY_TRGT_ACPT_DT_2.length + " : " + getData(RPY_TRGT_ACPT_DT_2) + "\n");
        sb.append("RPY_TRGT_ACPT_NO_2   : " + "\tSize " + RPY_TRGT_ACPT_NO_2.length + " : " + getData(RPY_TRGT_ACPT_NO_2) + "\n");
        sb.append("RPY_TRGT_BND_AMT_2   : " + "\tSize " + RPY_TRGT_BND_AMT_2.length + " : " + getData(RPY_TRGT_BND_AMT_2) + "\n");
        sb.append("RPY_TRGT_RNK_NO_3    : " + "\tSize " + RPY_TRGT_RNK_NO_3.length + " : " + getData(RPY_TRGT_RNK_NO_3) + "\n");
        sb.append("RPY_TRGT_ACPT_DT_3   : " + "\tSize " + RPY_TRGT_ACPT_DT_3.length + " : " + getData(RPY_TRGT_ACPT_DT_3) + "\n");
        sb.append("RPY_TRGT_ACPT_NO_3   : " + "\tSize " + RPY_TRGT_ACPT_NO_3.length + " : " + getData(RPY_TRGT_ACPT_NO_3) + "\n");
        sb.append("RPY_TRGT_BND_AMT_3   : " + "\tSize " + RPY_TRGT_BND_AMT_3.length + " : " + getData(RPY_TRGT_BND_AMT_3) + "\n");
        sb.append("RPY_TRGT_RNK_NO_4    : " + "\tSize " + RPY_TRGT_RNK_NO_4.length + " : " + getData(RPY_TRGT_RNK_NO_4) + "\n");
        sb.append("RPY_TRGT_ACPT_DT_4   : " + "\tSize " + RPY_TRGT_ACPT_DT_4.length + " : " + getData(RPY_TRGT_ACPT_DT_4) + "\n");
        sb.append("RPY_TRGT_ACPT_NO_4   : " + "\tSize " + RPY_TRGT_ACPT_NO_4.length + " : " + getData(RPY_TRGT_ACPT_NO_4) + "\n");
        sb.append("RPY_TRGT_BND_AMT_4   : " + "\tSize " + RPY_TRGT_BND_AMT_4.length + " : " + getData(RPY_TRGT_BND_AMT_4) + "\n");
        sb.append("RPY_TRGT_RNK_NO_5    : " + "\tSize " + RPY_TRGT_RNK_NO_5.length + " : " + getData(RPY_TRGT_RNK_NO_5) + "\n");
        sb.append("RPY_TRGT_ACPT_DT_5   : " + "\tSize " + RPY_TRGT_ACPT_DT_5.length + " : " + getData(RPY_TRGT_ACPT_DT_5) + "\n");
        sb.append("RPY_TRGT_ACPT_NO_5   : " + "\tSize " + RPY_TRGT_ACPT_NO_5.length + " : " + getData(RPY_TRGT_ACPT_NO_5) + "\n");
        sb.append("RPY_TRGT_BND_AMT_5   : " + "\tSize " + RPY_TRGT_BND_AMT_5.length + " : " + getData(RPY_TRGT_BND_AMT_5) + "\n");
        sb.append("AFRGSTR_SCRT_YN      : " + "\tSize " + AFRGSTR_SCRT_YN.length + " : " + getData(AFRGSTR_SCRT_YN) + "\n");
        sb.append("RSRV_ITM_B           : " + "\tSize " + RSRV_ITM_B.length + " : " + getData(RSRV_ITM_B) + "\n");
        return sb.toString();
    }

    public void readDataStream(InputStream stream) {
        try {
            stream.read(TG_LEN, 0, TG_LEN.length);
            stream.read(TG_DSC, 0, TG_DSC.length);
            stream.read(BNK_TG_NO, 0, BNK_TG_NO.length);
            stream.read(FA_TG_NO, 0, FA_TG_NO.length);
            stream.read(KOS_TG_SND_NO, 0, KOS_TG_SND_NO.length);
            stream.read(TG_SND_DTM, 0, TG_SND_DTM.length);
            stream.read(TG_RCV_DTM, 0, TG_RCV_DTM.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(RSRV_ITM_H, 0, RSRV_ITM_H.length);
            stream.read(BNK_TTL_REQ_NO, 0, BNK_TTL_REQ_NO.length);
            stream.read(LN_APRV_NO, 0, LN_APRV_NO.length);
            stream.read(TTL_ARD_ENTR_EANE, 0, TTL_ARD_ENTR_EANE.length);
            stream.read(TTL_ENTRCMPY, 0, TTL_ENTRCMPY.length);
            stream.read(TTL_SCRT_NO, 0, TTL_SCRT_NO.length);
            stream.read(LND_DSC, 0, LND_DSC.length);
            stream.read(LND_KND_CD, 0, LND_KND_CD.length);
            stream.read(FND_USE_CD, 0, FND_USE_CD.length);
            stream.read(BNK_LND_PRDT_CD, 0, BNK_LND_PRDT_CD.length);
            stream.read(BNK_LND_PRDT_NM, 0, BNK_LND_PRDT_NM.length);
            stream.read(GRNT_DSC, 0, GRNT_DSC.length);
            stream.read(STND_APL_YN, 0, STND_APL_YN.length);
            stream.read(RRCP_CNFM_REQ_YN, 0, RRCP_CNFM_REQ_YN.length);
            stream.read(MVHR_CNFM_REQ_YN, 0, MVHR_CNFM_REQ_YN.length);
            stream.read(BF_SRVTRGT_REQ_YN, 0, BF_SRVTRGT_REQ_YN.length);
            stream.read(AF_SRVTRGT_REQ_YN, 0, AF_SRVTRGT_REQ_YN.length);
            stream.read(RGSTR_UNQ_NO_1, 0, RGSTR_UNQ_NO_1.length);
            stream.read(RGSTR_UNQ_NO_2, 0, RGSTR_UNQ_NO_2.length);
            stream.read(RGSTR_UNQ_NO_3, 0, RGSTR_UNQ_NO_3.length);
            stream.read(RGSTR_UNQ_NO_4, 0, RGSTR_UNQ_NO_4.length);
            stream.read(RGSTR_UNQ_NO_5, 0, RGSTR_UNQ_NO_5.length);
            stream.read(RLES_DSC, 0, RLES_DSC.length);
            stream.read(TRGT_RLES_DSC, 0, TRGT_RLES_DSC.length);
            stream.read(TRGT_RLES_ADDR, 0, TRGT_RLES_ADDR.length);
            stream.read(SSCPT_ASK_DT, 0, SSCPT_ASK_DT.length);
            stream.read(LND_PLN_DT, 0, LND_PLN_DT.length);
            stream.read(LND_EXPRD_DT, 0, LND_EXPRD_DT.length);
            stream.read(SL_PRC, 0, SL_PRC.length);
            stream.read(ISRN_ENTR_AMT, 0, ISRN_ENTR_AMT.length);
            stream.read(LND_PRD, 0, LND_PRD.length);
            stream.read(LND_AMT, 0, LND_AMT.length);
            stream.read(BNK_FXCLT_RGSTR_RNK, 0, BNK_FXCLT_RGSTR_RNK.length);
            stream.read(BNK_FXCLT_BND_MAX_AMT, 0, BNK_FXCLT_BND_MAX_AMT.length);
            stream.read(DBTR_NM, 0, DBTR_NM.length);
            stream.read(DBTR_BIRTH_DT, 0, DBTR_BIRTH_DT.length);
            stream.read(DBTR_ADDR, 0, DBTR_ADDR.length);
            stream.read(DBTR_PHNO, 0, DBTR_PHNO.length);
            stream.read(DBTR_HPNO, 0, DBTR_HPNO.length);
            stream.read(PWPS_NM, 0, PWPS_NM.length);
            stream.read(PWPS_BIRTH_DT, 0, PWPS_BIRTH_DT.length);
            stream.read(PWPS_ADDR, 0, PWPS_ADDR.length);
            stream.read(PWPS_PHNO, 0, PWPS_PHNO.length);
            stream.read(PWPS_HPNO, 0, PWPS_HPNO.length);
            stream.read(RMK_FCT, 0, RMK_FCT.length);
            stream.read(LND_HNDG_SLF_DSC, 0, LND_HNDG_SLF_DSC.length);
            stream.read(BNK_BRNCH_NM, 0, BNK_BRNCH_NM.length);
            stream.read(BNK_DRCTR_NM, 0, BNK_DRCTR_NM.length);
            stream.read(BNK_BRNCH_PHNO, 0, BNK_BRNCH_PHNO.length);
            stream.read(BNK_DRCTR_HP, 0, BNK_DRCTR_HP.length);
            stream.read(BNK_BRNCH_FAX, 0, BNK_BRNCH_FAX.length);
            stream.read(BNK_BRNCH_ADDR, 0, BNK_BRNCH_ADDR.length);
            stream.read(SLMN_CMPY_NM, 0, SLMN_CMPY_NM.length);
            stream.read(SLMN_NM, 0, SLMN_NM.length);
            stream.read(SLMN_PHNO, 0, SLMN_PHNO.length);
            stream.read(LWFM_NM, 0, LWFM_NM.length);
            stream.read(LWFM_BIZNO, 0, LWFM_BIZNO.length);
            stream.read(DBTR_WDNG_PLN_YN, 0, DBTR_WDNG_PLN_YN.length);
            stream.read(RRCP_CNFM_YN, 0, RRCP_CNFM_YN.length);
            stream.read(SPUS_NM, 0, SPUS_NM.length);
            stream.read(WDNG_PLN_DT, 0, WDNG_PLN_DT.length);
            stream.read(RSCH_WK_DDLN_REQ_DT, 0, RSCH_WK_DDLN_REQ_DT.length);
            stream.read(ISRN_PRMM, 0, ISRN_PRMM.length);
            stream.read(RFR_LN_APRV_NO, 0, RFR_LN_APRV_NO.length);
            stream.read(RGSTR_MTD_DSC, 0, RGSTR_MTD_DSC.length);
            stream.read(RGSTR_REQ_NO, 0, RGSTR_REQ_NO.length);
            stream.read(ODPRT_RPY_EANE, 0, ODPRT_RPY_EANE.length);
            stream.read(ELTN_ESTBS_LWYR_NM, 0, ELTN_ESTBS_LWYR_NM.length);
            stream.read(ELTN_ESTBS_LWYR_BIZNO, 0, ELTN_ESTBS_LWYR_BIZNO.length);
            stream.read(ELTN_RPY_LOA_APL_YN, 0, ELTN_RPY_LOA_APL_YN.length);
            stream.read(ELTN_RPY_LOA_SQN, 0, ELTN_RPY_LOA_SQN.length);
            stream.read(ELTN_RPY_LOA_CTFC_NO, 0, ELTN_RPY_LOA_CTFC_NO.length);
            stream.read(WHL_RPY_CNT, 0, WHL_RPY_CNT.length);
            stream.read(WHL_RPY_AMT, 0, WHL_RPY_AMT.length);
            stream.read(EBNK_RPY_TOT_AMT, 0, EBNK_RPY_TOT_AMT.length);
            stream.read(DFBNK_RPY_TOT_AMT, 0, DFBNK_RPY_TOT_AMT.length);
            stream.read(RPY_TRGT_RNK_NO_1, 0, RPY_TRGT_RNK_NO_1.length);
            stream.read(RPY_TRGT_ACPT_DT_1, 0, RPY_TRGT_ACPT_DT_1.length);
            stream.read(RPY_TRGT_ACPT_NO_1, 0, RPY_TRGT_ACPT_NO_1.length);
            stream.read(RPY_TRGT_BND_AMT_1, 0, RPY_TRGT_BND_AMT_1.length);
            stream.read(RPY_TRGT_RNK_NO_2, 0, RPY_TRGT_RNK_NO_2.length);
            stream.read(RPY_TRGT_ACPT_DT_2, 0, RPY_TRGT_ACPT_DT_2.length);
            stream.read(RPY_TRGT_ACPT_NO_2, 0, RPY_TRGT_ACPT_NO_2.length);
            stream.read(RPY_TRGT_BND_AMT_2, 0, RPY_TRGT_BND_AMT_2.length);
            stream.read(RPY_TRGT_RNK_NO_3, 0, RPY_TRGT_RNK_NO_3.length);
            stream.read(RPY_TRGT_ACPT_DT_3, 0, RPY_TRGT_ACPT_DT_3.length);
            stream.read(RPY_TRGT_ACPT_NO_3, 0, RPY_TRGT_ACPT_NO_3.length);
            stream.read(RPY_TRGT_BND_AMT_3, 0, RPY_TRGT_BND_AMT_3.length);
            stream.read(RPY_TRGT_RNK_NO_4, 0, RPY_TRGT_RNK_NO_4.length);
            stream.read(RPY_TRGT_ACPT_DT_4, 0, RPY_TRGT_ACPT_DT_4.length);
            stream.read(RPY_TRGT_ACPT_NO_4, 0, RPY_TRGT_ACPT_NO_4.length);
            stream.read(RPY_TRGT_BND_AMT_4, 0, RPY_TRGT_BND_AMT_4.length);
            stream.read(RPY_TRGT_RNK_NO_5, 0, RPY_TRGT_RNK_NO_5.length);
            stream.read(RPY_TRGT_ACPT_DT_5, 0, RPY_TRGT_ACPT_DT_5.length);
            stream.read(RPY_TRGT_ACPT_NO_5, 0, RPY_TRGT_ACPT_NO_5.length);
            stream.read(RPY_TRGT_BND_AMT_5, 0, RPY_TRGT_BND_AMT_5.length);
            stream.read(AFRGSTR_SCRT_YN, 0, AFRGSTR_SCRT_YN.length);
            stream.read(RSRV_ITM_B, 0, RSRV_ITM_B.length);
        } catch (Exception Ex) {
            Ex.printStackTrace();
        }
    }
}
