package com.bankle.common.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_CNTR_MASTER")
public class TbWoCntrMaster {
    @Id
    @Size(max = 11)
    @Column(name = "LOAN_NO", nullable = false, length = 11)
    private String loanNo;

    @Size(max = 10)
    @NotNull
    @Column(name = "BIZ_NO", nullable = false, length = 10)
    private String bizNo;

    @Size(max = 4)
    @NotNull
    @Column(name = "ISRN_GB_CD", nullable = false, length = 4)
    private String isrnGbCd;

    @Size(max = 6)
    @Column(name = "BNK_BRNCH_CD", length = 6)
    private String bnkBrnchCd;

    @Size(max = 3)
    @Column(name = "BNK_GB_CD", length = 3)
    private String bnkGbCd;

    @Size(max = 50)
    @Column(name = "BNK_BRNCH_NM", length = 50)
    private String bnkBrnchNm;

    @Size(max = 50)
    @Column(name = "BNK_DRCTR_NM", length = 50)
    private String bnkDrctrNm;

    @Size(max = 14)
    @Column(name = "BNK_BRNCH_PHNO", length = 14)
    private String bnkBrnchPhno;

    @Size(max = 2)
    @Column(name = "LND_KND_CD", length = 2)
    private String lndKndCd;

    @Size(max = 2)
    @Column(name = "STAT_CD", length = 2)
    private String statCd;

    @Size(max = 3)
    @Column(name = "LND_STAT_CD", length = 3)
    private String lndStatCd;

    @Size(max = 2)
    @Column(name = "RGSTR_GB_CD", length = 2)
    private String rgstrGbCd;

    @Size(max = 200)
    @Column(name = "LND_PRDT_NM", length = 200)
    private String lndPrdtNm;

    @Size(max = 50)
    @Column(name = "DBTR_NM", length = 50)
    private String dbtrNm;

    @Size(max = 13)
    @Column(name = "DBTR_BIRTH_DT", length = 13)
    private String dbtrBirthDt;

    @Size(max = 300)
    @Column(name = "DBTR_ADDR", length = 300)
    private String dbtrAddr;

    @Size(max = 14)
    @Column(name = "DBTR_HPNO", length = 14)
    private String dbtrHpno;

    @Size(max = 50)
    @Column(name = "PWPS_NM", length = 50)
    private String pwpsNm;

    @Size(max = 13)
    @Column(name = "PWPS_BIRTH_DT", length = 13)
    private String pwpsBirthDt;

    @Size(max = 14)
    @Column(name = "PWPS_HPNO", length = 14)
    private String pwpsHpno;

    @ColumnDefault("0")
    @Column(name = "EXEC_PLN_AMT", precision = 50)
    private BigDecimal execPlnAmt;

    @Size(max = 13)
    @Column(name = "EXEC_PLN_DT", length = 13)
    private String execPlnDt;

    @ColumnDefault("0")
    @Column(name = "EXEC_AMT", precision = 50)
    private BigDecimal execAmt;

    @Size(max = 13)
    @Column(name = "EXEC_DT", length = 13)
    private String execDt;

    @Column(name = "SL_PRC", precision = 15)
    private BigDecimal slPrc;

    @Column(name = "ISRN_ENTR_AMT", precision = 15)
    private BigDecimal isrnEntrAmt;

    @Size(max = 3)
    @Column(name = "LWYR_DIFF_BANK_CD_1", length = 3)
    private String lwyrDiffBankCd1;

    @Size(max = 3)
    @Column(name = "LWYR_DIFF_BANK_CD_2", length = 3)
    private String lwyrDiffBankCd2;

    @Size(max = 3)
    @Column(name = "LWYR_DIFF_BANK_CD_3", length = 3)
    private String lwyrDiffBankCd3;

    @Size(max = 3)
    @Column(name = "LWYR_DIFF_BANK_CD_4", length = 3)
    private String lwyrDiffBankCd4;

    @Size(max = 3)
    @Column(name = "LWYR_DIFF_BANK_CD_5", length = 3)
    private String lwyrDiffBankCd5;

    @Size(max = 3)
    @Column(name = "LWYR_DIFF_BANK_CD_6", length = 3)
    private String lwyrDiffBankCd6;

    @Size(max = 3)
    @Column(name = "LWYR_DIFF_BANK_CD_7", length = 3)
    private String lwyrDiffBankCd7;

    @Size(max = 3)
    @Column(name = "LWYR_DIFF_BANK_CD_8", length = 3)
    private String lwyrDiffBankCd8;

    @Size(max = 3)
    @Column(name = "LWYR_DIFF_BANK_CD_9", length = 3)
    private String lwyrDiffBankCd9;

    @Size(max = 3)
    @Column(name = "LWYR_DIFF_BANK_CD_1_0", length = 3)
    private String lwyrDiffBankCd10;

    @Size(max = 300)
    @Column(name = "ERSU_CLS_MSG", length = 300)
    private String ersuClsMsg;

    @Size(max = 10)
    @Column(name = "EBTS_LWYR_BIZNO", length = 10)
    private String ebtsLwyrBizno;

    @Size(max = 60)
    @Column(name = "REGO_NM", length = 60)
    private String regoNm;

    @Column(name = "RGSTR_ACPT_DTM")
    private LocalDateTime rgstrAcptDtm;

    @Size(max = 27)
    @Column(name = "IMG_KEY", length = 27)
    private String imgKey;

    @Size(max = 1)
    @Column(name = "KND_CD", length = 1)
    private String kndCd;

    @Size(max = 200)
    @Column(name = "LND_THNG_ADDR", length = 200)
    private String lndThngAddr;

    @Size(max = 20)
    @Column(name = "CCRST_ACPT_NUM", length = 20)
    private String ccrstAcptNum;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "CLSCT_SCTRT_BPR_REG_YN", length = 1)
    private String clsctSctrtBprRegYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "CCRST_BPR_REG_YN", length = 1)
    private String ccrstBprRegYn;

    @Size(max = 1)
    @Column(name = "BLNC_FPYMN_RCPT", length = 1)
    private String blncFpymnRcpt;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "REGIF_BPR_REG_YN", length = 1)
    private String regifBprRegYn;

    @Size(max = 10)
    @Column(name = "ELREG_BIZ_NO", length = 10)
    private String elregBizNo;

    @Size(max = 200)
    @Column(name = "RDNM_INCL_ADDR", length = 200)
    private String rdnmInclAddr;

    @Size(max = 200)
    @Column(name = "RDNM_STND_ADDR", length = 200)
    private String rdnmStndAddr;

    @Size(max = 11)
    @Column(name = "GRP_NO", length = 11)
    private String grpNo;

    @Lob
    @Column(name = "RMK")
    private String rmk;

    @Size(max = 2)
    @Column(name = "INS_DVSN", length = 2)
    private String insDvsn;

    @ColumnDefault("0")
    @Column(name = "TRN_IN_CNT")
    private Long trnInCnt;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "REFND_ACCT_REG_YN", length = 1)
    private String refndAcctRegYn;

    @Size(max = 8)
    @Column(name = "REFND_ACCT_REG_DATE", length = 8)
    private String refndAcctRegDate;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "ELTN_SECURED_YN", length = 1)
    private String eltnSecuredYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "EXEC_AMT_CHANG_YN", length = 1)
    private String execAmtChangYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "ESTM_REG_YN", length = 1)
    private String estmRegYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "RGSTR_REG_YN", length = 1)
    private String rgstrRegYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "PAY_REG_YN", length = 1)
    private String payRegYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "ESTM_CNFM_YN", length = 1)
    private String estmCnfmYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "LND_AMT_PAY_YN", length = 1)
    private String lndAmtPayYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "REVISION_CHECK_YN", length = 1)
    private String revisionCheckYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "ESTBS_CNTR_FN_YN", length = 1)
    private String estbsCntrFnYn;

    @Size(max = 1)
    @Column(name = "SL_CNTRCT_EANE", length = 1)
    private String slCntrctEane;

    @Size(max = 50)
    @Column(name = "SL_CNTRCT_FLNM", length = 50)
    private String slCntrctFlnm;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "MVHHD_SBMT_YN", length = 1)
    private String mvhhdSbmtYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "RRCP_SBMT_YN", length = 1)
    private String rrcpSbmtYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "RTAL_SBMT_YN", length = 1)
    private String rtalSbmtYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "CNDT_CNTR_YN", length = 1)
    private String cndtCntrYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "RGSTR_ACPT_SBMT_YN", length = 1)
    private String rgstrAcptSbmtYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "CNVNT_LWYR_YN", length = 1)
    private String cnvntLwyrYn;

    @Size(max = 13)
    @Column(name = "RSCH_WK_DDLN_REQ_DT", length = 13)
    private String rschWkDdlnReqDt;

    @Size(max = 100)
    @Column(name = "SSCPT_ASK_DT", length = 100)
    private String sscptAskDt;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "RRCP_CNFM_REQ_YN", length = 1)
    private String rrcpCnfmReqYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "MVHHD_CNFM_REQ_YN", length = 1)
    private String mvhhdCnfmReqYn;

    @Size(max = 3)
    @ColumnDefault("'N'")
    @Column(name = "RVSN_CNTRCT_CHRG_TRGT_YN", length = 3)
    private String rvsnCntrctChrgTrgtYn;

    @Size(max = 3)
    @Column(name = "STND_APL_YN", length = 3)
    private String stndAplYn;

    @Size(max = 3)
    @ColumnDefault("'2'")
    @Column(name = "BEF_DBSMT_CNCL_CD", length = 3)
    private String befDbsmtCnclCd;

    @Size(max = 3)
    @ColumnDefault("'N'")
    @Column(name = "ELREG_YN", length = 3)
    private String elregYn;

    @Size(max = 20)
    @Column(name = "BNK_TTL_REQ_NO", length = 20)
    private String bnkTtlReqNo;

    @Size(max = 2)
    @Column(name = "FND_USE_CD", length = 2)
    private String fndUseCd;

    @Size(max = 3)
    @ColumnDefault("'N'")
    @Column(name = "OFF_RGSTR_YN", length = 3)
    private String offRgstrYn;

    @Size(max = 3)
    @ColumnDefault("'N'")
    @Column(name = "A300_SEND", length = 3)
    private String a300Send;

    @Size(max = 1)
    @Column(name = "LND_HNDG_SLF_DSC", length = 1)
    private String lndHndgSlfDsc;

    @Size(max = 50)
    @Column(name = "SLMN_CMPY_NM", length = 50)
    private String slmnCmpyNm;

    @Size(max = 50)
    @Column(name = "SLMN_NM", length = 50)
    private String slmnNm;

    @Size(max = 14)
    @Column(name = "SLMN_PHNO", length = 14)
    private String slmnPhno;

    @Size(max = 2)
    @Column(name = "SLMN_LND_PROC", length = 2)
    private String slmnLndProc;

    @Size(max = 10)
    @Column(name = "SR_MEMB_NO", length = 10)
    private String srMembNo;

    @Column(name = "TR_AMT", precision = 15)
    private BigDecimal trAmt;

    @Size(max = 50)
    @Column(name = "SELLER_NM_1", length = 50)
    private String sellerNm1;

    @Size(max = 6)
    @Column(name = "SELLER_BIRTH_DT_1", length = 6)
    private String sellerBirthDt1;

    @Size(max = 50)
    @Column(name = "SELLER_NM_2", length = 50)
    private String sellerNm2;

    @Size(max = 6)
    @Column(name = "SELLER_BIRTH_DT_2", length = 6)
    private String sellerBirthDt2;

    @Column(name = "OWN_LOAN_MAX_AMT", precision = 15)
    private BigDecimal ownLoanMaxAmt;

    @Column(name = "OWN_LOAN_PLN_AMT", precision = 15)
    private BigDecimal ownLoanPlnAmt;

    @Size(max = 50)
    @Column(name = "OWN_LOAN_BANK_NM_1", length = 50)
    private String ownLoanBankNm1;

    @Size(max = 50)
    @Column(name = "OWN_LOAN_BANK_NM_2", length = 50)
    private String ownLoanBankNm2;

    @Size(max = 50)
    @Column(name = "OWN_LOAN_BANK_NM_3", length = 50)
    private String ownLoanBankNm3;

    @Size(max = 50)
    @Column(name = "OWN_LOAN_BANK_NM_4", length = 50)
    private String ownLoanBankNm4;

    @Size(max = 50)
    @Column(name = "OWN_LOAN_BANK_NM_5", length = 50)
    private String ownLoanBankNm5;

    @Size(max = 50)
    @Column(name = "CNSGN_NM", length = 50)
    private String cnsgnNm;

    @Size(max = 50)
    @Column(name = "TRST_NM", length = 50)
    private String trstNm;

    @Size(max = 50)
    @Column(name = "BNFR_NM", length = 50)
    private String bnfrNm;

    @Size(max = 50)
    @Column(name = "NOW_LSHDR_NM", length = 50)
    private String nowLshDrNm;


    @Size(max = 50)
    @Column(name = "RSRV_ITM_B", length = 50)
    private String rsrvItmB;

    @Size(max = 20)
    @Column(name = "OBL_M_LN_APRV_NO", length = 20)
    private String oblMLnAprvNo;

    @Column(name = "OBL_TOT_CNT", precision = 1)
    private Integer oblTotCnt;

    @Column(name = "OBL_GRP_RNK_NO", precision = 1)
    private Integer oblGrpRnkNo;

    @NotNull
    @ColumnDefault("current_timestamp()")
    @Column(name = "CRT_DTM", nullable = false)
    private LocalDateTime crtDtm;

    @Size(max = 12)
    @NotNull
    @ColumnDefault("'SYSTEM'")
    @Column(name = "CRT_MEMB_NO", nullable = false, length = 12)
    private String crtMembNo;

    @NotNull
    @ColumnDefault("current_timestamp()")
    @Column(name = "CHG_DTM", nullable = false)
    private LocalDateTime chgDtm;

    @Size(max = 12)
    @NotNull
    @ColumnDefault("'SYSTEM'")
    @Column(name = "CHG_MEMB_NO", nullable = false, length = 12)
    private String chgMembNo;

    @Column(name = "DOC_AMT", precision = 20)
    private BigDecimal docAmt;

    @Column(name = "DEBT_DC_AMT", precision = 20)
    private BigDecimal debtDcAmt;

    @Column(name = "ETC_AMT", precision = 20)
    private BigDecimal etcAmt;

    @Size(max = 14)
    @Column(name = "UPT_UNQ_NO", length = 14)
    private String uptUnqNo;

}