/**
 * 여신부 상환 신청 지금 결과 통지
 */
package com.bankle.common.wooriApi.socket.woori.socketData;

import java.io.IOException;
import java.io.InputStream;

public class B8X0 extends GetSetData {

    byte[] TR_LN          = new byte[4];    // 전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정
    byte[] TR_CD          = new byte[4];    // 전문종별코드
    byte[] TR_TP_CD       = new byte[3];    // 거래구분코드
    byte[] LO_NO          = new byte[13];   // 관리번호
    byte[] TR_SQ          = new byte[14];   // 식별번호
    byte[] REQ_DTTM       = new byte[14];   // 송신일자
    byte[] RES_DTTM       = new byte[14];   // 수신일자
    byte[] RES_CD         = new byte[3];    // 응답코드
    byte[] MSG_CODE       = new byte[1];    // 메세지구분
    byte[] APPROVAL_NUM   = new byte[11];   // 여신승인신청번호
    byte[] BSTR_REG_NO    = new byte[10];   // 사업자등록번호
    byte[] BUYER_NAME     = new byte[50];   // 차주명
    byte[] SCHEDULED_DATE = new byte[8];    // 실행예정일
    byte[] BRANCH_NAME    = new byte[50];   // 영업점명
	
	byte[] FILLER  = new byte[305]; 	//공란
    
	public B8X0(){
		
		//default 값 셋팅
        setData(this.TR_LN         , "0500");
        setData(this.TR_CD         , "");
        setData(this.TR_TP_CD      , "");
        setData(this.LO_NO         , "");
        setData(this.TR_SQ         , "");
        setData(this.REQ_DTTM      , "");
        setData(this.RES_DTTM      , "");
        setData(this.RES_CD        , "");
        setData(this.MSG_CODE      , "");
        setData(this.APPROVAL_NUM  , "");
        setData(this.BSTR_REG_NO   , "");
        setData(this.BUYER_NAME    , "");
        setData(this.SCHEDULED_DATE, "");
        setData(this.BRANCH_NAME   , "");
        setData(this.FILLER        , "");                                                                                                                                                   
	}                                                                                                                                                                              
                                                                                                                                                                                   
    public String print() throws Exception {

        StringBuffer sb = new StringBuffer();

        String buyerName  = new String(getByte_BUYER_NAME (), "MS949");
        String branchName = new String(getByte_BRANCH_NAME(), "MS949");
        
        sb.append("TR_LN : ["          + getData(TR_LN         ) + "]\tSize : " + TR_LN.length         + "\n");
        sb.append("TR_CD : ["          + getData(TR_CD         ) + "]\tSize : " + TR_CD.length         + "\n");
        sb.append("TR_TP_CD : ["       + getData(TR_TP_CD      ) + "]\tSize : " + TR_TP_CD.length      + "\n");
        sb.append("LO_NO : ["          + getData(LO_NO         ) + "]\tSize : " + LO_NO.length         + "\n");
        sb.append("TR_SQ : ["          + getData(TR_SQ         ) + "]\tSize : " + TR_SQ.length         + "\n");
        sb.append("REQ_DTTM : ["       + getData(REQ_DTTM      ) + "]\tSize : " + REQ_DTTM.length      + "\n");
        sb.append("RES_DTTM : ["       + getData(RES_DTTM      ) + "]\tSize : " + RES_DTTM.length      + "\n");
        sb.append("RES_CD : ["         + getData(RES_CD        ) + "]\tSize : " + RES_CD.length        + "\n");
        sb.append("MSG_CODE : ["       + getData(MSG_CODE      ) + "]\tSize : " + MSG_CODE.length      + "\n");
        sb.append("APPROVAL_NUM : ["   + getData(APPROVAL_NUM  ) + "]\tSize : " + APPROVAL_NUM.length  + "\n");
        sb.append("BSTR_REG_NO : ["    + getData(BSTR_REG_NO   ) + "]\tSize : " + BSTR_REG_NO.length   + "\n");
//        sb.append("BUYER_NAME : ["     + getData(BUYER_NAME)     + "]\tSize : " + BUYER_NAME.length    + "\n");
        sb.append("BUYER_NAME : ["     + buyerName               + "]\tSize : " + BUYER_NAME.length    + "\n");
        sb.append("SCHEDULED_DATE : [" + getData(SCHEDULED_DATE) + "]\tSize : " + SCHEDULED_DATE.length+ "\n");
//        sb.append("BRANCH_NAME : ["    + getData(BRANCH_NAME   ) + "]\tSize : " + BRANCH_NAME.length   + "\n");
        sb.append("BRANCH_NAME : ["    + branchName              + "]\tSize : " + BRANCH_NAME.length   + "\n");        
        sb.append("FILLER : ["         + getData(FILLER        ) + "]\tSize : " + FILLER.length        + "\n");

        // System.out.println(sb.toString());

        return sb.toString();        
    }                                                                                                                                                                            
                                                                                                                                                                                 
    public String dataToString() throws Exception {
        
        String buyerName  = new String(getByte_BUYER_NAME (), "MS949");
        String branchName = new String(getByte_BRANCH_NAME(), "MS949");
        
        return  getData(TR_LN)          + getData(TR_CD)        + getData(TR_TP_CD)    + getData(LO_NO) 
              + getData(TR_SQ)          + getData(REQ_DTTM)     + getData(RES_DTTM)    + getData(RES_CD)      
              + getData(MSG_CODE)       + getData(APPROVAL_NUM) + getData(BSTR_REG_NO) + buyerName //getData(BUYER_NAME)
              + getData(SCHEDULED_DATE) 
              + branchName //getData(BRANCH_NAME)  
              + getData(FILLER);                                                                                                                          
    }                                                                                                                                                                       
                                                                                                                                                                            
    public void readDataExternal(InputStream stream) {                                                                                                                      
        try {                                                                                                                                                                    
            stream.read(TR_LN         , 0, TR_LN.length         );
            stream.read(TR_CD         , 0, TR_CD.length         );
            stream.read(TR_TP_CD      , 0, TR_TP_CD.length      );
            stream.read(LO_NO         , 0, LO_NO.length         );
            stream.read(TR_SQ         , 0, TR_SQ.length         );
            stream.read(REQ_DTTM      , 0, REQ_DTTM.length      );
            stream.read(RES_DTTM      , 0, RES_DTTM.length      );
            stream.read(RES_CD        , 0, RES_CD.length        );
            stream.read(MSG_CODE      , 0, MSG_CODE.length      );
            stream.read(APPROVAL_NUM  , 0, APPROVAL_NUM.length  );
            stream.read(BSTR_REG_NO   , 0, BSTR_REG_NO.length   );
            stream.read(BUYER_NAME    , 0, BUYER_NAME.length    );
            stream.read(SCHEDULED_DATE, 0, SCHEDULED_DATE.length);
            stream.read(BRANCH_NAME   , 0, BRANCH_NAME.length   );
            stream.read(FILLER        , 0, FILLER.length        );
                    
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	//------------------------------------------------------------------
	// Get Data
	//------------------------------------------------------------------

    /**
     * 전문길이
     * @return
     */
	public String getTR_LN() {
		return getData(TR_LN);
	}
	/**
	 * 전문종별코드
	 * @return
	 */
	public String getTR_CD() {
		return getData(TR_CD);
	}
	/**
	 * 거래구분코드
	 * @return
	 */
	public String getTR_TP_CD() {
		return getData(TR_TP_CD);
	}
	/**
	 * 관리번호
	 * @return
	 */
	public String getLO_NO() {
		return getData(LO_NO);
	}
	/**
	 * 식별번호
	 * @return
	 */
	public String getTR_SQ() {
		return getData(TR_SQ);
	}
	/**
	 * 송신일자
	 * @return
	 */
	public String getREQ_DTTM() {
		return getData(REQ_DTTM);
	}
	/**
	 * 수신일자
	 * @return
	 */
	public String getRES_DTTM() {
		return getData(RES_DTTM);
	}
	/**
	 * 응답코드
	 * @return
	 */
	public String getRES_CD() {
		return getData(RES_CD);
	}
	/**
	 * MESSAGE 구분코드
	 * @return
	 */
	public String getMSG_CODE() {
		return getData(MSG_CODE);
	}
	/**
	 * 여신승인신청번호
	 * @return
	 */
	public String getAPPROVAL_NUM() {
		return getData(APPROVAL_NUM);
	}
	/**
	 * 사업자등록번호
	 * @return
	 */
	public String getBSTR_REG_NO() {
		return getData(BSTR_REG_NO);
	}
	/**
	 * 차주명
	 * @return
	 */
	public String getBUYER_NAME() {
		return getData(BUYER_NAME);
		//return buyerName;
	}
	/**
	 * 차주명
	 * @return
	 */
	public byte[] getByte_BUYER_NAME() {
		return BUYER_NAME;
	}
	/**
	 * 실행예정일
	 * @return
	 */
	public String getSCHEDULED_DATE() {
		return getData(SCHEDULED_DATE);
	}
	/**
	 * 영업점명
	 * @return
	 */
	public String getBRANCH_NAME() {
		return getData(BRANCH_NAME);
		//return branchName;
	}
	/**
	 * 영업점명
	 * @return
	 */
	public byte[] getByte_BRANCH_NAME() {
		return BRANCH_NAME;
	}
	/**
	 * 예비
	 * @return
	 */
	public String getFILLER() {
		return getData(FILLER);
	}
	//------------------------------------------------------------------
	// Set Data
	//------------------------------------------------------------------

	/**
	 * 전문길이
	 * @param TR_LN
	 */
	public void setTR_LN(String TR_LN) {
		setData(this.TR_LN, TR_LN,"S");
	}



	/**
	 * 전문종별코드
	 * @param TR_CD
	 */
	public void setTR_CD(String TR_CD) {
		setData(this.TR_CD, TR_CD,"S");
	}



	/**
	 * 거래구분코드
	 * @param TR_TP_CD
	 */
	public void setTR_TP_CD(String TR_TP_CD) {
		setData(this.TR_TP_CD, TR_TP_CD,"S");
	}



	/**
	 * 관리번호
	 * @param LO_NO
	 */
	public void setLO_NO(String LO_NO) {
		setData(this.LO_NO, LO_NO,"S");
	}



	/**
	 * 식별번호
	 * @param TR_SQ
	 */
	public void setTR_SQ(String TR_SQ) {
		setData(this.TR_SQ, TR_SQ,"S");
	}
	


	/**
	 * 송신일자
	 * @param REQ_DTTM
	 */
	public void setREQ_DTTM(String REQ_DTTM) {
		setData(this.REQ_DTTM, REQ_DTTM,"S");
	}



	/**
	 * 수신일자
	 * @param RES_DTTM
	 */
	public void setRES_DTTM(String RES_DTTM) {
		setData(this.RES_DTTM, RES_DTTM,"S");
	}



	/**
	 * 응답코드
	 * @param RES_CD
	 */
	public void setRES_CD(String RES_CD) {
		setData(this.RES_CD, RES_CD,"S");
	}



	/**
	 * MESSAGE 구분코드
	 * @param APPROVAL_NUM
	 */
	public void setMAG_CODE(String MSG_CODE) {
		setData(this.MSG_CODE, MSG_CODE,"S");
	}



	/**
	 * 여신승인신청번호
	 * @param APPROVAL_NUM
	 */
	public void setAPPROVAL_NUM(String APPROVAL_NUM) {
		setData(this.APPROVAL_NUM, APPROVAL_NUM,"S");
	}
	


	/**
	 * 사업자등록번호
	 * @param BSTR_REG_NO
	 */
	public void setBSTR_REG_NO(String BSTR_REG_NO) {
		setData(this.BSTR_REG_NO, BSTR_REG_NO,"S");
	}


	


	/**
	 * 차주명
	 * @param BUYER_NAME
	 */
	public void setBUYER_NAME(String BUYER_NAME) {
		setData(this.BUYER_NAME, BUYER_NAME,"K");
	}



	/**
	 * 실행예정일
	 * @param SCHEDULED_DATE
	 */
	public void setSCHEDULED_DATE(String SCHEDULED_DATE) {
		setData(this.SCHEDULED_DATE, SCHEDULED_DATE,"S");
	}
	



	
	/**
	 * 영업점명
	 * @param BRANCH_NAME
	 */
	public void setBRANCH_NAME(String BRANCH_NAME) {
		setData(this.BRANCH_NAME, BRANCH_NAME,"K");
	}
	


	/**
	 * 예비
	 * @param FILLER
	 */
	public void setFILLER(String FILLER) {
		setData(this.FILLER, FILLER,"S");
	}

}
