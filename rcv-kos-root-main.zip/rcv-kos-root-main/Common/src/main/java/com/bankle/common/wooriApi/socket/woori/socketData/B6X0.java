/**
 * 수신부 등기접수번호 등록
 */
package com.bankle.common.wooriApi.socket.woori.socketData;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class B6X0 extends GetSetData {

    byte[] TR_LN   = new byte[4];       //전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정 
    byte[] TR_CD = new byte[4];         //전문종별코드 
    byte[] TR_TP_CD  = new byte[3];     //거래구분코드 
    byte[] LO_NO  = new byte[13];       //관리번호
    byte[] TR_SQ  = new byte[14];       //식별번호
    byte[] REQ_DTTM  = new byte[14];        //송신일자
    byte[] RES_DTTM  = new byte[14];        //수신일자
    byte[] RES_CD  = new byte[3];       //응답코드
    byte[] APPROVAL_NUM  = new byte[11];    //여신승인신청번호
    byte[] REGR_APPL_NO = new byte[6];          //등기접수번호
    byte[] REGR_OFFICE_NAME  = new byte[50];        //등기소명
    byte[] REGR_APPL_DATE  = new byte[8];       //접수일자
    
    byte[] FILLER  = new byte[360];     //공란

    public B6X0(){
        
        //default 값 셋팅
        setData(this.TR_LN, "0500");
        setData(this.TR_CD, "");
        setData(this.TR_TP_CD, "");
        setData(this.LO_NO, "");
        setData(this.TR_SQ, "");
        setData(this.REQ_DTTM, "");
        setData(this.RES_DTTM, "");
        setData(this.RES_CD, "");
        setData(this.APPROVAL_NUM, "");
        setDataNum(this.REGR_APPL_NO, "");
        setData(this.REGR_OFFICE_NAME, "");
        setData(this.REGR_APPL_DATE, "");
                                                                                                                                                                                              
        setData(this.FILLER, "");                                                                                                                                                   
    }                                                                                                                                                                              
                                                                                                                                                                                   
    public String print() {

        StringBuffer sb = new StringBuffer();
        
        String filler = "";
        String regr_office_name = "";
        try {
            filler = new String(FILLER, "MS949");
            regr_office_name = new String(REGR_OFFICE_NAME, "MS949");
        } catch (Exception Ex) {
            Ex.printStackTrace();
        }        
        
        sb.append("TR_LN : "            + getData(TR_LN           ) + "\tSize : " + TR_LN.length            + "\n");
        sb.append("TR_CD : "            + getData(TR_CD           ) + "\tSize : " + TR_CD.length            + "\n");
        sb.append("TR_TP_CD : "         + getData(TR_TP_CD        ) + "\tSize : " + TR_TP_CD.length         + "\n");
        sb.append("LO_NO : "            + getData(LO_NO           ) + "\tSize : " + LO_NO.length            + "\n");
        sb.append("TR_SQ : "            + getData(TR_SQ           ) + "\tSize : " + TR_SQ.length            + "\n");
        sb.append("REQ_DTTM : "         + getData(REQ_DTTM        ) + "\tSize : " + REQ_DTTM.length         + "\n");
        sb.append("RES_DTTM : "         + getData(RES_DTTM        ) + "\tSize : " + RES_DTTM.length         + "\n");
        sb.append("RES_CD : "           + getData(RES_CD          ) + "\tSize : " + RES_CD.length           + "\n");
        sb.append("APPROVAL_NUM : "     + getData(APPROVAL_NUM    ) + "\tSize : " + APPROVAL_NUM.length     + "\n");
        sb.append("REGR_APPL_NO : "     + getData(REGR_APPL_NO    ) + "\tSize : " + REGR_APPL_NO.length     + "\n");
        sb.append("REGR_OFFICE_NAME : " + regr_office_name          + "\tSize : " + REGR_OFFICE_NAME.length + "\n");
        sb.append("REGR_APPL_DATE : "   + getData(REGR_APPL_DATE  ) + "\tSize : " + REGR_APPL_DATE.length   + "\n");
        sb.append("FILLER : "           + filler                    + "\tSize : " + FILLER.length           + "\n");
        
        // System.out.println(sb.toString());

        return sb.toString();                                                                                                                                                    
    }                                                                                                                                                                            
                                                                                                                                                                                 
    public String dataToString() {
        
        String regrofficename = "";
        
        try {
        	regrofficename = new String(REGR_OFFICE_NAME, "MS949");
                                                                                                                         
        } catch (Exception Ex) {
            Ex.printStackTrace();
        }
    	
        return getData(TR_LN) + getData(TR_CD) + getData(TR_TP_CD) + getData(LO_NO) + getData(TR_SQ) + getData(REQ_DTTM) + getData(RES_DTTM) + getData(RES_CD)
                                + getData(APPROVAL_NUM) + getData(REGR_APPL_NO) + regrofficename + getData(REGR_APPL_DATE) 
                                + getData(FILLER) ;
    }                                                                                                                                                                       
                                                                                                                                                                            
    public byte[] getAllData() throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
        outputStream.write(TR_LN);
        outputStream.write(TR_CD);
        outputStream.write(TR_TP_CD);
        outputStream.write(LO_NO);
        outputStream.write(TR_SQ);
        outputStream.write(REQ_DTTM);
        outputStream.write(RES_DTTM);
        outputStream.write(RES_CD);
        outputStream.write(APPROVAL_NUM);
        outputStream.write(REGR_APPL_NO);
        outputStream.write(REGR_OFFICE_NAME);
        outputStream.write(REGR_APPL_DATE);
        outputStream.write(FILLER);
        byte[] data  = outputStream.toByteArray();
        return data;
    }    
    
    public void readDataExternal(InputStream stream) {                                                                                                                      
        try {                                                                                                                                                                    
            stream.read(TR_LN, 0, TR_LN.length);
            stream.read(TR_CD, 0, TR_CD.length);
            stream.read(TR_TP_CD, 0, TR_TP_CD.length);
            stream.read(LO_NO, 0, LO_NO.length);
            stream.read(TR_SQ, 0, TR_SQ.length);
            stream.read(REQ_DTTM, 0, REQ_DTTM.length);
            stream.read(RES_DTTM, 0, RES_DTTM.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(APPROVAL_NUM, 0, APPROVAL_NUM.length);
            stream.read(REGR_APPL_NO, 0, REGR_APPL_NO.length);
            stream.read(REGR_OFFICE_NAME, 0, REGR_OFFICE_NAME.length);
            stream.read(REGR_APPL_DATE, 0, REGR_APPL_DATE.length);
            
            stream.read(FILLER, 0, FILLER.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //------------------------------------------------------------------
    // Get Data
    //------------------------------------------------------------------

    /**
     * 전문길이
     * @return
     */
    public String getTR_LN() {
        return getData(TR_LN);
    }
    /**
     * 전문종별코드
     * @return
     */
    public String getTR_CD() {
        return getData(TR_CD);
    }
    /**
     * 거래구분코드
     * @return
     */
    public String getTR_TP_CD() {
        return getData(TR_TP_CD);
    }
    /**
     * 관리번호
     * @return
     */
    public String getLO_NO() {
        return getData(LO_NO);
    }
    /**
     * 식별번호
     * @return
     */
    public String getTR_SQ() {
        return getData(TR_SQ);
    }
    /**
     * 송신일자
     * @return
     */
    public String getREQ_DTTM() {
        return getData(REQ_DTTM);
    }
    /**
     * 수신일자
     * @return
     */
    public String getRES_DTTM() {
        return getData(RES_DTTM);
    }
    /**
     * 응답코드
     * @return
     */
    public String getRES_CD() {
        return getData(RES_CD);
    }
    /**
     * 여신승인신청번호
     * @return
     */
    public String getAPPROVAL_NUM() {
        return getData(APPROVAL_NUM);
    }
    /**
     * 등기접수번호
     * @return
     */
    public String getREGR_APPL_NO() {
        return getData(REGR_APPL_NO);
    }
    /**
     * 등기소명
     * @return
     */
    public String getREGR_OFFICE_NAME() {
        return getData(REGR_OFFICE_NAME);
    }
    /**
     * 접수일자
     * @return
     */
    public String getREGR_APPL_DATE() {
        return getData(REGR_APPL_DATE);
    }
    /**
     * 예비
     * @return
     */
    public String getFILLER() {
        return getData(FILLER);
    }
    //------------------------------------------------------------------
    // Set Data
    //------------------------------------------------------------------

    /**
     * 전문길이
     * @param TR_LN
     */
    public void setTR_LN(String TR_LN) {
        setData(this.TR_LN, TR_LN,"S");
    }



    /**
     * 전문종별코드
     * @param TR_CD
     */
    public void setTR_CD(String TR_CD) {
        setData(this.TR_CD, TR_CD,"S");
    }



    /**
     * 거래구분코드
     * @param TR_TP_CD
     */
    public void setTR_TP_CD(String TR_TP_CD) {
        setData(this.TR_TP_CD, TR_TP_CD,"S");
    }



    /**
     * 관리번호
     * @param LO_NO
     */
    public void setLO_NO(String LO_NO) {
        setData(this.LO_NO, LO_NO,"S");
    }



    /**
     * 식별번호
     * @param TR_SQ
     */
    public void setTR_SQ(String TR_SQ) {
        setData(this.TR_SQ, TR_SQ,"S");
    }



    /**
     * 송신일자
     * @param REQ_DTTM
     */
    public void setREQ_DTTM(String REQ_DTTM) {
        setData(this.REQ_DTTM, REQ_DTTM,"S");
    }



    /**
     * 수신일자
     * @param RES_DTTM
     */
    public void setRES_DTTM(String RES_DTTM) {
        setData(this.RES_DTTM, RES_DTTM,"S");
    }



    /**
     * 응답코드
     * @param RES_CD
     */
    public void setRES_CD(String RES_CD) {
        setData(this.RES_CD, RES_CD,"S");
    }


    
    /**
     * 여신승인신청번호
     * @param APPROVAL_NUM
     */
    public void setAPPROVAL_NUM(String APPROVAL_NUM) {
        setData(this.APPROVAL_NUM, APPROVAL_NUM,"S");
    }
    


    /**
     * 등기접수번호
     * @param REGR_APPL_NO
     */
    public void setREGR_APPL_NO(String REGR_APPL_NO) {
        setData(this.REGR_APPL_NO, REGR_APPL_NO,"N");
    }



    /**
     * 등기소명
     * @param REGR_OFFICE_NAME
     */
    public void setREGR_OFFICE_NAME(String REGR_OFFICE_NAME) {
        setData(this.REGR_OFFICE_NAME, REGR_OFFICE_NAME,"K");
    }



    /**
     * 접수일자
     * @param REGR_APPL_DATE
     */
    public void setREGR_APPL_DATE(String REGR_APPL_DATE) {
        setData(this.REGR_APPL_DATE, REGR_APPL_DATE,"S");
    }
    


    /**
     * 예비
     * @param FILLER
     */
    public void setFILLER(String FILLER) {
        setData(this.FILLER, FILLER,"S");
    }

}
