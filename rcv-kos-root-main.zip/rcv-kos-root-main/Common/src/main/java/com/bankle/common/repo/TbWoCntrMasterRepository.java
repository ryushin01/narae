package com.bankle.common.repo;

import com.bankle.common.entity.TbWoCntrMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TbWoCntrMasterRepository extends JpaRepository<TbWoCntrMaster, String> {

    Optional<TbWoCntrMaster> findByLoanNo(String loanNo);

    boolean existsByLoanNo(String loanNo);

}