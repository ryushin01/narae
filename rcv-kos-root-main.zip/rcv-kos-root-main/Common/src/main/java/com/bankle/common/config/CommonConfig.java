package com.bankle.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CommonConfig {

    /**
     * Common 및 모든 프로젝트 Configuration 파일 사용방법입니다.
     * <p>
     * 해당 클래스의 기능은 application-{server}.yml 파일 내의 설정된 내용의 value를 가져오는 기능을 하고 있습니다.
     * 해당하는 값을 불러와서 사용하는 방법은 아래와 동일하다.
     * static으로 사용을 할 것 이기 때문에 경로를 언더스코어 & 대문자로 작성을 합니다.
     * 어노테이션 @Value로 선언하여 yml내에 지정한 경로로 작성을 해줍니다. 이떄는 ":"(콜론) 을 .으로 변경하여 붙여서 작성을 해줍니다.
     * 선언된 어노테이션 아래에 setter를 작성을 해줍니다.
     * 해당하는 property의 값을 쓸 곳에 가서 CommonConfig.SAMPLE 로 불러서 사용하시면 됩니다.
     * <p>
     * <ex>
     * <p>
     * application-common-dev.yml >>>>>>>>>>>> 파일 위치입니다.
     * <p>
     * private static String CUSTOM_PROPERTY_SAMPLE;
     *
     * @Value("${custom.property.sample}") public void setCUSTOM_PROPERTY_SAMPLE(String sample) {
     * CUSTOM_PROPERTY_SAMPLE = sample;
     * }
     * </ex>
     */

    public static boolean SAVE_TRANSFER_TO_DB = false;
    public static String IROS_APIKEY;
    public static String PUSH_API_KEY;
    public static String SMS_SECRET_KEY;
    public static String CORP_NUM;
    public static String USER_ID;
    public static String LINK_ID;
    public static String SECRET_KEY;
    public static Boolean IS_TEST;
    public static Boolean IS_IP_RESTRICT_ON_OFF;
    public static String ENV;
    public static String BASE_URL_ADMIN;
    public static String BASE_URL_API;
    public static String BASE_URL_APP_WOORI;
    public static String BASE_URL_AUTH;
    public static String BASE_URL_BATCH;
    public static String BASE_URL_IMAGE;
    public static final String IMG_SCH_PATH = "/images/";
    public static String WEB_BASE_URL_APP_WOORI;
    // DirectSend(이메일)
    public static String DIRECTSEND_URL;
    public static String DIRECTSEND_ID;
    public static String DIRECTSEND_APIKEY;
    public static int    DIRECTSEND_RETURN_URL;
    public static int    DIRECTSEND_OPTION_RETURN_URL;


//    @Value("${custom.nicekos.save-transfer-to-db}")
//    public void setSAVE_TRANSFER_TO_DB(Boolean saveTransferToDb) { SAVE_TRANSFER_TO_DB = saveTransferToDb; }
//    @Value("${iros.apikey}")
//    public void setIROS_APIKEY(String irosApikey) { IROS_APIKEY = irosApikey; }
//    @Value("${message.push.api_key}")
//    public void setPUSH_API_KEY(String pushApiKey) { PUSH_API_KEY = pushApiKey; }
//    @Value("${message.sms.secret_key}")
//    public void setSMS_SECRET_KEY(String smsSecretKey) { SMS_SECRET_KEY = smsSecretKey; }
//    @Value("${message.kakao.corp_num}")
//    public void setCORP_NUM(String corpNum) { CORP_NUM = corpNum; }
//    @Value("${message.kakao.user_id}")
//    public void setUSER_ID(String userId) { USER_ID = userId; }
//    @Value("${message.kakao.link_id}")
//    public void setLINK_ID(String linkId) { LINK_ID = linkId; }
//    @Value("${message.kakao.secret_key}")
//    public void setSECRET_KEY(String secretKey) { SECRET_KEY = secretKey; }
//    @Value("${message.kakao.is_test}")
//    public void setIS_TEST(String istest) { IS_TEST = "true".equals(istest) ? true : false; }
//    @Value("${message.kakao.is_ip_restrict_on_off}")
//    public void setIS_IP_RESTRICT_ON_OFF(String isIpRestrictOnOff) { IS_IP_RESTRICT_ON_OFF = "true".equals(isIpRestrictOnOff) ? true : false; }
//    @Value("${spring.config.activate.on-profile}")
//    public void setENV(String env) { ENV = env; }
//    @Value("${base_url.admin}")
//    public void setBaseUrlAdmin(String baseUrlAdmin) { BASE_URL_ADMIN = baseUrlAdmin; }
//    @Value("${base_url.api}")
//    public void setBaseUrlApi(String baseUrlApi) { BASE_URL_API = baseUrlApi; }
//    @Value("${base_url.app_woori}")
//    public void setBaseUrlAppWoori(String baseUrlAppWoori) { BASE_URL_APP_WOORI = baseUrlAppWoori; }
//    @Value("${base_url.auth}")
//    public void setBaseUrlAuth(String baseUrlAuth) { BASE_URL_AUTH = baseUrlAuth; }
//    @Value("${base_url.batch}")
//    public void setBaseUrlBatch(String baseUrlBatch) { BASE_URL_BATCH = baseUrlBatch; }
//    @Value("${base_url.image}")
//    public void setBaseUrlImage(String baseUrlImage) { BASE_URL_IMAGE = baseUrlImage; }
//    @Value("${directsend.url}")
//    public void setDirectSendUrl(String directSendUrl) { DIRECTSEND_URL = directSendUrl; }
//    @Value("${directsend.id}")
//    public void setDirectSendId(String directSendId) { DIRECTSEND_ID = directSendId; }
//    @Value("${directsend.apikey}")
//    public void setDirectSendApiKey(String directSendApiKey) { DIRECTSEND_APIKEY = directSendApiKey; }
//    @Value("${directsend.return_url}")
//    public void setDirectSendReturnUrl(int directSendReturnUrl) { DIRECTSEND_RETURN_URL = directSendReturnUrl; }
//    @Value("${directsend.option_return_url}")
//    public void setDirectSendOptionReturnUrl(int directSendOptionReturnUrl) { DIRECTSEND_OPTION_RETURN_URL = directSendOptionReturnUrl; }
//    @Value("${web_base_url.app_woori}")
//    public void setWebBaseUrlAppWoori(String webBaseUrlAppWoori) { WEB_BASE_URL_APP_WOORI = webBaseUrlAppWoori; }

}