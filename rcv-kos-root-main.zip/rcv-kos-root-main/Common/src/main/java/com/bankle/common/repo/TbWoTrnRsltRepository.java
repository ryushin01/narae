package com.bankle.common.repo;

import com.bankle.common.entity.TbWoTrnRslt;
import com.bankle.common.entity.TbWoTrnRsltId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TbWoTrnRsltRepository extends JpaRepository<TbWoTrnRslt, TbWoTrnRsltId> {
    Optional<TbWoTrnRslt> findByIdLoanNoAndIdTgDsc(String loanNo, String tgDsc);
}