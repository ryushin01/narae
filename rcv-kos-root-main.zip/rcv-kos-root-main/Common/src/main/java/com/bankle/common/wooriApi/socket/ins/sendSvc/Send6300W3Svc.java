package com.bankle.common.wooriApi.socket.ins.sendSvc;

import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.DateUtil;
import com.bankle.common.utils.StringUtil;
import com.bankle.common.wooriApi.socket.ins.commonSvc.InsCmnSvc;
import com.bankle.common.wooriApi.socket.ins.commonSvc.vo.InsCmnSvo;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6300W3Svo;
import com.bankle.common.wooriApi.socket.ins.socketData.T6300W3;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;

@Slf4j
@Component
@RequiredArgsConstructor
public class Send6300W3Svc {
    private final InsCmnSvc insCmnSvc;
    private final String TG_DSC = "W3000";
    private final String BNK_CD = "020";
    private final String TR_DSC = "100";
    private final String TG_LEN = "996";
    private final String RES_CD = "000";
    private final String REQ_TG_FN_YN = "Y";
    private final String RES_TG_FN_YN = "N";
    private final BizUtil bizUtil;


    @Transactional
    public CheckResponseSvo sendAndResponse(@Valid Send6300W3Svo.sendInVo invo) throws Exception{
        log.debug("Send6200F2Svc.sendAndResponse().invo : " + invo);
        log.debug("Send6200F2Svc.sendAndResponse().invo : " + invo.getLoanNo());
        String seq = this.send(invo);
        return insCmnSvc.checkResponse(seq);
    }

    @org.springframework.transaction.annotation.Transactional(propagation = Propagation.REQUIRES_NEW)
    public String send(Send6300W3Svo.sendInVo sendInVo) throws Exception {

        try {
            log.debug("Send6300W3Svc send > sendInVo : " + sendInVo);
            //String seq = StringUtil.lpad(sendInVo.getDbTgNo().toString(), 8, "0");
            String seq = bizUtil.getSeq(Sequence.TRANS);
            log.debug("Send6300W3Svc send > seq : " + seq);
            T6300W3 sendData = new T6300W3();
            sendData.setTG_LEN(TG_LEN);                            // 1. 전문 길이
            sendData.setTG_DSC(TG_DSC);             // 2. 전문 구분 코드
            sendData.setRES_CD(RES_CD);                            // 7. 응답 코드
            sendData.setLND_AGNC_CD(sendInVo.getLndAgncCd());
            sendData.setBNK_TG_TRNS_DTM(sendInVo.getBnkTgTrnsDtm());
            sendData.setDB_TG_TRNS_DTM(sendInVo.getDbTgTrnsDtm());
            sendData.setBNK_TG_NO(sendInVo.getBnkTgNo());
            sendData.setDB_TG_NO(sendInVo.getBnkTgNo());
            sendData.setRSRV_ITM_H(sendInVo.getRsrvItmH());
            sendData.setBNK_ASK_NO(sendInVo.getBnkAskNo());
            sendData.setLN_APRV_NO(StringUtil.rpad(sendInVo.getLoanNo(), 14, "0"));
            sendData.setDB_MNG_NO(sendInVo.getDbMngNo());
            sendData.setKOS_TG_TRNS_DTM(DateUtil.getCurrentDateTime());
            sendData.setKOS_TG_NO(seq);
            sendData.setNTTN_YN(sendInVo.getNttnYn());
            sendData.setEND_NOTI_DT(sendInVo.getEndNotiDt());
            sendData.setEND_NOTI_TM(sendInVo.getEndnotiTm());
            sendData.setBNK_DRCTR_NM(sendInVo.getBnkDrctrNm());
            sendData.setBNK_DRCTR_PHNO(sendInVo.getBnkDrctrPhno());
            sendData.setRSRV_ITM_B(sendInVo.getRsrvItmB());

            log.debug(sendData.print());
            insCmnSvc.insSend(InsCmnSvo.insCmnInVo.builder()
                    .tgSqn(seq)
                    .bnkTgNo(sendData.getBNK_TG_NO())
                    .bnkCd(BNK_CD)
                    .tgDsc(TG_DSC)
                    .trDsc(TR_DSC)
                    .reqTgCnts(sendData.dataToString())
                    .reqTgLog(sendData.print())
                    .reqTgFnYn(REQ_TG_FN_YN)
                    .resTgFnYn(RES_TG_FN_YN)
                    .loanNo(sendInVo.getLoanNo())
                    .membNo("SYSTEM")
                    .build());

            return seq;
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException("전문 전송 테이블 적재시 오류가 발생했습니다! -> " + e.getMessage());
        }
    }
}
