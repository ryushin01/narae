/**
 * 수신부(BPR) 법무사 등록 여부 확인 및 인원 변경 통지
 */
package com.bankle.common.wooriApi.socket.woori.socketData;

import java.io.IOException;
import java.io.InputStream;

public class B1X0 extends GetSetData {

	byte[] TR_LN   = new byte[4];   	//전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정 
	byte[] TR_CD = new byte[4];   		//전문종별코드 
	byte[] TR_TP_CD  = new byte[3];   	//거래구분코드 
	byte[] LO_NO  = new byte[13];   	//관리번호
	byte[] TR_SQ  = new byte[14];   	//식별번호
	byte[] REQ_DTTM  = new byte[14];  		//송신일자
	byte[] RES_DTTM  = new byte[14];  		//수신일자
	byte[] RES_CD  = new byte[3];  		//응답코드
	byte[] BSTR_REG_NO  = new byte[10];   	//사업자등록번호
	byte[] ACCT_NO  = new byte[20];   	//은행계좌번호
	byte[] BRANCH_CODE = new byte[6];  		//지점코드
	byte[] REQ_TP  = new byte[1];  		//요청구분(N:신규 U:수정)
	byte[] REG_YN  = new byte[1];  		//등록여부(Y:정상등록 N:비정상또는 없음)
	byte[] LEG_TP  = new byte[1];  		//법무사등록구분(1:협약법무사 2:권원법무사)
	byte[] CUR_MEM_CNT  = new byte[1];  //현운영인력
	byte[] OUT_MEM_CNT  = new byte[1];  //탈퇴인력
	byte[] IN_MEM_CNT  = new byte[1];  //신규인원
	byte[] CHG_DT  = new byte[8];  		//최종수정일
	
	byte[] FILLER  = new byte[385]; 	//공란

	public B1X0(){
		
		//default 값 셋팅
		setData(this.TR_LN, "0500");
        setData(this.TR_CD, "");
        setData(this.TR_TP_CD, "");
        setData(this.LO_NO, "");
        setData(this.TR_SQ, "");
        setData(this.REQ_DTTM, "");
        setData(this.RES_DTTM, "");
        setData(this.RES_CD, "");
        setData(this.BSTR_REG_NO, "");
        setData(this.ACCT_NO, "");
        setData(this.BRANCH_CODE, "");
        setData(this.REQ_TP, "");
        setData(this.REG_YN, "");
        setData(this.LEG_TP, "");                 
        setDataNum(this.CUR_MEM_CNT, "");
        setDataNum(this.OUT_MEM_CNT, "");
        setDataNum(this.IN_MEM_CNT, "");
        setData(this.CHG_DT, ""); 
        
        setData(this.FILLER, "");                                                                                                                                                   
	}                                                                                                                                                                              
                                                                                                                                                                                   
	public String  print() {
	    
        StringBuffer sb = new StringBuffer();
        
        sb.append("TR_LN : "       + getData(TR_LN      ) + "\tSize : " + TR_LN.length       + "\n");
        sb.append("TR_CD : "       + getData(TR_CD      ) + "\tSize : " + TR_CD.length       + "\n");
        sb.append("TR_TP_CD : "    + getData(TR_TP_CD   ) + "\tSize : " + TR_TP_CD.length    + "\n");
        sb.append("LO_NO : "       + getData(LO_NO      ) + "\tSize : " + LO_NO.length       + "\n");
        sb.append("TR_SQ : "       + getData(TR_SQ      ) + "\tSize : " + TR_SQ.length       + "\n");
        sb.append("REQ_DTTM : "    + getData(REQ_DTTM   ) + "\tSize : " + REQ_DTTM.length    + "\n");
        sb.append("RES_DTTM : "    + getData(RES_DTTM   ) + "\tSize : " + RES_DTTM.length    + "\n");
        sb.append("RES_CD : "      + getData(RES_CD     ) + "\tSize : " + RES_CD.length      + "\n");
        sb.append("BSTR_REG_NO : " + getData(BSTR_REG_NO) + "\tSize : " + BSTR_REG_NO.length + "\n");
        sb.append("ACCT_NO : "     + getData(ACCT_NO    ) + "\tSize : " + ACCT_NO.length     + "\n");
        sb.append("BRANCH_CODE : " + getData(BRANCH_CODE) + "\tSize : " + BRANCH_CODE.length + "\n");
        sb.append("REQ_TP : "      + getData(REQ_TP     ) + "\tSize : " + REQ_TP.length      + "\n");
        sb.append("REG_YN : "      + getData(REG_YN     ) + "\tSize : " + REG_YN.length      + "\n");
        sb.append("LEG_TP : "      + getData(LEG_TP     ) + "\tSize : " + LEG_TP.length      + "\n");
        sb.append("CUR_MEM_CNT : " + getData(CUR_MEM_CNT) + "\tSize : " + CUR_MEM_CNT.length + "\n");
        sb.append("OUT_MEM_CNT : " + getData(OUT_MEM_CNT) + "\tSize : " + OUT_MEM_CNT.length + "\n");
        sb.append("IN_MEM_CNT : "  + getData(IN_MEM_CNT ) + "\tSize : " + IN_MEM_CNT.length  + "\n");
        sb.append("CHG_DT : "      + getData(CHG_DT     ) + "\tSize : " + CHG_DT.length      + "\n");
        sb.append("FILLER : "      + getData(FILLER     ) + "\tSize : " + FILLER.length      + "\n");                                                                                         
        
        // System.out.println(sb.toString());

        return sb.toString();                                                                                                                                                    
    }                                                                                                                                                                            
                                                                                                                                                                                 
    public String dataToString() {         
    	return getData(TR_LN) + getData(TR_CD) + getData(TR_TP_CD) + getData(LO_NO) + getData(TR_SQ) + getData(REQ_DTTM) + getData(RES_DTTM) + getData(RES_CD)
        						+ getData(BSTR_REG_NO)+ getData(ACCT_NO) + getData(BRANCH_CODE) + getData(REQ_TP) + getData(REG_YN) + getData(LEG_TP)
        						+ getData(CUR_MEM_CNT) + getData(OUT_MEM_CNT) + getData(IN_MEM_CNT) + getData(CHG_DT)
        						+ getData(FILLER);                                                                                                                          
    }                                                                                                                                                                       
                                                                                                                                                                            
    public void readDataExternal(InputStream stream) {                                                                                                                      
        try {                                                                                                                                                                    
            stream.read(TR_LN, 0, TR_LN.length);
            stream.read(TR_CD, 0, TR_CD.length);
            stream.read(TR_TP_CD, 0, TR_TP_CD.length);
            stream.read(LO_NO, 0, LO_NO.length);
            stream.read(TR_SQ, 0, TR_SQ.length);
            stream.read(REQ_DTTM, 0, REQ_DTTM.length);
            stream.read(RES_DTTM, 0, RES_DTTM.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(BSTR_REG_NO, 0, BSTR_REG_NO.length);
            stream.read(ACCT_NO, 0, ACCT_NO.length);
            stream.read(BRANCH_CODE, 0, BRANCH_CODE.length);
            stream.read(REQ_TP, 0, REQ_TP.length);
            stream.read(REG_YN, 0, REG_YN.length);
            stream.read(LEG_TP, 0, LEG_TP.length);
            stream.read(CUR_MEM_CNT, 0, CUR_MEM_CNT.length);
            stream.read(OUT_MEM_CNT, 0, OUT_MEM_CNT.length);
            stream.read(IN_MEM_CNT, 0, IN_MEM_CNT.length);
            stream.read(CHG_DT, 0, CHG_DT.length);
            
            stream.read(FILLER, 0, FILLER.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	//------------------------------------------------------------------
	// Get Data
	//------------------------------------------------------------------

    /**
     * 전문길이
     * @return
     */
	public String getTR_LN() {
		return getData(TR_LN);
	}
	/**
	 * 전문종별코드
	 * @return
	 */
	public String getTR_CD() {
		return getData(TR_CD);
	}
	/**
	 * 거래구분코드
	 * @return
	 */
	public String getTR_TP_CD() {
		return getData(TR_TP_CD);
	}
	/**
	 * 관리번호
	 * @return
	 */
	public String getLO_NO() {
		return getData(LO_NO);
	}
	/**
	 * 식별번호
	 * @return
	 */
	public String getTR_SQ() {
		return getData(TR_SQ);
	}
	/**
	 * 송신일자
	 * @return
	 */
	public String getREQ_DTTM() {
		return getData(REQ_DTTM);
	}
	/**
	 * 수신일자
	 * @return
	 */
	public String getRES_DTTM() {
		return getData(RES_DTTM);
	}
	/**
	 * 응답코드
	 * @return
	 */
	public String getRES_CD() {
		return getData(RES_CD);
	}
	/**
	 * 사업자등록번호
	 * @return
	 */
	public String getBSTR_REG_NO() {
		return getData(BSTR_REG_NO);
	}
	/**
	 * 은행계좌번호
	 * @return
	 */
	public String getACCT_NO() {
		return getData(ACCT_NO);
	}
	/**
	 * 지점코드
	 * @return
	 */
	public String getBRANCH_CODE() {
		return getData(BRANCH_CODE);
	}
	/**
	 * 요청구분
	 * @return
	 */
	public String getREQ_TP() {
		return getData(REQ_TP);
	}
	/**
	 * 등록여부
	 * @return
	 */
	public String getREG_YN() {
		return getData(REG_YN);
	}
	/**
	 * 법무사등록구분
	 * @return
	 */
	public String getLEG_TP() {
		return getData(LEG_TP);
	}
	/**
	 * 현운영인력
	 * @return
	 */
	public String getCUR_MEM_CNT() {
		return getData(CUR_MEM_CNT);
	}
	/**
	 * 탈퇴인력
	 * @return
	 */
	public String getOUT_MEM_CNT() {
		return getData(OUT_MEM_CNT);
	}
	/**
	 * 신규인원
	 * @return
	 */
	public String getIN_MEM_CNT() {
		return getData(IN_MEM_CNT);
	}
	/**
	 * 최종수정일
	 * @return
	 */
	public String getCHG_DT() {
		return getData(CHG_DT);
	}
	/**
	 * 예비
	 * @return
	 */
	public String getFILLER() {
		return getData(FILLER);
	}

	//------------------------------------------------------------------
	// Set Data
	//------------------------------------------------------------------

	/**
	 * 전문길이
	 * @param TR_LN
	 */
	public void setTR_LN(String TR_LN) {
		setData(this.TR_LN, TR_LN,"S");
	}



	/**
	 * 전문종별코드
	 * @param TR_CD
	 */
	public void setTR_CD(String TR_CD) {
		setData(this.TR_CD, TR_CD,"S");
	}



	/**
	 * 거래구분코드
	 * @param TR_TP_CD
	 */
	public void setTR_TP_CD(String TR_TP_CD) {
		setData(this.TR_TP_CD, TR_TP_CD,"S");
	}



	/**
	 * 관리번호
	 * @param LO_NO
	 */
	public void setLO_NO(String LO_NO) {
		setData(this.LO_NO, LO_NO,"S");
	}



	/**
	 * 식별번호
	 * @param TR_SQ
	 */
	public void setTR_SQ(String TR_SQ) {
		setData(this.TR_SQ, TR_SQ,"S");
	}



	/**
	 * 송신일자
	 * @param REQ_DTTM
	 */
	public void setREQ_DTTM(String REQ_DTTM) {
		setData(this.REQ_DTTM, REQ_DTTM,"S");
	}



	/**
	 * 수신일자
	 * @param RES_DTTM
	 */
	public void setRES_DTTM(String RES_DTTM) {
		setData(this.RES_DTTM, RES_DTTM,"S");
	}



	/**
	 * 응답코드
	 * @param RES_CD
	 */
	public void setRES_CD(String RES_CD) {
		setData(this.RES_CD, RES_CD,"S");
	}


	
	/**
	 * 사업자등록번호
	 * @param BSTR_REG_NO
	 */
	public void setBSTR_REG_NO(String BSTR_REG_NO) {
		setData(this.BSTR_REG_NO, BSTR_REG_NO,"S");
	}
	

	
	/**
	 * 은행계좌번호
	 * @param ACCT_NO
	 */
	public void setACCT_NO(String ACCT_NO) {
		setData(this.ACCT_NO, ACCT_NO,"S");
	}
	


	/**
	 * 지점코드
	 * @param BRANCH_CODE
	 */
	public void setBRANCH_CODE(String BRANCH_CODE) {
		setData(this.BRANCH_CODE, BRANCH_CODE,"S");
	}



	/**
	 * 요청구분
	 * @param REQ_TP
	 */
	public void setREQ_TP(String REQ_TP) {
		setData(this.REQ_TP, REQ_TP,"S");
	}



	/**
	 * 등록여부
	 * @param REG_YN
	 */
	public void setREG_YN(String REG_YN) {
		setData(this.REG_YN, REG_YN,"S");
	}
	


	/**
	 * 법무사등록구분
	 * @param LEG_TP
	 */
	public void setLEG_TP(String LEG_TP) {
		setData(this.LEG_TP, LEG_TP,"S");
	}
	


	/**
	 * 현운영인력
	 * @param CUR_MEM_CNT
	 */
	public void setCUR_MEM_CNT(String CUR_MEM_CNT) {
		setData(this.CUR_MEM_CNT, CUR_MEM_CNT,"N");
	}


	/**
	 * 탈퇴인력
	 * @param OUT_MEM_CNT
	 */
	public void setOUT_MEM_CNT(String OUT_MEM_CNT) {
		setData(this.OUT_MEM_CNT, OUT_MEM_CNT,"N");
	}


	/**
	 * 신규인원
	 * @param IN_MEM_CNT
	 */
	public void setIN_MEM_CNT(String IN_MEM_CNT) {
		setData(this.IN_MEM_CNT, IN_MEM_CNT,"N");
	}
	


	/**
	 * 최종수정일
	 * @param CHG_DT
	 */
	public void setCHG_DT(String CHG_DT) {
		setData(this.CHG_DT, CHG_DT,"S");
	}
	


	/**
	 * 예비
	 * @param FILLER
	 */
	public void setFILLER(String FILLER) {
		setData(this.FILLER, FILLER,"S");
	}

}
