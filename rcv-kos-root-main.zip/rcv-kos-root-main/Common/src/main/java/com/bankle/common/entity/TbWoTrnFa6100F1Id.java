package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.Hibernate;

import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class TbWoTrnFa6100F1Id implements java.io.Serializable {
    private static final long serialVersionUID = 9135659571955093912L;
    @Size(max = 20)
    @NotNull
    @Column(name = "LOAN_NO", nullable = false, length = 20)
    private String loanNo;

    @NotNull
    @Column(name = "CHG_DTM", nullable = false)
    private LocalDateTime chgDtm;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        TbWoTrnFa6100F1Id entity = (TbWoTrnFa6100F1Id) o;
        return Objects.equals(this.chgDtm, entity.chgDtm) &&
                Objects.equals(this.loanNo, entity.loanNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(chgDtm, loanNo);
    }

}