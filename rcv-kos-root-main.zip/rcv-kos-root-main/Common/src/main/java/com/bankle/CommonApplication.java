package com.bankle;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@EnableJpaAuditing
@SpringBootApplication
public class CommonApplication {
    public static void contextLoads(String[] args) {
        System.out.println("###### CommonApplication Module START!!!!!!!!!!!!!! ######");
        System.out.println("###### CommonApplication Module START!!!!!!!!!!!!!! ######");
        System.out.println("###### CommonApplication Module START!!!!!!!!!!!!!! ######");
    }
}
