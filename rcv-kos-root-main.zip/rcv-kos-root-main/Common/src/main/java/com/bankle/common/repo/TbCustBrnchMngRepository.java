package com.bankle.common.repo;

import com.bankle.common.entity.TbCustBrnchMng;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbCustBrnchMngRepository extends JpaRepository<TbCustBrnchMng, Long> {
    Optional<TbCustBrnchMng> findAllByBrnchNm(String brnchNm);
}