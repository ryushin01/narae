package com.bankle.app.biz.trn.vo;

import lombok.*;


public class PayRsltSvo {

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class PayRsltInSvo {
        private String loanNo;
        private String trLn;            // 전문길이
        private String trCd;            // 전문종별코드
        private String trTpCd;          // 거래구분코드
        private String loNo;            // 관리번호
//        private String trSq;            // 식별번호
//        private String reqDttm;         // 송신일자
//        private String resDttm;         // 수신일자
//        private String resCd;           // 응답코드
//        private String approvalNum;     // 여신승인신청번호
        private String payType;         // 지급구분
        private String payBankCd;       // 지급요청 은행코드
        private String payAmt;          // 지급요청 금액
        private String transResultCd;   // 이체 결과 코드
        private String filler;
    }
}
