package com.bankle.app.biz.trn.ctrl;

import com.bankle.app.biz.trn.svc.PayRsltSvc;
import com.bankle.app.biz.trn.vo.PayRsltCvo;
import com.bankle.app.biz.trn.vo.PayRsltSvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "지급 결과 통지", description = "지급 결과 통지 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class PayRsltCtrl {

    private final PayRsltSvc PayRsltSvc;

    private final CustomeModelMapper customeModelMapper;

    @Operation(summary = "지급 결과 통지 전송(A400)", description = "지급 결과 통지 전송(A400) 서비스")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "지급 결과 통지 전송(A400) 성공", content = @Content(schema = @Schema(implementation = PayRsltCvo.PayRsltReqCvo.class))),
    })
    @PostMapping("/trn/sendpayrslt")
    public ResponseEntity<?> save(@RequestBody PayRsltCvo.PayRsltReqCvo reqCvo) throws Exception {
        try {
            boolean valid = PayRsltSvc
                    .save(customeModelMapper
                            .mapping(reqCvo, PayRsltSvo.PayRsltInSvo.class));
            if (valid) {
                return ResData.SUCCESS(reqCvo, "성공");
            } else {
                return ResData.FAIL(reqCvo, "실패");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }
}
