package com.bankle.app.biz.trn.svc;

import com.bankle.app.biz.trn.vo.SendFaAskSvo;
import com.bankle.common.dto.TbWoCntrMasterDto;
import com.bankle.common.dto.TbWoTrnFa6100F1Dto;
import com.bankle.common.entity.TbCustBrnchMng;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoTrnFa6100F1Mapper;
import com.bankle.common.repo.TbCustBrnchMngRepository;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoTrnCommMasterRepository;
import com.bankle.common.repo.TbWoTrnFa6100F1Repository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.NumberUtil;
import com.bankle.common.wooriApi.biz.cntr.svc.CustBrnchMngSvc;
import com.bankle.common.wooriApi.socket.ins.sendSvc.Send6100F1Svc;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6100F1Svo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import jakarta.persistence.EntityManager;
import jakarta.validation.Valid;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class SendFaAskSvc {
    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;
    private final TbCustBrnchMngRepository tbCustBrnchMngRepository;
    private final CustomeModelMapper customeModelMapper;
    private final TbWoTrnFa6100F1Repository tbWoTrnFa6100F1Repository;
    private final TbWoTrnCommMasterRepository tbWoTrnCommMasterRepository;
    private final BizUtil bizUtil;
    private final Send6100F1Svc send6100F1Svc;
    private final CustBrnchMngSvc custBrnchMngSvc;
    private final String TG_DSC = "F1000";
    private final EntityManager entityManager;

    @Transactional
    public boolean save(@Valid SendFaAskSvo.SendFaAskInSvo inSvo) throws Exception {

        //------------------------------------------------------------------
        // 원장 생성
        //------------------------------------------------------------------
        String seq = bizUtil.getSeq(Sequence.TRANS);
        String newLoanNo = inSvo.getNewLoanNo();
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(inSvo.getLoanNo())
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));

        TbWoCntrMasterDto tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);
        //String prodNm = getProdNm(tbWoCntrMasterDto.getLndPrdtNm());
        String prodNm = inSvo.getBnkLndPrdtNm();
        inSvo.setBnkLndPrdtNm(prodNm);
        tbWoCntrMasterDto.setLoanNo(newLoanNo);
        tbWoCntrMasterDto.setBizNo(inSvo.getLwfmBizNo());
        tbWoCntrMasterDto.setLndKndCd(inSvo.getLndKndCd());
        tbWoCntrMasterDto.setFndUseCd(inSvo.getFndUseCd());
        //tbWoCntrMasterDto.setLndPrdtNm(inSvo.getBnkLndPrdtNm());
        tbWoCntrMasterDto.setLndPrdtNm(prodNm);
        tbWoCntrMasterDto.setStndAplYn(inSvo.getStndAplYn());
        tbWoCntrMasterDto.setMvhhdCnfmReqYn(inSvo.getMvhrCnfmReqYn());
        tbWoCntrMasterDto.setSlPrc(inSvo.getSlPrc());
        tbWoCntrMasterDto.setIsrnEntrAmt(inSvo.getIsrnEntrAmt());
        tbWoCntrMasterDto.setExecPlnAmt(inSvo.getLndAmt());
        tbWoCntrMasterDto.setExecPlnDt(inSvo.getLndPlnDt());
        tbWoCntrMasterDto.setExecDt(inSvo.getLndPlnDt());
        tbWoCntrMasterDto.setExecAmt(inSvo.getLndAmt());
        tbWoCntrMasterDto.setDbtrNm(inSvo.getDbtrNm());
        tbWoCntrMasterDto.setDbtrBirthDt(inSvo.getDbtrBirthDt());
        tbWoCntrMasterDto.setDbtrAddr(inSvo.getDbtrAddr());
        tbWoCntrMasterDto.setDbtrHpno(inSvo.getDbtrHpno());
        tbWoCntrMasterDto.setPwpsNm(inSvo.getPwpsNm());
        tbWoCntrMasterDto.setSlmnLndProc(inSvo.getSlmnLndProc());
        tbWoCntrMasterDto.setSrMembNo(inSvo.getSrMembNo());
        tbWoCntrMasterDto.setTrAmt(NumberUtil.toBigDecimal(inSvo.getTrAmt()));
        tbWoCntrMasterDto.setSellerNm1(inSvo.getSllNm1());
        tbWoCntrMasterDto.setSellerBirthDt1(inSvo.getSllBrDay1());
        tbWoCntrMasterDto.setSellerNm2(inSvo.getSllNm2());
        tbWoCntrMasterDto.setOwnLoanMaxAmt(NumberUtil.toBigDecimal(inSvo.getOwnLoanMaxAmt()));
        tbWoCntrMasterDto.setOwnLoanPlnAmt(NumberUtil.toBigDecimal(inSvo.getOwnLoanPlnAmt()));
        tbWoCntrMasterDto.setOwnLoanBankNm1(inSvo.getOwnLoanBnkNm1());
        tbWoCntrMasterDto.setOwnLoanBankNm2(inSvo.getOwnLoanBnkNm2());
        tbWoCntrMasterDto.setOwnLoanBankNm3(inSvo.getOwnLoanBnkNm3());
        tbWoCntrMasterDto.setOwnLoanBankNm4(inSvo.getOwnLoanBnkNm4());
        tbWoCntrMasterDto.setOwnLoanBankNm5(inSvo.getOwnLoanBnkNm5());
        tbWoCntrMasterDto.setCnsgnNm(inSvo.getCnsgnNm());
        tbWoCntrMasterDto.setTrstNm(inSvo.getTrstNm());
        tbWoCntrMasterDto.setBnfrNm(inSvo.getBnfrNm());
        tbWoCntrMasterDto.setNowLshDrNm(inSvo.getNowLessNm());
        tbWoCntrMasterDto.setRsrvItmB(inSvo.getRsrvItmB());
        tbWoCntrMasterDto.setOblMLnAprvNo(inSvo.getOblMLnAprvNo());
        tbWoCntrMasterDto.setOblTotCnt(NumberUtil.toInt(inSvo.getOblTotCnt()));
        tbWoCntrMasterDto.setOblGrpRnkNo(NumberUtil.toInt(inSvo.getOblGrpRnkNo()));

        Optional<TbCustBrnchMng> fndByNm = tbCustBrnchMngRepository.findAllByBrnchNm(inSvo.getBnkBrnchNm());
        if (fndByNm.isPresent()) {
            tbWoCntrMasterDto.setBnkBrnchCd(fndByNm.get().getBrnchCd());
        } else {
            tbWoCntrMasterDto.setBnkBrnchCd("999999");
        }
        tbWoCntrMasterDto.setBnkBrnchNm(inSvo.getBnkBrnchNm());
        tbWoCntrMasterDto.setBnkDrctrNm(inSvo.getBnkDrctrNm());
        tbWoCntrMasterDto.setBnkBrnchPhno(inSvo.getBnkBrnchPhno());
        tbWoCntrMasterRepository.save(TbWoCntrMasterMapper.INSTANCE.toEntity(tbWoCntrMasterDto));
        entityManager.flush();

        //------------------------------------------------------------------
        // 전문 상세 생성
        //------------------------------------------------------------------
        inSvo.setLoanNo(newLoanNo);
        inSvo.setChgDtm(LocalDateTime.now());
        log.debug("inSvo.getChgDtm : {}", inSvo.getChgDtm());
        tbWoTrnFa6100F1Repository.save(
                TbWoTrnFa6100F1Mapper.INSTANCE
                        .toEntity(customeModelMapper
                                .mapping(inSvo, TbWoTrnFa6100F1Dto.class)));
        entityManager.flush();


        //------------------------------------------------------------------
        // 전문 전송
        //------------------------------------------------------------------
        Send6100F1Svo.sendInVo sendInVo = Send6100F1Svo.sendInVo
                .builder()
                .loanNo(newLoanNo)
                .chgDtm(LocalDateTime.now())
                .tgDsc(TG_DSC)
                .bnkTgNo(inSvo.getBnkTgNo())
                .faTgNo(inSvo.getFaTgNo())
                .kosTgSndNo(seq)
                .tgSndDtm(LocalDateTime.now())
                .tgRcvDtm(inSvo.getTgRcvDtm())
                .resCd(inSvo.getResCd())
                .rsrvItmH(inSvo.getRsrvItmH())
                .bnkTtlReqNo(inSvo.getBnkTtlReqNo())
                .ttlArdEntrEane(inSvo.getTtlArdEntrEane())
                .ttlEntrCmpy(inSvo.getTtlEntrCmpy())
                .ttlScrtNo(inSvo.getTtlScrtNo())
                .lndDsc(inSvo.getLndDsc())
                .lndKndCd(inSvo.getLndKndCd())
                .fndUseCd(inSvo.getFndUseCd())
                .bnkLndPrdtCd(inSvo.getBnkLndPrdtCd())
                .bnkLndPrdtNm(inSvo.getBnkLndPrdtNm())
                .grntDsc(inSvo.getGrntDsc())
                .stndAplYn(inSvo.getStndAplYn())
                .rrcpCnfmReqYn(inSvo.getRrcpCnfmReqYn())
                .mvhrCnfmReqYn(inSvo.getMvhrCnfmReqYn())
                .bfSrvtrgtReqYn(inSvo.getBfSrvtrgtReqYn())
                .afSrvtrgtReqYn(inSvo.getAfSrvtrgtReqYn())
                .rgstrUnqNo1(inSvo.getRgstrUnqNo1())
                .rgstrUnqNo2(inSvo.getRgstrUnqNo2())
                .rgstrUnqNo3(inSvo.getRgstrUnqNo3())
                .rgstrUnqNo4(inSvo.getRgstrUnqNo4())
                .rgstrUnqNo5(inSvo.getRgstrUnqNo5())
                .rlesDsc(inSvo.getRlesDsc())
                .trgtRlesDsc(inSvo.getTrgtRlesDsc())
                .trgtRlesAddr(inSvo.getTrgtRlesAddr())
                .sscptAskDt(inSvo.getSscptAskDt())
                .lndPlnDt(inSvo.getLndPlnDt())
                .slPrc(inSvo.getSlPrc())
                .isrnEntrAmt(inSvo.getIsrnEntrAmt())
                .lndPrd(inSvo.getLndPrd())
                .lndAmt(inSvo.getLndAmt())
                .bnkFxcltRgstrRnk(inSvo.getBnkFxcltRgstrRnk())
                .bnkFxcltBndMaxAmt(inSvo.getBnkFxcltBndMaxAmt())
                .dbtrNm(inSvo.getDbtrNm())
                .dbtrBirthDt(inSvo.getDbtrBirthDt())
                .dbtrAddr(inSvo.getDbtrAddr())
                .dbtrPhno(inSvo.getDbtrPhno())
                .dbtrHpno(inSvo.getDbtrHpno())
                .pwpsNm(inSvo.getPwpsNm())
                .pwpsBirthDt(inSvo.getPwpsBirthDt())
                .pwpsAddr(inSvo.getPwpsAddr())
                .pwpsPhno(inSvo.getPwpsPhno())
                .pwpsHpno(inSvo.getPwpsHpno())
                .rmkFct(inSvo.getRmkFct())
                .lndHndgSlfDsc(inSvo.getLndHndgSlfDsc())
                .bnkBrnchNm(inSvo.getBnkBrnchNm())
                .bnkDrctrNm(inSvo.getBnkDrctrNm())
                .bnkBrnchPhno(inSvo.getBnkBrnchPhno())
                .bnkDrctrHp(inSvo.getBnkDrctrHp())
                .bnkBrnchFax(inSvo.getBnkBrnchFax())
                .bnkBrnchAddr(inSvo.getBnkBrnchAddr())
                .slmnNm(inSvo.getSlmnNm())
                .slmnCmpyNm(inSvo.getSlmnCmpyNm())
                .slmnPhno(inSvo.getSlmnPhno())
                .lwfmNm(inSvo.getLwfmNm())
                .lwfmBizNo(inSvo.getLwfmBizNo())
                .dbtrWdngPlnYn(inSvo.getDbtrWdngPlnYn())
                .rrcpCnfmYn(inSvo.getRrcpCnfmYn())
                .spusNm(inSvo.getSpusNm())
                .wdngPlnDt(inSvo.getWdngPlnDt())
                .rschWkDdlnReqDt(inSvo.getRschWkDdlnReqDt())
                .isrnPrmm(inSvo.getIsrnPrmm())
                .rfrLnAprvNo(newLoanNo.concat("000"))
                .rgstrMtdDsc(inSvo.getRgstrMtdDsc())
                .rgstrReqNo(inSvo.getRgstrReqNo())
                .odprtaRpyEane(inSvo.getOdprtaRpyEane())
                .eltnEstbsLwyrNm(inSvo.getEltnEstbsLwyrNm())
                .eltnEstbsLwyrBizNo(inSvo.getEltnEstbsLwyrBizNo())
                .eltnRpyLoaAplYn(inSvo.getEltnRpyLoaAplYn())
                .eltnRpyLoaSqn(inSvo.getEltnRpyLoaSqn())
                .eltnRpyLoaCtfcNo(inSvo.getEltnRpyLoaCtfcNo())
                .whlRpyCnt(inSvo.getWhlRpyCnt())
                .whlRpyAmt(inSvo.getWhlRpyAmt())
                .ebnkRpyTotAmt(inSvo.getEbnkRpyTotAmt())
                .dfbnkRpyTotAmt(inSvo.getDfbnkRpyTotAmt())
                .rpyTrgtRnkNo1(inSvo.getRpyTrgtRnkNo1())
                .rpyTrgtAcptDt1(inSvo.getRpyTrgtAcptDt1())
                .rpyTrgtAcptNo1(inSvo.getRpyTrgtAcptNo1())
                .rpyTrgtBndAmt1(inSvo.getRpyTrgtBndAmt1())
                .rpyTrgtRnkNo2(inSvo.getRpyTrgtRnkNo2())
                .rpyTrgtAcptDt2(inSvo.getRpyTrgtAcptDt2())
                .rpyTrgtAcptNo2(inSvo.getRpyTrgtAcptNo2())
                .rpyTrgtBndAmt2(inSvo.getRpyTrgtBndAmt2())
                .rpyTrgtRnkNo3(inSvo.getRpyTrgtRnkNo3())
                .rpyTrgtAcptDt3(inSvo.getRpyTrgtAcptDt3())
                .rpyTrgtAcptNo3(inSvo.getRpyTrgtAcptNo3())
                .rpyTrgtBndAmt3(inSvo.getRpyTrgtBndAmt3())
                .rpyTrgtRnkNo4(inSvo.getRpyTrgtRnkNo4())
                .rpyTrgtAcptDt4(inSvo.getRpyTrgtAcptDt4())
                .rpyTrgtAcptNo4(inSvo.getRpyTrgtAcptNo4())
                .rpyTrgtBndAmt4(inSvo.getRpyTrgtBndAmt4())
                .rpyTrgtRnkNo5(inSvo.getRpyTrgtRnkNo5())
                .rpyTrgtAcptDt5(inSvo.getRpyTrgtAcptDt5())
                .rpyTrgtAcptNo5(inSvo.getRpyTrgtAcptNo5())
                .rpyTrgtBndAmt5(inSvo.getRpyTrgtBndAmt5())
                .afrgstrScrtYn(inSvo.getAfrgstrScrtYn())
                .slmnLndProc(inSvo.getSlmnLndProc())
                .srMembNo(inSvo.getSrMembNo())
                .trAmt(inSvo.getTrAmt())
                .sllNm1(inSvo.getSllNm1())
                .sllBrDay1(inSvo.getSllBrDay1())
                .sllNm2(inSvo.getSllNm2())
                .sllBrDay2(inSvo.getSllBrDay2())
                .ownLoanMaxAmt(inSvo.getOwnLoanMaxAmt())
                .ownLoanPlnAmt(inSvo.getOwnLoanPlnAmt())
                .ownLoanBankNm1(inSvo.getOwnLoanBnkNm1())
                .ownLoanBankNm2(inSvo.getOwnLoanBnkNm2())
                .ownLoanBankNm3(inSvo.getOwnLoanBnkNm3())
                .ownLoanBankNm4(inSvo.getOwnLoanBnkNm4())
                .ownLoanBankNm5(inSvo.getOwnLoanBnkNm5())
                .cnsgnNm(inSvo.getCnsgnNm())
                .trstNm(inSvo.getTrstNm())
                .bnfrNm(inSvo.getBnfrNm())
                .nowLessNm(inSvo.getNowLessNm())
                .rsrvItmB(inSvo.getRsrvItmB())
                .oblMLnAprvNo(inSvo.getOblMLnAprvNo())
                .oblTotCnt(inSvo.getOblTotCnt())
                .oblGrpRnkNo(inSvo.getOblGrpRnkNo())
                .lnAprvNo2(inSvo.getLnAprvNo2())
                .build();
        CheckResponseSvo checkResponseSvo = send6100F1Svc.sendAndResponse(sendInVo);
        return "000".equals(checkResponseSvo.getRescode());
    }

    String getProdNm(String prodNm) {
        if (prodNm == null || prodNm.isEmpty()) {
            return "";
        }
        if (prodNm.contains("우리")) {
            return prodNm.replace("우리", "");
        } else {
            return prodNm;
        }
    }
}
