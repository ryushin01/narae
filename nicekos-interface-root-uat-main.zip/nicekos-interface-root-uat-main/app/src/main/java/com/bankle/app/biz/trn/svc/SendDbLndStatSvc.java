package com.bankle.app.biz.trn.svc;

import com.bankle.app.biz.trn.vo.SendDbLndStatSvo;
import com.bankle.common.dto.TbWoCntrMasterDto;
import com.bankle.common.dto.TbWoTrnDb6300W3Dto;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoTrnDb6300W3Mapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoTrnDb6300W3Repository;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.wooriApi.socket.ins.sendSvc.Send6300W3Svc;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6300W3Svo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import jakarta.persistence.EntityManager;
import jakarta.validation.Valid;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Slf4j
@Service
@AllArgsConstructor
public class SendDbLndStatSvc {

    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;

    private final TbWoTrnDb6300W3Repository tbWoTrnDb6300W3Repository;

    private final EntityManager entityManager;

    private final CustomeModelMapper customeModelMapper;

    private final Send6300W3Svc send6300W3Svc;
    private final String TG_DSC = "W3000";

    @Transactional
    public boolean save(@Valid SendDbLndStatSvo.SendDbLndStatInSvo inSvo) throws Exception {
        //------------------------------------------------------------------
        // 원장 생성
        //------------------------------------------------------------------
        String newLoanNo = inSvo.getNewLoanNo();
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(inSvo.getLoanNo())
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));
        log.debug("tbWoCntrMaster.loanNo : {}", tbWoCntrMaster.getLoanNo());

        if (!tbWoCntrMasterRepository.existsByLoanNo(newLoanNo)) {
            TbWoCntrMasterDto tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);
            tbWoCntrMasterDto.setLoanNo(newLoanNo);
            tbWoCntrMasterRepository.save(TbWoCntrMasterMapper.INSTANCE.toEntity(tbWoCntrMasterDto));
            entityManager.flush();
        }
        //------------------------------------------------------------------
        // 전문 상세 생성
        //------------------------------------------------------------------
        inSvo.setLoanNo(newLoanNo);
        inSvo.setChgDtm(LocalDateTime.now());
        log.debug("inSvo.getChgDtm : {}", inSvo.getChgDtm());
        log.debug("inSvo.getRegDtm : {}", inSvo.getRegDtm());
        tbWoTrnDb6300W3Repository.save(
                TbWoTrnDb6300W3Mapper.INSTANCE
                        .toEntity(customeModelMapper
                                .mapping(inSvo, TbWoTrnDb6300W3Dto.class)));
        entityManager.flush();
        //------------------------------------------------------------------
        // 전문 전송
        //------------------------------------------------------------------
        log.debug("inSvo.regDtm : {}", inSvo.getRegDtm());
        Send6300W3Svo.sendInVo sendInVo = Send6300W3Svo.sendInVo
                .builder()
                .loanNo(newLoanNo)
                .chgDtm(LocalDateTime.now())
                .tgDsc(TG_DSC)
                .resCd(inSvo.getResCd())
                .lndAgncCd(inSvo.getLndAgncCd())
                .bnkTgTrnsDtm(inSvo.getBnkTgTrnsDtm())
                .dbTgTrnsDtm(inSvo.getDbTgTrnsDtm())
                .bnkTgNo(inSvo.getBnkTgNo())
                .dbTgNo(inSvo.getDbTgNo())
                .rsrvItmH(inSvo.getRsrvItmH())
                .bnkAskNo(inSvo.getBnkAskNo())
                .dbMngNo(inSvo.getDbMngNo())
                .kosTgTrnsDtm(inSvo.getKosTgTrnsDtm())
                .kosTgNo(inSvo.getKosTgNo())
                .nttnYn(inSvo.getNttnYn())
                .endNotiDt(inSvo.getEndNotiDt())
                .endnotiTm(inSvo.getEndnotiTm())
                .bnkDrctrNm(inSvo.getBnkDrctrNm())
                .bnkDrctrPhno(inSvo.getBnkDrctrPhno())
                .rsrvItmB(inSvo.getRsrvItmB())
                .regDtm(inSvo.getRegDtm())
                .build();
        CheckResponseSvo checkResponseSvo = send6300W3Svc.sendAndResponse(sendInVo);
        return "000".equals(checkResponseSvo.getRescode());
    }
}
