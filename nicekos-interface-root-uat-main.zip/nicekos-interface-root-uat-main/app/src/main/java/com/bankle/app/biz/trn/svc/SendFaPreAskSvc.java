package com.bankle.app.biz.trn.svc;


import com.bankle.app.biz.trn.vo.SendFaPreAskSvo;
import com.bankle.common.dto.TbWoCntrMasterDto;
import com.bankle.common.dto.TbWoTrnFa6500F5Dto;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoTrnFa6500F5Mapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoTrnCommMasterRepository;
import com.bankle.common.repo.TbWoTrnFa6500F5Repository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.wooriApi.socket.ins.sendSvc.Send6500F5Svc;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6500F5Svo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import jakarta.persistence.EntityManager;
import jakarta.validation.Valid;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class SendFaPreAskSvc {

    private final Send6500F5Svc send6500F5Svc;
    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;
    private final TbWoTrnFa6500F5Repository tbWoTrnFa6500F5Repository;
    private final CustomeModelMapper customeModelMapper;
    private final BizUtil bizUtil;
    private final String TG_DSC = "F5000";
    private final EntityManager entityManager;
    private final TbWoTrnCommMasterRepository tbWoTrnCommMasterRepository;

    @Transactional(rollbackFor = {Exception.class})
    public boolean save(@Valid SendFaPreAskSvo.SendFaPreAskInSvo inSvo) throws Exception {

        //------------------------------------------------------------------
        // 원장 생성
        //------------------------------------------------------------------
        String seq = bizUtil.getSeq(Sequence.TRANS);
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(inSvo.getLoanNo())
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));

        String newLoanNo = inSvo.getNewLoanNo();
        TbWoCntrMasterDto tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);
        tbWoCntrMasterDto.setLoanNo(newLoanNo);
        tbWoCntrMasterDto.setLndKndCd(inSvo.getLndKndCd());
        tbWoCntrMasterDto.setFndUseCd(inSvo.getFndUseCd());
        tbWoCntrMasterDto.setLndPrdtNm(inSvo.getBnkLndProdtNm());
        tbWoCntrMasterDto.setStndAplYn(inSvo.getStndAplYn());
        tbWoCntrMasterDto.setMvhhdCnfmReqYn(inSvo.getMvLwyrCnfmYn());
        tbWoCntrMasterDto.setSlPrc(inSvo.getSlPrc());
        tbWoCntrMasterDto.setIsrnEntrAmt(new BigDecimal(inSvo.getIsrnEntrAmt()));
        tbWoCntrMasterDto.setExecPlnAmt(inSvo.getLndAmt());
        tbWoCntrMasterDto.setExecPlnDt(inSvo.getLndPlnDt());
        tbWoCntrMasterDto.setDbtrNm(inSvo.getDbrtNm());
        tbWoCntrMasterDto.setDbtrBirthDt(inSvo.getDbtrBirthDt());
        tbWoCntrMasterDto.setDbtrAddr(inSvo.getDbtrAddr());
        tbWoCntrMasterDto.setDbtrHpno(inSvo.getDbtrHpno());
        tbWoCntrMasterDto.setPwpsNm(inSvo.getPwpsNm());
        tbWoCntrMasterDto.setBnkBrnchCd(inSvo.getBnkBrnchCd());
        tbWoCntrMasterDto.setBnkBrnchNm(inSvo.getBnkBrnchNm());
        tbWoCntrMasterDto.setBnkDrctrNm(inSvo.getBnkDrctrNm());
        tbWoCntrMasterDto.setBnkBrnchPhno(inSvo.getBnkBrnchPhno());
        tbWoCntrMasterRepository.save(TbWoCntrMasterMapper.INSTANCE.toEntity(tbWoCntrMasterDto));
        entityManager.flush();

        //------------------------------------------------------------------
        // 전문 상세 생성
        //------------------------------------------------------------------
        inSvo.setLoanNo(newLoanNo);
        inSvo.setChgDtm(LocalDateTime.now());
        tbWoTrnFa6500F5Repository.save(
                TbWoTrnFa6500F5Mapper.INSTANCE
                .toEntity(customeModelMapper
                        .mapping(inSvo, TbWoTrnFa6500F5Dto.class)));
        entityManager.flush();

        //------------------------------------------------------------------
        // 전문 전송
        //------------------------------------------------------------------
        Send6500F5Svo.sendInVo sendInVo = Send6500F5Svo.sendInVo
                .builder()
                .loanNo(newLoanNo)
                .chgDtm(LocalDateTime.now())
                .tgDsc(TG_DSC)
                .bnkTgNo(inSvo.getBnkTgNo())
                .faTgNo(inSvo.getFaTgNo())
                .kosTgSndNo(seq)
                .tgSndDtm(LocalDateTime.now())
                .tgRcvDtm(inSvo.getTgRcvDtm())
                .resCd(inSvo.getResCd())
                .lnAprovNo(newLoanNo)
                .rsrvItmH(inSvo.getRsrvItmH())
                .lndDsc(inSvo.getLndDsc())
                .lndKndCd(inSvo.getLndKndCd())
                .fndUseCd(inSvo.getFndUseCd())
                .bnkLndProdtCd(inSvo.getBnkLndProdtCd())
                .bnkLndProdtNm(inSvo.getBnkLndProdtNm())
                .stndApnYn(inSvo.getStndAplYn())
                .mvLwyrCnfmYn(inSvo.getMvLwyrCnfmYn())
                .rgstrUnqNo1(inSvo.getRgstrUnqNo1())
                .rgstrUnqNo2(inSvo.getRgstrUnqNo2())
                .rgstrUnqNo3(inSvo.getRgstrUnqNo3())
                .rgstrUnqNo4(inSvo.getRgstrUnqNo4())
                .rgstrUnqNo5(inSvo.getRgstrUnqNo5())
                .rlesDsc(inSvo.getRlesDsc())
                .trgtRlesDsc(inSvo.getTrgtRlesDsc())
                .trgtRlesAddr(inSvo.getTrgtRlesAddr())
                .bfAskDt(inSvo.getBfAskDt())
                .lndPlnDt(inSvo.getLndPlnDt())
                .slPrc(inSvo.getSlPrc().toString())
                .scrtevlAmt(inSvo.getScrtevlAmt())
                .isrnEntrAmt(inSvo.getIsrnEntrAmt())
                .lndAmt(inSvo.getLndAmt().toString())
                .bnkfxcltRgstrRnk(inSvo.getBnkfxcltRgstrRnk())
                .dbtrNm(inSvo.getDbrtNm())
                .dbtrBirthDt(inSvo.getDbtrBirthDt())
                .dbtrAddr(inSvo.getDbtrAddr())
                .dbtrPhno(inSvo.getDbtrPhno())
                .dbtrHpno(inSvo.getDbtrHpno())
                .pwpsNm(inSvo.getPwpsNm())
                .pwpsBirthDt(inSvo.getPwpsBirthDt())
                .pwpsAddr(inSvo.getPwpsAddr())
                .pwpsPhno(inSvo.getPwpsPhno())
                .pwpsHpno(inSvo.getPwpsHpno())
                .rmkFct(inSvo.getRmkFc())
                .lndHndgSlfDsc(inSvo.getLndHndgSlfDsc())
                .bnkBrnchNm(inSvo.getBnkBrnchNm())
                .bnkDrctrNm(inSvo.getBnkDrctrNm())
                .bnkBrnchPhno(inSvo.getBnkBrnchPhno())
                .bnkDrctrHp(inSvo.getBnkDrctrHp())
                .bnkBrnchFax(inSvo.getBnkBrnchFax())
                .bnkBrnchAddr(inSvo.getBnkBrnchAddr())
                .slmnCmpyNm(inSvo.getSlmnCmpyNM())
                .slmnPhno(inSvo.getSlmnPhno())
                .rfrLnAprvNo(newLoanNo.concat("000"))
                .rgstrMtdDsc(inSvo.getRgstrMtdDsc())
                .odprtRpyEane(inSvo.getOdprtRpyEane())
                .eltnEstbsLwyrNm(inSvo.getEltnEstbsLwyrNm())
                .eltnEstbsLwyrBizNo(inSvo.getEltnEstbsLwyrBizNo())
                .slCntrctEane(inSvo.getSlCntrctEane())
                .slCntrctFlnm(inSvo.getSlCntrctFlnm())
                .afrgstrScrtYn(inSvo.getAfrgstrScrtYn())
                .bnkBrnchCd(inSvo.getBnkBrnchCd())
                .rsrvItmB(inSvo.getRsrvItmB())
                .build();
        CheckResponseSvo checkResponseSvo = send6500F5Svc.sendAndResponse(sendInVo);
        return "000".equals(checkResponseSvo.getRescode());
    }
}
