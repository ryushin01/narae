package com.bankle.app.biz.trn.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;


public class PayRsltCvo {

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class PayRsltReqCvo {

        @Schema(description = "여신번호")
        private String loanNo;

        @Schema(description = "전문길이")
        private String trLn;

        @Schema(description = "전문종별코드")
        private String trCd;

        @Schema(description = "거래구분코드")
        private String trTpCd;

        @Schema(description = "관리번호")
        private String loNo;

//        @Schema(description = "식별번호")
//        private String trSq;
//
//        @Schema(description = "송신일자 (YYYYMMDDHHMMSS 형식)")
//        private String reqDttm;
//
//        @Schema(description = "수신일자 (YYYYMMDDHHMMSS 형식)")
//        private String resDttm;
//
//        @Schema(description = "응답코드")
//        private String resCd;
//
//        @Schema(description = "여신승인신청번호")
//        private String approvalNum;

        @Schema(description = "지급구분")
        private String payType;

        @Schema(description = "지급요청 은행코드")
        private String payBankCd;

        @Schema(description = "지급요청 금액")
        private String payAmt;

        @Schema(description = "이체 결과 코드")
        private String transResultCd;

        @Schema(description = "")
        private String filler;
    }
}
