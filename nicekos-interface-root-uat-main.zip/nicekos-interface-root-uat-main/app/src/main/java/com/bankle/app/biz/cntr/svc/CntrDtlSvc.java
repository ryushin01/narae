package com.bankle.app.biz.cntr.svc;

import com.bankle.app.biz.cntr.dao.CntrDtlDao;
import com.bankle.app.biz.cntr.vo.CntrSvo;
import com.bankle.common.dto.TbWoCntrMasterDto;
import com.bankle.common.entity.TbCustBrnchMng;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.NumberUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;


@Slf4j
@Service
@RequiredArgsConstructor
public class CntrDtlSvc {

    private final CntrDtlDao cntrDtlDao;
    private final CustomeModelMapper mapper;
    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;

    @Transactional(rollbackFor = {Exception.class})
    public List<CntrSvo.CntrDtlOutSvo> getByLoanNo(String loanNo) throws Exception {
        log.debug("START getByLoanNo :" + loanNo);
        CntrSvo.CntrDtlInSvo inSvo = CntrSvo.CntrDtlInSvo.builder()
                .loanNo(loanNo)
                .build();
        return cntrDtlDao.selCntrDetailOutSvo(inSvo);
    }

    @Transactional(rollbackFor = {Exception.class})
    public CntrSvo.CntrInfoOutSvo updateCntrInfo(CntrSvo.CntrInfoInSvo inSvo) throws Exception {
        try {
            log.debug("START updateCntrInfo inSvo:" + inSvo.toString());
            TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(inSvo.getLoanNo())
                    .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));

            TbWoCntrMasterDto tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);
            tbWoCntrMasterDto.setLoanNo(inSvo.getLoanNo());
            tbWoCntrMasterDto.setKndCd(inSvo.getKndCd());
            tbWoCntrMasterDto.setLndKndCd(inSvo.getLndKndCd());
            tbWoCntrMasterDto.setRgstrGbCd(inSvo.getRgstrGbCd());
            tbWoCntrMasterDto.setStatCd(inSvo.getStatCd());
            tbWoCntrMasterDto.setLndStatCd(inSvo.getLndStatCd());
            tbWoCntrMasterDto.setExecPlnAmt(inSvo.getExecPlnAmt());
            tbWoCntrMasterDto.setExecAmt(inSvo.getExecAmt());
            tbWoCntrMasterDto.setExecPlnDt(inSvo.getExecPlnDt());
            tbWoCntrMasterDto.setExecDt(inSvo.getExecDt());
            tbWoCntrMasterDto.setSlPrc(inSvo.getSlPrc());
            tbWoCntrMasterDto.setBnkBrnchCd(inSvo.getBnkBrnchCd());
            tbWoCntrMasterDto.setBizNo(inSvo.getBizNo());
            tbWoCntrMasterDto.setTrnInCnt(inSvo.getTrnInCnt());
            tbWoCntrMasterDto.setRefndAcctRegYn(inSvo.getRefndAcctRegYn());
            tbWoCntrMasterDto.setRefndAcctRegDate(inSvo.getRefndAcctRegDate());
            tbWoCntrMasterDto.setEltnSecuredYn(inSvo.getEltnSecuredYn());
            tbWoCntrMasterDto.setExecAmtChangYn(inSvo.getExecAmtChangYn());
            tbWoCntrMasterDto.setEstmRegYn(inSvo.getEstmRegYn());
            tbWoCntrMasterDto.setRgstrRegYn(inSvo.getRgstrRegYn());
            tbWoCntrMasterDto.setPayRegYn(inSvo.getPayRegYn());
            tbWoCntrMasterDto.setEstmCnfmYn(inSvo.getEstmCnfmYn());
            tbWoCntrMasterDto.setLndAmtPayYn(inSvo.getLndAmtPayYn());
            tbWoCntrMasterDto.setRevisionCheckYn(inSvo.getRevisionCheckYn());
            tbWoCntrMasterDto.setEstbsCntrFnYn(inSvo.getEstbsCntrFnYn());
            tbWoCntrMasterDto.setSlCntrctEane(inSvo.getSlCntrctEane());
            tbWoCntrMasterDto.setMvhhdSbmtYn(inSvo.getMvhhdSbmtYn());
            tbWoCntrMasterDto.setRrcpSbmtYn(inSvo.getRrcpSbmtYn());
            tbWoCntrMasterDto.setRtalSbmtYn(inSvo.getRtalSbmtYn());
            tbWoCntrMasterDto.setCndtCntrYn(inSvo.getCndtCntrYn());
            tbWoCntrMasterDto.setLwyrDiffBankCd8(inSvo.getLwyrDiffBankCd8());
            tbWoCntrMasterDto.setLwyrDiffBankCd10(inSvo.getLwyrDiffBankCd10());
            tbWoCntrMasterRepository.save(TbWoCntrMasterMapper.INSTANCE.toEntity(tbWoCntrMasterDto));
            log.debug("END updateCntrInfo tbWoCntrMasterDto :" + tbWoCntrMasterDto.toString());
            return CntrSvo.CntrInfoOutSvo.builder()
                    .loanNo(tbWoCntrMasterDto.getLoanNo())
                    .build();
        } catch(Exception e) {
            throw new Exception(e.getMessage());
        }
    }
}
