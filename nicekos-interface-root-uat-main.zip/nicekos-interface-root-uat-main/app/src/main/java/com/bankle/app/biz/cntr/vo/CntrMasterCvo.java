package com.bankle.app.biz.cntr.vo;


import com.bankle.common.vo.PageResData;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class CntrMasterCvo {
    /*================================================================================================================*/

    /**
     * 원장 리스트 조회
     */
    @Getter
    @Setter
    public static class CntrLstReqCvo {
        /**
         * 여신번호
         */
        @Schema(example = "22371208572")
        private String loanNo;
        /**
         * 차주명
         */
        @Schema(example = "박연진")
        private String dbtrNm;
        /**
         * 차주전화번호
         */
        @Schema(example = "01012345678")
        private String dbtrHpno;
        /**
         * 페이지 번호
         */
        @Schema(example = "0", description = "페이지 번호  번째부터")
        private Integer page;

        /**
         * Page 번호
         */
        @Schema(example = "20", description = "페이지 Size")
        private Integer pageSize;
    }

    @Getter
    @Setter
    public static class CntrLstCvo extends PageResData {
        List<CntrLstResCvo> list;
    }

    @Getter
    @Setter
    public static class CntrLstResCvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        private String bnkGbCd;
        /**
         * 은행구분명
         */
        private String bnkNm;
        /**
         * 지점명
         */
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;
        /**
         * 대출종류명
         */
        private String lndKndNm;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 상태명
         * */
        private String statNm;

        /**
         * 대출상태코드
         */
        private String lndStatCd;
        /**
         * 대출상태명
         */
        private String lndStatNm;
        /**
         * 등기 구분 코드
         */
        private String rgstrGbCd;
        /**
         * 등기 구분명
         */
        private String rgstrGbNm;
        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        private String dbtrAddr;
        /**
         * 차주 핸드폰 번호
         */
        private String dbtrHpno;
        /**
         * 담보제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰 번호
         */
        private String pwpsHpno;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사타은행코드1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사타은행코드2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사타은행코드3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사타은행코드4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사타은행코드5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사타은행코드6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사타은행코드7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사타은행코드8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사타은행코드9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사타은행코드10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지 키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출구분명
         */
        private String kndNm;
        /**
         * 대출물건지주소(asis:address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(ASIS:M_APPROVAL_NUM)
         */
        private String grpNo;
        /**
         * 비고
         */
        private String rmk;
        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 전문인입횟수
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록 일자
         */
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String regifRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estmCntrFnYn;
        /**
         * 매매 계약서 유무
         */
        private String slCntrctEane;
        /**
         * 매매 계약서 파일명
         */
        private String slCntrctFlnm;
        /**
         * 전입세대열람원 제출여부
         */
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        private String rrcpSbMtYn;
        /**
         * 수정임대차 계약서 제출 여부
         */
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        private String cndtCntrYn;
        /**
         * 등기신청번호 등록여부
         */
        private String rgstrAcptSbmtYn;
        /**
         * 이전등기 가능 법무사 유무
         */
        private String cnvntLwyrYn;

        private String offRgstrYn;
        private String rdnmStndAddr;
        private String a300Send;
        private String stndAplYn;
    }
    /*================================================================================================================*/

    /**
     * 여신번호로 원장 조회
     */
    @Getter
    @Setter
    public static class FndByLoanNoReqCvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 차주명
         */
        private String dbtrNm;
    }
    @Getter
    @Setter
    public static class FndByLoanNoResCvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        private String bankGbCd;
        /**
         * 지점명
         */
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 대출상태코드
         */
        private String lndStatCd;
        /**
         * 이전, 설정등기 구분코드
         */
        private String rgstrGbCd;
        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주 생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        private String dbtrAddr;
        /**
         * 차주 핸드폰번호
         */
        private String dbtrHpno;
        /**
         * 매도인명
         */
        private String slrNm;
        /**
         * 매도인 생년월일
         */
        private String slrBirthDtm;
        /**
         * 담보 제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰번호
         */
        private String pwpsHpno;
        /**
         * 실행예정금액
         */
        private BigDecimal execPlnAmt;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사 타 은행코드 1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사 타 은행코드 2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사 타 은행코드 3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사 타 은행코드 4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사 타 은행코드 5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사 타 은행코드 6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사 타 은행코드 7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사 타 은행코드 8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사 타 은행코드 9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사 타 은행코드 10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출물건지주소(asis : address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(asis : M_APPROVAL_NUM)
         */
        private String grpNo;
        /**
         * 비고
         */
        private String rmk;
        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 금액수정대상여부
         */
        private String amtModTrgtYn;
        /**
         * 전문인입횟수(6100 전문에 한함)
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록한 당일인지 여부
         */
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String rgstrRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estbsCntrFnYn;
        /**
         * 매매계약서 유무
         */
        private String slCntrctEane;
        /**
         * 매매계약서 파일명
         */
        private String slCntrctFlNm;
        /**
         * 전입세대열람원 제출여부
         */
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        private String rrcpSbmtYn;
        /**
         * 수정임대차 계약서 제출여부
         */
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        private String cndtCntrYn;

        private String offRgstrYn;
        private String a300Send;
        private String stndAplYn;
    }

    /*================================================================================================================*/

    /**
     * 여신승인신청번호로 BK1MC0917M조회
     */
    @Getter
    @Setter
    public static class ApprNumReqCvo {
        /**
         * 여신승인신청번호
         */
        @Schema(example = "22484120984", description = "여신승인신청번호")
        private String approvalNum;
    }

    @Getter
    @Setter
    public static class ApprNumResCvo {
        /**
         * 식별번호
         */
        private String seq;

        /**
         * 전문이름
         */
        private String trnName;
        /**
         * 전문코드업무구분
         */
        private String trnKnd;
        /**
         * 응답완료코드
         */
        private String resCode;
        /**
         * 응답완료명
         */
        private String resName;
        /**
         * 여신승인신청번호
         */
        private String approvalNum;
        /**
         * 은행코드
         */
        private String bankCode;
        /**
         * 은행명
         */
        private String bankName;
        /**
         * 구분
         */
        private String gubun;
        /**
         * 전송 구분코드
         */
        private String tgDsc;
        /**
         * 전송상태코드
         */
        private String trnsStc;
        /**
         * 전송상태명
         */
        private String trnsStcNm;
        /**
         * 요청일시
         */
        private String reqDttm;
    }
    /*================================================================================================================*/

    /**
     * 원장 수정
     */
    @Getter
    @Setter
    public static class UpdCntrReqCvo {
        /**
         * 여신번호
         */
        @Schema(example = "22381020430", description = "여신번호")
        @NotBlank(message = "여신번호는 null일 수 없으며, 필수 값입니다.")
        private String loanNo;
        /**
         * 사업자등록번호
         */
        @Schema(example = "0000000987")
        @NotBlank(message = "사업자등록번호는 null일 수 없으며, 필수 값입니다.")
        private String bizNo;
        /**
         * 보험구분코드
         */
        @Schema(example = "FA")
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        @Schema(example = "020005")
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        @Schema(example = "020")
        private String bnkGbCd;
        /**
         * 지점명
         */
        @Schema(example = "오산금융센터")
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        @Schema(example = "서동현")
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        @Schema(example = "0328375410")
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        @Schema(example = "02")
        private String lndKndCd;
        /**
         * 상태코드
         */
        @Schema(example = "01")
        private String statCd;
        /**
         * 대출상태코드
         */
        @Schema(example = "31")
        private String lndStatCd;
        /**
         * 등기 구분 코드
         */
        @Schema(example = "01")
        private String rgstrGbCd;
        /**
         * 대출상품명
         */
        @Schema(example = "아낌e-보금자리론")
        private String lndPrdtNm;
        /**
         * 차주명
         */
        @Schema(example = "조재평")
        private String dbtrNm;
        /**
         * 차주생년월일
         */
        @Schema(example = "9307131000000")
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        @Schema(example = "대구 남구 중앙대로 187")
        private String dbtrAddr;
        /**
         * 차주 핸드폰 번호
         */
        @Schema(example = "01099274288")
        private String dbtrHpno;
        /**
         * 담보제공자명
         */
        @Schema(example = "아무개")
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        @Schema(example = "9307131000000")
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰 번호
         */
        @Schema(example = "01028260620")
        private String pwpsHpno;
        /**
         * 실행예정금액
         */
        @Schema(example = "100000000")
        private BigDecimal execPlnAmt;
        /**
         * 실행예정일자
         */
        @Schema(example = "20220801")
        private String execPlnDt;
        /**
         * 실행금액
         */
        @Schema(example = "15000000")
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        @Schema(example = "20220801")
        private String execDt;
        /**
         * 매매가액
         */
        @Schema(example = "1500000")
        private BigDecimal slPrc;
        /**
         * 법무사타은행코드1
         */
        @Schema(example = "0")
        private String lwyrDiffBankCd1;
        /**
         * 법무사타은행코드2
         */
        @Schema(example = "0")
        private String lwyrDiffBankCd2;
        /**
         * 법무사타은행코드3
         */
        @Schema(example = "0")
        private String lwyrDiffBankCd3;
        /**
         * 법무사타은행코드4
         */
        @Schema(example = "0")
        private String lwyrDiffBankCd4;
        /**
         * 법무사타은행코드5
         */
        @Schema(example = "0")
        private String lwyrDiffBankCd5;
        /**
         * 법무사타은행코드6
         */
        @Schema(example = "0")
        private String lwyrDiffBankCd6;
        /**
         * 법무사타은행코드7
         */
        @Schema(example = "0")
        private String lwyrDiffBankCd7;
        /**
         * 법무사타은행코드8
         */
        @Schema(example = "0")
        private String lwyrDiffBankCd8;
        /**
         * 법무사타은행코드9
         */
        @Schema(example = "0")
        private String lwyrDiffBankCd9;
        /**
         * 법무사타은행코드10
         */
        @Schema(example = "0")
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        @Schema(example = "")
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        @Schema(example = "6070958359")
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        @Schema(example = "등기소")
        private String regoNm;
        /**
         * 등기접수일시
         */
        @Schema(example = "")
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지 키
         */
        @Schema(example = "010111020605202401220310016")
        private String imgKey;
        /**
         * 대출구분코드
         */
        @Schema(example = "1")
        private String kndCd;
        /**
         * 대출물건지주소(asis:address)
         */
        @Schema(example = "대구광역시 남구 대명동  3067-0번지 3067-0번지")
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        @Schema(example = "")
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        @Schema(example = "Y")
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        @Schema(example = "Y")
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        @Schema(example = "Y")
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        @Schema(example = "Y")
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        @Schema(example = "6070958359")
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        @Schema(example = "")
        private String rdnmInclAddr;
        /**
         * 그룹번호(ASIS:M_APPROVAL_NUM)
         */
        @Schema(example = "")
        private String grpNo;
        /**
         * 비고
         */
        @Schema(example = "")
        private String rmk;
        /**
         * INS_DVSN
         */
        @Schema(example = "FA")
        private String insDvsn;
        /**
         * 전문인입횟수
         */
        @Schema(example = "0")
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        @Schema(example = "Y")
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록 일자
         */
        @Schema(example = "20231122")
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        @Schema(example = "Y")
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        @Schema(example = "Y")
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        @Schema(example = "Y")
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        @Schema(example = "Y")
        private String rgstrRegYn;
        /**
         * 지급정보 등록 여부
         */
        @Schema(example = "Y")
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        @Schema(example = "Y")
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        @Schema(example = "Y")
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        @Schema(example = "Y")
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        @Schema(example = "Y")
        private String estbsCntrFnYn;
        /**
         * 매매 계약서 유무
         */
        @Schema(example = "Y")
        private String slCntrctEane;
        /**
         * 매매 계약서 파일명
         */
        @Schema(example = "")
        private String slCntrctFlnm;
        /**
         * 전입세대열람원 제출여부
         */
        @Schema(example = "Y")
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        @Schema(example = "Y")
        private String rrcpSbMtYn;
        /**
         * 수정임대차 계약서 제출 여부
         */
        @Schema(example = "Y")
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        @Schema(example = "Y")
        private String cndtCntrYn;
        /**
         * 등기신청번호 등록여부
         */
        @Schema(example = "Y")
        private String rgstrAcptSbmtYn;
        /**
         * 이전등기 가능 법무사 유무
         */
        @Schema(example = "Y")
        private String cnvntLwyrYn;
    }

    @Getter
    @Setter
    public static class UpdCntrResCvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        private String bnkGbCd;
        /**
         * 지점명
         */
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 대출상태코드
         */
        private String lndStatCd;
        /**
         * 등기 구분 코드
         */
        private String rgstrGbCd;
        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        private String dbtrAddr;
        /**
         * 차주 핸드폰 번호
         */
        private String dbtrHpno;
        /**
         * 담보제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰 번호
         */
        private String pwpsHpno;
        /**
         * 실행예정금액
         */
        private BigDecimal execPlnAmt;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사타은행코드1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사타은행코드2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사타은행코드3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사타은행코드4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사타은행코드5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사타은행코드6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사타은행코드7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사타은행코드8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사타은행코드9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사타은행코드10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지 키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출물건지주소(asis:address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(ASIS:M_APPROVAL_NUM)
         */
        private String grpNo;
        /**
         * 비고
         */
        private String rmk;
        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 전문인입횟수
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록 일자
         */
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String rgstrRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estbsCntrFnYn;
        /**
         * 매매 계약서 유무
         */
        private String slCntrctEane;
        /**
         * 매매 계약서 파일명
         */
        private String slCntrctFlnm;
        /**
         * 전입세대열람원 제출여부
         */
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        private String rrcpSbMtYn;
        /**
         * 수정임대차 계약서 제출 여부
         */
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        private String cndtCntrYn;
        /**
         * 등기신청번호 등록여부
         */
        private String rgstrAcptSbmtYn;
        /**
         * 이전등기 가능 법무사 유무
         */
        private String cnvntLwyrYn;
    }
    /*================================================================================================================*/

    /**
     * 원장 여신번호로 삭제
     */
    @Getter
    @Setter
    public static class DelCntrReqCvo {
        /**
         * 여신번호
         */
        @Schema(example = "22381020430", description = "여신번호")
        @NotBlank(message = "여신번호는 필수 값이며, null일 수 없습니다.")
        private String loanNo;
    }

    @Getter
    @Setter
    public static class DelCntrResCvo {
        private String loanNo;
    }

    /*================================================================================================================*/

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AutoCompleteReqCvo {

        @Schema(description = "자동완성구분", example = "2")
        String searchTypeValue;

        @Schema(description = "자동완성검색어", example = "홍길동")
        String searchKeyWord;

    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AutoCompleteResCvo {

        List<String> list;
    }

}
