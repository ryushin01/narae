package com.bankle.app.biz.trn.svc;


import com.bankle.app.biz.trn.vo.TransSvo;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.repo.*;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.DateUtil;
import com.bankle.common.utils.NumberUtil;
import com.bankle.common.wooriApi.socket.ins.commonSvc.GetSetData;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.List;


@Slf4j
@Service
@RequiredArgsConstructor
public class TransDtlSvc {

    private final TbWoTrnFa6500F5Repository tbWoTrnFa6500F5Repository;
    private final TbWoTrnFa6100F1Repository tbWoTrnFa6100F1Repository;
    private final TbWoTrnFa6300F3Repository tbWoTrnFa6300F3Repository;
    private final TbWoTrnDb6300W3Repository tbWoTrnDb6300W3Repository;
    private final TbWoTrnDb6100W1Repository tbWoTrnDb6100W1Repository;
    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;
    private final CustomeModelMapper customeModelMapper;
    private final BizUtil bizUtil;
    private final GetSetData getSetData;

    @Transactional(rollbackFor = {Exception.class})
    public List<TransSvo.trnasOutSvo> getByLoanNo(String loanNo) throws Exception {
        String newLoanNo = bizUtil.getSeq(Sequence.CNTR);
        return tbWoTrnFa6500F5Repository.findByIdLoanNoOrderByIdChgDtm(loanNo)
                .stream()
                .map(e -> TransSvo.trnasOutSvo.builder()
                        .loanNo(newLoanNo)
                        .tgLen(e.getTgLen())
                        .tgDsc(e.getTgDsc())
                        .bnkTgNo(e.getBnkTgNo())
                        .faTgNo(e.getFaTgNo())
                        //.kosTgSndNo(e.getKosTgSndNo())
                        .rsrvItmH(e.getRsrvItmH())
                        .lndDsc(e.getLndDsc())
                        .lndKndCd(e.getLndKndCd())
                        .fndUseCd(e.getFndUseCd())
                        .bnkLndProdtCd(e.getBnkLndPrdtCd())
                        .bnkLndProdtNm(e.getBnkLndPrdtNm())
                        .stndAplYn(e.getStndAplYn())
                        .mvLwyrCnfmYn(e.getMvLwyrCnfmYn())
                        .rgstrUnqNo1(e.getRgstrUnqNo1())
                        .rgstrUnqNo2(e.getRgstrUnqNo2())
                        .rgstrUnqNo3(e.getRgstrUnqNo3())
                        .rgstrUnqNo4(e.getRgstrUnqNo4())
                        .rgstrUnqNo5(e.getRgstrUnqNo5())
                        .rlesDsc(e.getRlesDsc())
                        .trgtRlesDsc(e.getTrgtRlesDsc())
                        .trgtRlesAddr(e.getTrgtRlesAddr())
                        //.bfAskDt(DateUtil.getDateNowStr())
                        //.lndPlnDt(DateUtil.getDateNowStr())
                        .bfAskDt(e.getBfAskDt())
                        .lndPlnDt(e.getLndPlnDt())
                        .slPrc(e.getSlPrc())
                        .scrtevlAmt(e.getScrtEvlAmt())
                        .isrnEntrAmt(e.getIsrnEntrAmt())
                        .lndAmt(e.getLndAmt())
                        .bnkfxcltRgstrRnk(e.getBnkFxcltRgstrRnk())
                        .dbrtNm(e.getDbtrNm())
                        .dbtrBirthDt(e.getDbtrBirthDt())
                        .dbtrAddr(e.getDbtrAddr())
                        .dbtrPhno(e.getDbtrPhno())
                        .dbtrHpno(e.getDbtrHpno())
                        .pwpsNm(e.getPwpsNm())
                        .pwpsBirthDt(e.getPwpsBirthDt())
                        .pwpsAddr(e.getPwpsAddr())
                        .pwpsPhno(e.getPwpsPhno())
                        .pwpsHpno(e.getPwpsHpno())
                        .rmkFct(e.getRmkFct())
                        .lndHndgSlfDsc(e.getLndHndgSlfDsc())
                        .bnkBrnchNm(e.getBnkBrnchNm())
                        .bnkDrctrNm(e.getBnkDrctrNm())
                        .bnkBrnchPhno(e.getBnkBrnchPhno())
                        .bnkDrctrHp(e.getBnkDrctrHp())
                        .bnkBrnchFax(e.getBnkBrnchFax())
                        .bnkBrnchAddr(e.getBnkBrnchAddr())
                        .slmnCmpyNm(e.getSlmnCmpyNm())
                        .slmnNm(e.getSlmnNm())
                        .slmnPhno(e.getSlmnPhno())
                        .rfrLnAprvNo(e.getRfrLnAprvNo())
                        .rgstrMtdDsc(e.getRgstrMtdDsc())
                        .odprtRpyEane(e.getOdprtRpyEane())
                        .eltnEstbsLwyrNm(e.getEltnEstbsLwyrNm())
                        .eltnEstbsLwyrBizNo(e.getEltnEstbsLwyrBizno())
                        .slCntrctEane(e.getSlCntrctEane())
                        .slCntrctFlnm(e.getSlCntrctFlnm())
                        .afrgstrScrtYn(e.getAfrgstrScrtYn())
                        .bnkBrnchCd(e.getBnkBrnchCd())
                        .rsrvItmB(e.getRsrvItmB())
                        .regDtm(e.getRegDtm())
                        .trgtRlesAddr2(e.getTrgtRlesAddr2())
                        .addrSrchYn(e.getAddrSrchYn())
                        .cnvntLwyrYn(e.getCnvntLwyrYn())
                        .lnAprvNo2(e.getLnAprvNo2())
                        .build())
                .toList();
    }

    public List<TransSvo.Trns6100OutSvo> getByLoanNo6100(String loanNo) throws Exception {
        String newLoanNo = bizUtil.getSeq(Sequence.CNTR);
        return tbWoTrnFa6100F1Repository.findByIdLoanNoOrderByIdChgDtm(loanNo)
                .stream()
                .map(e -> TransSvo.Trns6100OutSvo.builder()
                        .loanNo(newLoanNo)
                        .tgLen(e.getTgLen() != null ? e.getTgLen() : BigDecimal.valueOf(0))    // tgLen 필드 추가
                        .tgDsc(e.getTgDsc() != null ? e.getTgDsc() : "")    // tgDsc 필드 추가
                        .bnkTgNo(e.getBnkTgNo() != null ? e.getBnkTgNo() : "")  // bnkTgNo 필드 추가
                        .faTgNo(e.getFaTgNo() != null ? e.getFaTgNo() : "")  // faTgNo 필드 추가
                        .kosTgSndNo(e.getKosTgSndNo() != null ? e.getKosTgSndNo() : "")  // kosTgSndNo 필드 추가
                        .resCd(e.getResCd() != null ? e.getResCd() : "")    // resCd 필드 추가
                        .rsrvItmH(e.getRsrvItmH() != null ? e.getRsrvItmH() : "")  // rsrvItmH 필드 추가
                        .bnkTtlReqNo(e.getBnkTtlReqNo() != null ? e.getBnkTtlReqNo() : "")  // bnkTtlReqNo 필드 추가
                        .ttlArdEntrEane(e.getTtlArdEntrEane() != null ? e.getTtlArdEntrEane() : "")  // ttlArdEntrEane 필드 추가
                        .ttlEntrcmpy(e.getTtlEntrcmpy() != null ? e.getTtlEntrcmpy() : "")  // ttlEntrcmpy 필드 추가
                        .ttlScrtNo(e.getTtlScrtNo() != null ? e.getTtlScrtNo() : "")  // ttlScrtNo 필드 추가
                        .lndDsc(e.getLndDsc() != null ? e.getLndDsc() : "")  // lndDsc 필드 추가
                        .lndKndCd(e.getLndKndCd() != null ? e.getLndKndCd() : "")  // lndKndCd 필드 추가
                        .fndUseCd(e.getFndUseCd() != null ? e.getFndUseCd() : "")  // fndUseCd 필드 추가
                        .bnkLndPrdtCd(e.getBnkLndPrdtCd() != null ? e.getBnkLndPrdtCd() : "")  // bnkLndPrdtCd 필드 추가
                        .bnkLndPrdtNm(e.getBnkLndPrdtNm() != null ? e.getBnkLndPrdtNm() : "")  // bnkLndPrdtNm 필드 추가
                        .grntDsc(e.getGrntDsc() != null ? e.getGrntDsc() : "")  // grntDsc 필드 추가
                        .stndAplYn(e.getStndAplYn() != null ? e.getStndAplYn() : "")  // stndAplYn 필드 추가
                        .rrcpCnfmReqYn(e.getRrcpCnfmReqYn() != null ? e.getRrcpCnfmReqYn() : "")  // rrcpCnfmReqYn 필드 추가
                        .mvhrCnfmReqYn(e.getMvhrCnfmReqYn() != null ? e.getMvhrCnfmReqYn() : "")  // mvhrCnfmReqYn 필드 추가
                        .bfSrvtrgtReqyn(e.getBfSrvtrgtReqYn() != null ? e.getBfSrvtrgtReqYn() : "")  // bfSrvtrgtReqyn 필드 추가
                        .afSrvtrgtReqYn(e.getAfSrvtrgtReqYn() != null ? e.getAfSrvtrgtReqYn() : "")  // afSrvtrgtReqYn 필드 추가
                        .rgstrUnqNo1(e.getRgstrUnqNo1() != null ? e.getRgstrUnqNo1() : "")  // rgstrUnqNo1 필드 추가
                        .rgstrUnqNo2(e.getRgstrUnqNo2() != null ? e.getRgstrUnqNo2() : "")  // rgstrUnqNo2 필드 추가
                        .rgstrUnqNo3(e.getRgstrUnqNo3() != null ? e.getRgstrUnqNo3() : "")  // rgstrUnqNo3 필드 추가
                        .rgstrUnqNo4(e.getRgstrUnqNo4() != null ? e.getRgstrUnqNo4() : "")  // rgstrUnqNo4 필드 추가
                        .rgstrUnqNo5(e.getRgstrUnqNo5() != null ? e.getRgstrUnqNo5() : "")  // rgstrUnqNo5 필드 추가
                        .rlesDsc(e.getRlesDsc() != null ? e.getRlesDsc() : "")  // rlesDsc 필드 추가
                        .trgtRlesDsc(e.getTrgtRlesDsc() != null ? e.getTrgtRlesDsc() : "")  // trgtRlesDsc 필드 추가
                        .trgtRlesAddr(e.getTrgtRlesAddr() != null ? e.getTrgtRlesAddr() : "")  // trgtRlesAddr 필드 추가
                        //.sscptAskDt(DateUtil.getDateNowStr())  // sscptAskDt 필드 추가
                        //.lndPlnDt(DateUtil.getDateNowStr())  // lndPlnDt 필드 추가
                        //.lndExprdDt(DateUtil.getDateAddDays(DateUtil.getDateNowStr(), 31))  // lndExprdDt 필드 추가
                        .sscptAskDt(e.getSscptAskDt())  // sscptAskDt 필드 추가
                        .lndPlnDt(e.getLndPlnDt())  // lndPlnDt 필드 추가
                        .lndExprdDt(e.getLndExprdDt())  // lndExprdDt 필드 추가
                        .slPrc(e.getSlPrc() != null ? e.getSlPrc() : BigDecimal.valueOf(0))  // slPrc 필드 추가
                        .isrnEntrAmt(e.getIsrnEntrAmt() != null ? e.getIsrnEntrAmt() : BigDecimal.valueOf(0))  // isrnEntrAmt 필드 추가
                        .lndPrd(e.getLndPrd() != null ? e.getLndPrd() : BigDecimal.valueOf(0))  // lndPrd 필드 추가
                        .lndAmt(e.getLndAmt() != null ? e.getLndAmt() : BigDecimal.valueOf(0))  // lndAmt 필드 추가
                        .bnkFxcltRgstrRnk(e.getBnkFxcltRgstrRnk() != null ? e.getBnkFxcltRgstrRnk() : BigDecimal.valueOf(0))  // bnkFxcltRgstrRnk 필드 추가
                        .bnkFxcltBndMaxAmt(e.getBnkFxcltBndMaxAmt() != null ? e.getBnkFxcltBndMaxAmt() : BigDecimal.valueOf(0))  // bnkFxcltBndMaxAmt 필드 추가
                        .dbtrNm(e.getDbtrNm() != null ? e.getDbtrNm() : "")  // dbtrNm 필드 추가
                        .dbtrBirthDt(e.getDbtrBirthDt() != null ? e.getDbtrBirthDt() : "")  // dbtrBirthDt 필드 추가
                        .dbtrAddr(e.getDbtrAddr() != null ? e.getDbtrAddr() : "")  // dbtrAddr 필드 추가
                        .dbtrPhno(e.getDbtrPhno() != null ? e.getDbtrPhno() : "")  // dbtrPhno 필드 추가
                        .dbtrHpno(e.getDbtrHpno() != null ? e.getDbtrHpno() : "")  // dbtrHpno 필드 추가
                        .pwpsNm(e.getPwpsNm() != null ? e.getPwpsNm() : "")  // pwpsNm 필드 추가
                        .pwpsBirthDt(e.getPwpsBirthDt() != null ? e.getPwpsBirthDt() : "")  // pwpsBirthDt 필드 추가
                        .pwpsAddr(e.getPwpsAddr() != null ? e.getPwpsAddr() : "")  // pwpsAddr 필드 추가
                        .pwpsPhno(e.getPwpsPhno() != null ? e.getPwpsPhno() : "")  // pwpsPhno 필드 추가
                        .pwpsHpno(e.getPwpsHpno() != null ? e.getPwpsHpno() : "")  // pwpsHpno 필드 추가
                        .rmkFct(e.getRmkFct() != null ? e.getRmkFct() : "")  // rmkFct 필드 추가
                        .lndHndgSlfDsc(e.getLndHndgSlfDsc() != null ? e.getLndHndgSlfDsc() : "")  // lndHndgSlfDsc 필드 추가
                        .bnkBrnchNm(e.getBnkBrnchNm() != null ? e.getBnkBrnchNm() : "")  // bnkBrnchNm 필드 추가
                        .bnkDrctrNm(e.getBnkDrctrNm() != null ? e.getBnkDrctrNm() : "")  // bnkDrctrNm 필드 추가
                        .bnkBrnchPhno(e.getBnkBrnchPhno() != null ? e.getBnkBrnchPhno() : "")  // bnkBrnchPhno 필드 추가
                        .bnkDrctrHp(e.getBnkDrctrHp() != null ? e.getBnkDrctrHp() : "")  // bnkDrctrHp 필드 추가
                        .bnkBrnchFax(e.getBnkBrnchFax() != null ? e.getBnkBrnchFax() : "")  // bnkBrnchFax 필드 추가
                        .bnkBrnchAddr(e.getBnkBrnchAddr() != null ? e.getBnkBrnchAddr() : "")  // bnkBrnchAddr 필드 추가
                        .slmnCmpyNm(e.getSlmnCmpyNm() != null ? e.getSlmnCmpyNm() : "")  // slmnCmpyNm 필드 추가
                        .slmnNm(e.getSlmnNm() != null ? e.getSlmnNm() : "")  // slmnNm 필드 추가
                        .slmnPhno(e.getSlmnPhno() != null ? e.getSlmnPhno() : "")  // slmnPhno 필드 추가
                        .lwfmNm(e.getLwfmNm() != null ? e.getLwfmNm() : "")  // lwfmNm 필드 추가
                        .lwfmBizNo(e.getLwfmBizno() != null ? e.getLwfmBizno() : "")  // lwfmBizNo 필드 추가
                        .dbtrWdngPlnYn(e.getDbtrWdngPlnYn() != null ? e.getDbtrWdngPlnYn() : "")  // dbtrWdngPlnYn 필드 추가
                        .rrcpCnfmYn(e.getRrcpCnfmYn() != null ? e.getRrcpCnfmYn() : "")  // rrcpCnfmYn 필드 추가
                        .spusNm(e.getSpusNm() != null ? e.getSpusNm() : "")  // spusNm 필드 추가
                        .wdngPlnDt(e.getWdngPlnDt() != null ? e.getWdngPlnDt() : "")  // wdngPlnDt 필드 추가
                        .rschWkDdlnReqDt(e.getRschWkDdlnReqDt() != null ? e.getRschWkDdlnReqDt() : "")  // rschWkDdlnReqDt 필드 추가
                        .isrnPrmm(e.getIsrnPrmm() != null ? e.getIsrnPrmm() : BigDecimal.valueOf(0))  // isrnPrmm 필드 추가
                        .rfrLnAprvNo(e.getRfrLnAprvNo() != null ? e.getRfrLnAprvNo() : "")  // rfrLnAprvNo 필드 추가
                        .rgstrMtdDsc(e.getRgstrMtdDsc() != null ? e.getRgstrMtdDsc() : "")  // rgstrMtdDsc 필드 추가
                        .rgstrReqNo(e.getRgstrReqNo() != null ? e.getRgstrReqNo() : "")  // rgstrReqNo 필드 추가
                        .odprtRpyEane(e.getOdprtRpyEane() != null ? e.getOdprtRpyEane() : "")  // odprtRpyEane 필드 추가
                        .eltnEstbsLwyrNm(e.getEltnEstbsLwyrNm() != null ? e.getEltnEstbsLwyrNm() : "")  // eltnEstbsLwyrNm 필드 추가
                        .eltnEstbsLywrBizNo(e.getEltnEstbsLwyrBizno() != null ? e.getEltnEstbsLwyrBizno() : "")  // eltnEstbsLywrBizNo 필드 추가
                        .eltnRpyLoaAplYn(e.getEltnRpyLoaAplYn() != null ? e.getEltnRpyLoaAplYn() : "")  // eltnRpyLoaAplYn 필드 추가
                        .eltnRpyLoaSqn(e.getEltnRpyLoaSqn() != null ? e.getEltnRpyLoaSqn() : "")  // eltnRpyLoaSqn 필드 추가
                        .eltnRpyLoaCtfcNo(e.getEltnRpyLoaCtfcNo() != null ? e.getEltnRpyLoaCtfcNo() : "")  // eltnRpyLoaCtfcNo 필드 추가
                        .whlRpyCnt(e.getWhlRpyCnt() != null ? e.getWhlRpyCnt() : BigDecimal.valueOf(0))  // whlRpyCnt 필드 추가
                        .whlRpyAmt(e.getWhlRpyAmt() != null ? e.getWhlRpyAmt() : BigDecimal.valueOf(0))  // whlRpyAmt 필드 추가
                        .ebnkRpyTotAmt(e.getEbnkRpyTotAmt() != null ? e.getEbnkRpyTotAmt() : BigDecimal.valueOf(0))  // ebnkRpyTotAmt 필드 추가
                        .dfbnkRpyTotAmt(e.getDfbnkRpyTotAmt() != null ? e.getDfbnkRpyTotAmt() : BigDecimal.valueOf(0))  // dfbnkRpyTotAmt 필드 추가
                        .rpyTrgtRnkNo1(e.getRpyTrgtRnkNo1() != null ? e.getRpyTrgtRnkNo1() : "")  // rpyTrgtRnkNo1 필드 추가
                        .rpyTrgtAcptDt1(e.getRpyTrgtAcptDt1() != null ? e.getRpyTrgtAcptDt1() : "")  // rpyTrgtAcptDt1 필드 추가
                        .rpyTrgtAcptNo1(e.getRpyTrgtAcptNo1() != null ? e.getRpyTrgtAcptNo1() : "")  // rpyTrgtAcptNo1 필드 추가
                        .rpyTrgtBndAmt1(e.getRpyTrgtBndAmt1() != null ? e.getRpyTrgtBndAmt1() : BigDecimal.valueOf(0))  // rpyTrgtBndAmt1 필드 추가
                        .rpyTrgtRnkNo2(e.getRpyTrgtRnkNo2() != null ? e.getRpyTrgtRnkNo2() : "")  // rpyTrgtRnkNo2 필드 추가
                        .rpyTrgtAcptDt2(e.getRpyTrgtAcptDt2() != null ? e.getRpyTrgtAcptDt2() : "")  // rpyTrgtAcptDt2 필드 추가
                        .rpyTrgtAcptNo2(e.getRpyTrgtAcptNo2() != null ? e.getRpyTrgtAcptNo2() : "")  // rpyTrgtAcptNo2 필드 추가
                        .rpyTrgtBndAmt2(e.getRpyTrgtBndAmt2() != null ? e.getRpyTrgtBndAmt1() : BigDecimal.valueOf(0))  // rpyTrgtBndAmt2 필드 추가
                        .rpyTrgtRnkNo3(e.getRpyTrgtRnkNo3() != null ? e.getRpyTrgtRnkNo3() : "")  // rpyTrgtRnkNo3 필드 추가
                        .rpyTrgtAcptDt3(e.getRpyTrgtAcptDt3() != null ? e.getRpyTrgtAcptDt3() : "")  // rpyTrgtAcptDt3 필드 추가
                        .rpyTrgtAcptNo3(e.getRpyTrgtAcptNo3() != null ? e.getRpyTrgtAcptNo3() : "")  // rpyTrgtAcptNo3 필드 추가
                        .rpyTrgtBndAmt3(e.getRpyTrgtBndAmt3() != null ? e.getRpyTrgtBndAmt1() : BigDecimal.valueOf(0))  // rpyTrgtBndAmt3 필드 추가
                        .rpyTrgtRnkNo4(e.getRpyTrgtRnkNo4() != null ? e.getRpyTrgtRnkNo4() : "")  // rpyTrgtRnkNo4 필드 추가
                        .rpyTrgtAcptDt4(e.getRpyTrgtAcptDt4() != null ? e.getRpyTrgtAcptDt4() : "")  // rpyTrgtAcptDt4 필드 추가
                        .rpyTrgtAcptNo4(e.getRpyTrgtAcptNo4() != null ? e.getRpyTrgtAcptNo4() : "")  // rpyTrgtAcptNo4 필드 추가
                        .rpyTrgtBndAmt4(e.getRpyTrgtBndAmt4() != null ? e.getRpyTrgtBndAmt1() : BigDecimal.valueOf(0))  // rpyTrgtBndAmt4 필드 추가
                        .rpyTrgtRnkNo5(e.getRpyTrgtRnkNo5() != null ? e.getRpyTrgtRnkNo5() : "")  // rpyTrgtRnkNo5 필드 추가
                        .rpyTrgtAcptDt5(e.getRpyTrgtAcptDt5() != null ? e.getRpyTrgtAcptDt5() : "")  // rpyTrgtAcptDt5 필드 추가
                        .rpyTrgtAcptNo5(e.getRpyTrgtAcptNo5() != null ? e.getRpyTrgtAcptNo5() : "")  // rpyTrgtAcptNo5 필드 추가
                        .rpyTrgtBndAmt5(e.getRpyTrgtBndAmt5() != null ? e.getRpyTrgtBndAmt1() : BigDecimal.valueOf(0))  // rpyTrgtBndAmt5 필드 추가
                        .afrgstrScrtYn(e.getAfrgstrScrtYn() != null ? e.getAfrgstrScrtYn() : "")  // afrgstrScrtYn 필드 추가
                        .slmnLndProc(e.getSlmnLndProc() != null ? e.getSlmnLndProc() : "")
                        .srMembNo(e.getSrMembNo() != null ? e.getSrMembNo() : "")
                        .trAmt(e.getTrAmt() != null ? e.getTrAmt() : BigDecimal.valueOf(0))
                        .sllNm1(e.getSllNm1() != null ? e.getSllNm1() : "")
                        .sllBrDay1(e.getSllBrDay1() != null ? e.getSllBrDay1() : "")
                        .sllNm2(e.getSllNm2() != null ? e.getSllNm2() : "")
                        .sllBrDay2(e.getSllBrDay2() != null ? e.getSllBrDay2() : "")
                        .ownLoanMaxAmt(e.getOwnLoanMaxAmt() != null ? e.getOwnLoanMaxAmt() : BigDecimal.valueOf(0))
                        .ownLoanPlnAmt(e.getOwnLoanPlnAmt() != null ? e.getOwnLoanPlnAmt() : BigDecimal.valueOf(0))
                        .ownLoanBnkNm1(e.getOwnLoanBnkNm1() != null ? e.getOwnLoanBnkNm1() : "")
                        .ownLoanBnkNm2(e.getOwnLoanBnkNm2() != null ? e.getOwnLoanBnkNm2() : "")
                        .ownLoanBnkNm3(e.getOwnLoanBnkNm3() != null ? e.getOwnLoanBnkNm3() : "")
                        .ownLoanBnkNm4(e.getOwnLoanBnkNm4() != null ? e.getOwnLoanBnkNm4() : "")
                        .ownLoanBnkNm5(e.getOwnLoanBnkNm5() != null ? e.getOwnLoanBnkNm5() : "")
                        .cnsgnNm(e.getCnsgnNm() != null ? e.getCnsgnNm() : "")
                        .trstNm(e.getTrstNm() != null ? e.getTrstNm() : "")
                        .bnfrNm(e.getBnfrNm() != null ? e.getBnfrNm() : "")
                        .nowLessNm(e.getNowLessNm() != null ? e.getNowLessNm() : "")
                        .rsrvItmB(e.getRsrvItmB() != null ? e.getRsrvItmB() : "")  // rsrvItmB 필드 추가
                        .oblMLnAprvNo(e.getOblMLnAprvNo() != null ? e.getOblMLnAprvNo() : "")  // oblMLnAprvNo 필드 추가
                        .oblTotCnt(e.getOblTotCnt() != null ? e.getOblGrpRnkNo() : 0)  // oblTotCnt 필드 추가
                        .oblGrpRnkNo(e.getOblGrpRnkNo() != null ? e.getOblGrpRnkNo() : 0)  // oblGrpRnkNo 필드 추가
                        .lnAprvNo2(e.getLnAprvNo2() != null ? e.getLnAprvNo2() : "")  // lnAprvNo2 필드 추가
                        .build())
                .toList();
    }

    @Transactional(rollbackFor = {Exception.class})
    public List<TransSvo.Trns6300OutSvo> getByLoanNo6300(String loanNo) throws Exception {
        String newLoanNo = bizUtil.getSeq(Sequence.CNTR);
        return tbWoTrnFa6300F3Repository.findByIdLoanNoOrderByIdChgDtm(loanNo)
                .stream()
                .map(e -> TransSvo.Trns6300OutSvo.builder()
                        .loanNo(newLoanNo)
                        .tgLen(e.getTgLen())
                        .tgDsc(e.getTgDsc())
                        .bnkTgNo(e.getBnkTgNo())
                        .faTgNo(e.getFaTgNo())
                        .kosTgSndNo(e.getKosTgSndNo())
                        .resCd(e.getResCd())
                        .rsrvItmH(e.getRsrvItmH())
                        .bnkTtlReqNo(e.getBnkTtlReqNo())
                        .lndPrgsStc(e.getLndPrgsStc())
                        .prgsDt(e.getPrgsDt())
                        .sbmtDocLst(e.getSbmtDocLst())
                        .mvhrHshldrRno(e.getMvhrHshldrRno())
                        .mvhrTrgtThngAddr(e.getMvhrTrgtThngAddr())
                        .mvhrHshldrNmMvinDt(e.getMvhrHshldrNmMvinDt())
                        .mvhrdtm(e.getMvhrdtm())
                        .rsrvItmB(e.getRsrvItmB())
                        .regDtm(e.getRegDtm())
                        .lnAprvNo2(e.getLnAprvNo2())
                        .build())
                .toList();
    }

    @Transactional(rollbackFor = {Exception.class})
    public List<TransSvo.TrnsDb6300OutSvo> getByLoanNoDb6300(String loanNo) throws Exception {
        String newLoanNo = bizUtil.getSeq(Sequence.CNTR);
        return tbWoTrnDb6300W3Repository.findByIdLoanNoOrderByIdChgDtm(loanNo)
                .stream()
                .map(e -> TransSvo.TrnsDb6300OutSvo.builder()
                        .loanNo(newLoanNo)
                        .tgLen(e.getTgLen())
                        .tgDsc(e.getTgDsc())
                        .resCd(e.getResCd())
                        .lndAgncCd(e.getLndAgncCd())
                        .bnkTgTrnsDtm(e.getBnkTgTrnsDtm())
                        .bnkTgNo(String.valueOf(e.getBnkTgNo()))
                        .dbTgNo(e.getDbTgNo())
                        .rsrvItmH(e.getRsrvItmH())
                        .bnkAskNo(e.getBnkAskNo())
                        .dbMngNo(e.getDbMngNo())
                        .kosTgTrnsDtm(e.getKosTgTrnsDtm())
                        .kosTgNo(e.getKosTgNo())
                        .nttnYn(e.getNttnYn())
                        .endNotiDt(e.getEndNotiDt())
                        .endNotiTm(e.getEndNotiTm())
                        .bnkDrctrNm(e.getBnkDrctrNm())
                        .bnkDrctrPhno(e.getBnkDrctrPhno())
                        .rsrvItmB(e.getRsrvItmB())
                        .regDtm(e.getRegDtm())
                        .build()).toList();
    }

    @Transactional(rollbackFor = {Exception.class})
    public TransSvo.TrnsLoanExeOutSvo getLoanExeByLoanNo(String loanNo) throws Exception {
        //------------------------------------------------------------------
        // 원장 조회
        //------------------------------------------------------------------
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(loanNo)
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));
        var tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);

        String newLoanNo = bizUtil.getSeq(Sequence.CNTR);
        String trLn = "500";
        String trCd = "A700";
        String trTpCd = "100";
        String reqDttm = DateUtil.getCurrentDateTime();
        String trSq = bizUtil.getSeq(Sequence.TRANS);
        String approvalNum = newLoanNo;
        String procDvsn = "1";
        String exeDtm = DateUtil.getCurrentDateTime();
        String exeAmt = NumberUtil.toBigDecimal(tbWoCntrMasterDto.getExecAmt()).toString();
        String docTax = NumberUtil.toBigDecimal(tbWoCntrMasterDto.getDocAmt()).toString();
        String debtDcAmt = NumberUtil.toBigDecimal(tbWoCntrMasterDto.getDebtDcAmt()).toString();
        String etcAmt = NumberUtil.toBigDecimal(tbWoCntrMasterDto.getEtcAmt()).toString();

        return TransSvo.TrnsLoanExeOutSvo
                .builder()
                .loanNo(newLoanNo)
                .trLn(trLn)
                .trCd(trCd)
                .trTpCd(trTpCd)
                .trSq(reqDttm)
                .reqDttm(trSq)
                .approvalNum(approvalNum)
                .exeDtm(exeDtm)
                .procDvsn(procDvsn)
                .exeAmt(exeAmt)
                .docTax(docTax)
                .debtDcAmt(debtDcAmt)
                .etcAmt(etcAmt)
                .build();
    }


    @Transactional(rollbackFor = {Exception.class})
    public TransSvo.TrnsPayRsltOutSvo getPayRsltByLoanNo(String loanNo) throws Exception {

        //------------------------------------------------------------------
        // 원장 조회
        //------------------------------------------------------------------
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(loanNo)
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));
        var tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);

        String newLoanNo = bizUtil.getSeq(Sequence.CNTR);
        String trLn = "500"; // 전문길이
        String trCd = "A400"; // 전문종별코드
        String trTpCd = "100"; // 거래구분코드
//        String trSq = bizUtil.getSeq(Sequence.TRANS); // 식별번호
//        String reqDttm = DateUtil.getCurrentDateTime(); // 송신일자

        return TransSvo.TrnsPayRsltOutSvo
                .builder()
                .loanNo(newLoanNo)
                .trLn(trLn)
                .trCd(trCd)
                .trTpCd(trTpCd)
//                .trSq(trSq)
//                .reqDttm(reqDttm)
//                .approvalNum(newLoanNo)
                .transResultCd("0000")
                .build();
    }

    @Transactional(rollbackFor = {Exception.class})
    public List<TransSvo.TrnAskDbOutSvo> getTrnAskDbByLoanNo(String loanNo) throws Exception {
        String newLoanNo = bizUtil.getSeq(Sequence.CNTR);
        return tbWoTrnDb6100W1Repository.findTop1ByIdLoanNo(loanNo)
                .stream()
                .map(e -> TransSvo.TrnAskDbOutSvo.builder()
                        .loanNo(e.getId().getLoanNo())
                        .newLoanNo(newLoanNo)
                        .chgDtm(e.getId().getChgDtm())
                        .tgLen(e.getTgLen())
                        .tgDsc(e.getTgDsc())
                        .resCd(e.getResCd())
                        .lndAgncCd(e.getLndAgncCd())
                        //.bnkTgTrnsDtm(e.getBnkTgTrnsDtm().toString())
                        //.dbTgTrnsDtm(e.getKosTgTrnsDtm().toString())
                        .bnkTgNo(e.getBnkTgNo())
                        .dbTgNo(e.getDbTgNo())
                        .rsrvItmH(e.getRsrvItmH())
                        .bnkAskNo(e.getBnkAskNo())
                        .dbMngNo(e.getDbMngNo())
                        //.kosTgTrnsDtm(e.getKosTgTrnsDtm())
                        .kosTgNo(e.getKosTgNo())
                        .procDvsnCd(e.getProcDvsnCd())
                        .rthIsrnEntrYn(e.getRthIsrnEntrYn())
                        .rthIsrnEntrCmpy(e.getRthIsrnEntrCmpy())
                        .rthIsrnScrtNo(e.getRthIsrnScrtNo())
                        .pstNo(e.getPstNo())
                        .crtdnCd(e.getCrtdnCd())
                        .trgtAddr(e.getTrgtAddr())
                        .trgtDtlAddr(e.getTrgtDtlAddr())
                        .rgstrUnqNo1(e.getRgstrUnqNo1())
                        .rgstrUnqNo2(e.getRgstrUnqNo2())
                        .rgstrUnqNo3(e.getRgstrUnqNo3())
                        .lndKndCd(e.getLndKndCd())
                        .fndYn(e.getFndYn())
                        .prdtNm(e.getPrdtNm())
                        .prdtCd(e.getPrdtCd())
                        .grntAgncCd(e.getGrntAgncCd())
                        .srvTrgtYn(e.getSrvTrgtYn())
                        .stndTrgtYn(e.getStndTrgtYn())
                        .rrcpChrgTrgtYn(e.getRrcpChrgTrgtYn())
                        .rvsnCntrctChrgTrgtYn(e.getRvsnCntrctChrgTrgtYn())
                        //.sscptAskDt(DateUtil.getDateNowStr())
                        //.lndPlnDt(DateUtil.getDateNowStr())
                        .sscptAskDt(e.getSscptAskDt())
                        .lndPlnDt(e.getLndPlnDt())
                        .rntlPrdEndDt(e.getRntlPrdEndDt())
                        .lndExprdDt(DateUtil.getDateAddDays(DateUtil.getDateNowStr(), 31))
                        .lndPrd(e.getLndPrd())
                        .lndAmt(e.getLndAmt())
                        .isrnEntrAmt(e.getIsrnEntrAmt())
                        .objtEbnkRgstrRnk(NumberUtil.toBigDecimal(e.getObjtEbnkRgstrRnk()))
                        .objtEbnkBndMaxAmt(NumberUtil.toBigDecimal(e.getObjtEbnkBndMaxAmt()))
                        .mggFnlOdprtAmt(NumberUtil.toBigDecimal(e.getMggFnlOdprtAmt()))
                        .trolFnlOdprtAmt(NumberUtil.toBigDecimal(e.getTrolFnlOdprtAmt()))
                        .srvcEndDt(e.getSrvcEndDt())
                        .dbtrNm(e.getDbtrNm())
                        .dbtrRrno(e.getDbtrRrno())
                        .dbtrPstNo(e.getDbtrPstNo())
                        .dbtrAddr(e.getDbtrAddr())
                        .dbtrPhno(e.getDbtrPhno())
                        .dbtrHpno(e.getDbtrHpno())
                        .wdngPlnYn(e.getWdngPlnYn())
                        .wdngPlnDt(e.getWdngPlnDt())
                        .hshldrCnddtYn(e.getHshldrCnddtYn())
                        .unmrdHshldr25agLstnYn(e.getUnmrdHshldr25agLstnYn())
                        .acptDsc(e.getAcptDsc())
                        .lwfmNm(e.getLwfmNm())
                        .lwfmBizno(e.getLwfmBizno())
                        .askBrnchCd(e.getAskBrnchCd())
                        .askBrnchNm(e.getAskBrnchNm())
                        .askBrnchDrctrNm(e.getAskBrnchDrctrNm())
                        .askBrnchPhno(e.getAskBrnchPhno())
                        .bnkLesDsc(e.getBnkLesDsc())
                        .fndLesDsc(e.getFndLesDsc())
                        .cndtlCnts(e.getCndtlCnts())
                        .isrnPrmm(e.getIsrnPrmm())
                        .rsrvItmB(e.getRsrvItmB())
                        .regDtm(e.getRegDtm())
                        .loanAprvNo2(e.getLoanAprvNo2())
                        .build()).toList();
    }


    @Transactional(rollbackFor = {Exception.class})
    public TransSvo.TrnsImageSendRsltOutSvo getImageSendRsltByLoanNo(String loanNo) throws Exception {

        //------------------------------------------------------------------
        // 원장 조회
        //------------------------------------------------------------------
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(loanNo)
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));
        var tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);

        String newLoanNo = bizUtil.getSeq(Sequence.CNTR);
        String trLn = "500"; // 전문길이
        String trCd = "B700"; // 전문종별코드
        String trTpCd = "100"; // 거래구분코드
//        String trSq = bizUtil.getSeq(Sequence.TRANS); // 식별번호
//        String reqDttm = DateUtil.getCurrentDateTime(); // 송신일자

        return TransSvo.TrnsImageSendRsltOutSvo
                .builder()
                .loanNo(newLoanNo)
                .trLn(trLn)
                .trCd(trCd)
                .trTpCd(trTpCd)
                .imgKey(StringUtils.hasText(tbWoCntrMasterDto.getImgKey()) ? tbWoCntrMasterDto.getImgKey() : "")
//                .trSq(trSq)
//                .reqDttm(reqDttm)
//                .approvalNum(newLoanNo)
                .build();
    }
}
