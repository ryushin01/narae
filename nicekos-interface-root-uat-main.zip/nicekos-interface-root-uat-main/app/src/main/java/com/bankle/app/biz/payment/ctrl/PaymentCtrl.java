package com.bankle.app.biz.payment.ctrl;

import com.bankle.app.biz.cntr.svc.CntrDtlSvc;
import com.bankle.app.biz.cntr.vo.CntrCvo;
import com.bankle.app.biz.cntr.vo.CntrMasterCvo;
import com.bankle.app.biz.payment.svc.PaymentSvc;
import com.bankle.app.biz.payment.vo.PaymentCvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@Tag(name = "2. 은행 대출금 지급 정보", description = "은행 대출금 지급 정보 관리 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class PaymentCtrl {

    private final PaymentSvc paymentSvc;
    private final CustomeModelMapper customeModelMapper;

    @Operation(
            summary = "은행 대출금 지급 정보 리스트 조회",
            description = """
        특정 여신번호(loanNo)에 해당하는 은행 대출금 지급 정보를 조회합니다.
        지급 정보는 List 형태로 반환됩니다.
    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "은행 대출금 지급 정보 리스트 조회 성공", content = @Content(schema = @Schema(implementation = PaymentCvo.PaymentInfoResCvo.class))),
    })
    @PostMapping("/cntr/searchpaymentlist/{loanNo}")
    public ResponseEntity<?> searchPaymentList(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {

            var res = paymentSvc.findPaymentInfoList(loanNo);

            if (res.stream().count() > 0) {
                return ResData.SUCCESS(res, "은행 대출금 지급 정보 리스트 조회 성공");
            }
            return ResData.FAIL("은행 대출금 지급 정보 리스트 조회 실패");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }
}
