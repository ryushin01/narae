package com.bankle.app.biz.admin.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;

public class AdminCvo {
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LoginVo {
        @NotEmpty(message = "LOGIN ID는 필수 항목입니다.")
        @Schema(name = "adminId", example = "a@bankle.co.kr")
        String adminId;
        @NotEmpty(message = "PASSWORD는 필수 항목입니다.")
        @Schema(name = "pwd", example = "bankle")
        String pwd;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Getter
    @Setter
    public static class LoginAdminResCvo {
        /**
         * 로그인 중 여부
         */
        private String lognYn;
        /**
         * 결과코드
         */
        private String resCd;
        /**
         * 관리자 번호
         */
        private String membNo;
        /**
         * 관리자명
         */
        private String adminNm;

        /**
         * 권한 코드
         */
        private String permCd;
        /**
         * 권한 코드명
         */
        private String permNm;

        /**
         * 아이디
         */
        private String lognId;
        /**
         * 휴대폰번호
         */
        private String cphnNum;
        /**
         * 로그인 실패 횟수
         */
        private Integer lognFailCnt;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 상태명
         */
        private String statNm;
        /**
         * accessToken
         */
        private String accessToken;
        /**
         * refreshToken
         */
        private String refreshToken;
    }
}
