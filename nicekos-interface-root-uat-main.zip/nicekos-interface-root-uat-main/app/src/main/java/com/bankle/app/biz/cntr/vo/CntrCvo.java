package com.bankle.app.biz.cntr.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class CntrCvo {

    @Getter
    @Setter
    @Builder
    public static class CntrDtlReqCvo {

        /**
         * 여신 번호
         */
        @Schema(example = "12345678901", description = "여신 번호")
        private String loanNo;
    }


    @Getter
    @Setter
    public static class CntrDtlResCvo {

        /**
         * 여신 번호
         */
        @Schema(example = "12345678901", description = "여신 번호")
        private String loanNo;

        /**
         * 사업자 등록 번호
         */
        @Schema(example = "1234567890", description = "사업자 등록 번호")
        private String bizNo;

        /**
         * 보험사 구분 코드
         */
        @Schema(example = "1234567890", description = "사업자 등록 번호")
        private String isrnGbCd;

        private String bnkBrnchCd;
        private String bnkGbCd;
        private String bnkBrnchNm;
        private String bnkDrctrNm;
        private String bnkBrnchPhno;
        private String lndKndCd;
        private String statCd;
        private String lndStatCd;
        private String rgstrGbCd;
        private String lndPrdtNm;
        private String dbtrNm;
        private String dbtrBirthDt;
        private String dbtrAddr;
        private String dbtrHpno;
        private String pwpsNm;
        private String pwpsBirthDt;
        private String pwpsHpno;
        private BigDecimal execPlnAmt;
        private String execPlnDt;
        private BigDecimal execAmt;
        private String execDt;
        private BigDecimal slPrc;
        private BigDecimal isrnEntrAmt;
        private String lwyrDiffBankCd1;
        private String lwyrDiffBankCd2;
        private String lwyrDiffBankCd3;
        private String lwyrDiffBankCd4;
        private String lwyrDiffBankCd5;
        private String lwyrDiffBankCd6;
        private String lwyrDiffBankCd7;
        private String lwyrDiffBankCd8;
        private String lwyrDiffBankCd9;
        private String lwyrDiffBankCd10;
        private String ersuClsMsg;
        private String ebtsLwyrBizno;
        private String regoNm;
        private LocalDateTime rgstrAcptDtm;
        private String imgKey;
        private String kndCd;
        private String lndThngAddr;
        private String ccrstAcptNum;
        private String clsctSctrtBprRegYn;
        private String ccrstBprRegYn;
        private String blncFpymnRcpt;
        private String regifBprRegYn;
        private String elregBizNo;
        private String rdnmInclAddr;
        private String rdnmStndAddr;
        private String grpNo;
        private String rmk;
        private String insDvsn;
        private Long trnInCnt;
        private String refndAcctRegYn;
        private String refndAcctRegDate;
        private String eltnSecuredYn;
        private String execAmtChangYn;
        private String estmRegYn;
        private String rgstrRegYn;
        private String payRegYn;
        private String estmCnfmYn;
        private String lndAmtPayYn;
        private String revisionCheckYn;
        private String estbsCntrFnYn;
        private String slCntrctEane;
        private String slCntrctFlnm;
        private String mvhhdSbmtYn;
        private String rrcpSbmtYn;
        private String rtalSbmtYn;
        private String cndtCntrYn;
        private String rgstrAcptSbmtYn;
        private String cnvntLwyrYn;
        private String rschWkDdlnReqDt;
        private String sscptAskDt;
        private String rrcpCnfmReqYn;
        private String mvhhdCnfmReqYn;
        private String rvsnCntrctChrgTrgtYn;
        private String stndAplYn;
        private String befDbsmtCnclCd;
        private String elregYn;
        private String bnkTtlReqNo;
        private String fndUseCd;
        private String offRgstrYn;
        private String a300Send;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CntrInfoReqCvo {

        private String loanNo;
        private String kndCd;
        private String lndKndCd;
        private String rgstrGbCd;
        private String statCd;
        private String lndStatCd;
        private BigDecimal execPlnAmt;
        private BigDecimal execAmt;
        private String execPlnDt;
        private String execDt;
        private BigDecimal slPrc;
        private String bnkBrnchCd;
        private String bizNo;
        private Long trnInCnt;
        private String refndAcctRegYn;
        private String refndAcctRegDate;
        private String eltnSecuredYn;
        private String execAmtChangYn;
        private String estmRegYn;
        private String rgstrRegYn;
        private String payRegYn;
        private String estmCnfmYn;
        private String lndAmtPayYn;
        private String revisionCheckYn;
        private String estbsCntrFnYn;
        private String slCntrctEane;
        private String slCntrctFlnm;
        private String mvhhdSbmtYn;
        private String rrcpSbmtYn;
        private String rtalSbmtYn;
        private String cndtCntrYn;
        private String lwyrDiffBankCd8;
        private String lwyrDiffBankCd10;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CntrInfoResCvo {

        private String loanNo;
        private String lndKndCd;
        private String rgstrGbCd;
        private String statCd;
        private String lndStatCd;
        private BigDecimal execPlnAmt;
        private BigDecimal execAmt;
        private String execPlnDt;
        private String execDt;
        private BigDecimal slPrc;
        private String bnkBrnchCd;
        private String bizNo;
        private Long trnInCnt;
        private String refndAcctRegYn;
        private String refndAcctRegDate;
        private String eltnSecuredYn;
        private String execAmtChangYn;
        private String estmRegYn;
        private String rgstrRegYn;
        private String payRegYn;
        private String estmCnfmYn;
        private String lndAmtPayYn;
        private String revisionCheckYn;
        private String estbsCntrFnYn;
        private String slCntrctEane;
        private String slCntrctFlnm;
        private String mvhhdSbmtYn;
        private String rrcpSbmtYn;
        private String rtalSbmtYn;
        private String cndtCntrYn;
    }
}
