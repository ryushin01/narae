package com.bankle.app.biz.admin.svc;

import com.bankle.app.biz.admin.vo.AdminSvo;
import com.bankle.common.config.security.JwtUtil;
import com.bankle.common.dto.TbAdminMasterDto;
import com.bankle.common.entity.TbAdminMaster;
import com.bankle.common.mapper.TbAdminMasterMapper;
import com.bankle.common.repo.TbAdminMasterRepository;
import com.bankle.common.utils.CustomeModelMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.concurrent.TimeUnit;
@Slf4j
@Service
@RequiredArgsConstructor
public class AdminSvc {

    private final TbAdminMasterRepository tbAdmMasterRepo;
    private final CustomeModelMapper modelMapper;
    private final JwtUtil jwtUtil;
    /**
     * @package : com.withuslaw.Admin.biz.admin.svc
     * @name : Admin 로그인 Service (id, pw)
     * @date : 2023-11-13 오전 11:25
     * @author : JS Hong
     * @version : 1.0.0
     **/

    @Transactional
    public AdminSvo.AdminLoginOutSvo adminLogin(AdminSvo.AdminLoginInSvo inSvo) throws Exception {
        AdminSvo.AdminLoginOutSvo result = new AdminSvo.AdminLoginOutSvo();
        result.setLognYn("N");
        try {
            String lognId = inSvo.getLognId();

            //------------------------------------------------------------------
            // 아이디로 회원정보와 상태코드(01)로 불러오기
            //------------------------------------------------------------------
            Optional<TbAdminMaster> tbAdminMaster = tbAdmMasterRepo.findByLognIdAndStatCd(lognId, "01");

            if (tbAdminMaster.isPresent()) {
                TbAdminMasterDto admDto = TbAdminMasterMapper.INSTANCE.toDto(tbAdminMaster.get());
                result = modelMapper.mapping(admDto, AdminSvo.AdminLoginOutSvo.class);

                //------------------------------------------------------------------
                // 패스워드 일치 여부 판단
                //------------------------------------------------------------------
                String inputPwd = inSvo.getPwd();
                log.debug("입력된 비밀번호 : {}", inputPwd);

                if (!result.getPwd().equals(inputPwd)) {
                    result = new AdminSvo.AdminLoginOutSvo();
                    result.setResCd("01");
                    result.setAdminNm(admDto.getAdminNm());
                    result.setLognId(admDto.getLognId());
//                    result.setLognFailCnt(edtFaliCntAdd(lognId));
                    return result;
                }
//                String membNo = admDto.getMembNo();
                //------------------------------------------------------------------
                // 토큰 가져오기
                //------------------------------------------------------------------
                String accessToken = jwtUtil.getAdminAccessToken(admDto.getMembNo());
                log.debug("new accessToken : {}", accessToken);
                String refreshToken = jwtUtil.getAdminRefreshToken(admDto.getMembNo());
                result.setAccessToken(accessToken);
                result.setRefreshToken(refreshToken);
            } else {
                result.setResCd("06");
                result.setLognId(inSvo.getLognId());
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e.getMessage());
        }
        return result;
    }
}
