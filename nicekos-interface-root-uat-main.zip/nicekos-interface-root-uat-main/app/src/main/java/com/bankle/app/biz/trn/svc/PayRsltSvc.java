package com.bankle.app.biz.trn.svc;


import com.bankle.app.biz.trn.vo.PayRsltSvo;
import com.bankle.common.dto.TbWoCntrPaymentListDto;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.entity.TbWoCntrPaymentList;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoCntrPaymentListMapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoCntrPaymentListRepository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.StringUtil;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import com.bankle.common.wooriApi.socket.woori.sendSvc.SendA400Svc;
import com.bankle.common.wooriApi.socket.woori.sendSvc.vo.SendA400Svo;
import jakarta.persistence.EntityManager;
import jakarta.validation.Valid;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class PayRsltSvc {

    private final SendA400Svc sendA400Svc;
    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;
    private final TbWoCntrPaymentListRepository tbWoCntrPaymentListRepository;
    private final BizUtil bizUtil;
    private final EntityManager entityManager;

    @Transactional
    public boolean save(@Valid PayRsltSvo.PayRsltInSvo inSvo) throws Exception {

        //------------------------------------------------------------------
        // 원장 조회
        //------------------------------------------------------------------
        String loanNo = inSvo.getLoanNo();
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(inSvo.getLoanNo())
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));
        var tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);

        //------------------------------------------------------------------
        // 전문 전송
        //------------------------------------------------------------------
        SendA400Svo.SendA400InSvo sendInSvo =  SendA400Svo.SendA400InSvo.builder()
                .loanNo(loanNo) //여신번호
                .trLn(inSvo.getTrLn())
                .trnName("지급결과통지")
                .trCd(inSvo.getTrCd())
                .trTpCd(inSvo.getTrTpCd())
                .loNo(inSvo.getLoNo())
                .trSq(bizUtil.getSeq(Sequence.TRANS))
                .payType(inSvo.getPayType())
                .payBankCd(inSvo.getPayBankCd())
                .payAmt(inSvo.getPayAmt())
                .transResultCd(StringUtil.lpad(inSvo.getTransResultCd(), 4, '0'))
                .insGbn(tbWoCntrMasterDto.getInsDvsn())
                .build();
        CheckResponseSvo checkResponseSvo = sendA400Svc.sendAndResponse(sendInSvo);

        //------------------------------------------------------------------
        // 지급 결과 반영
        //------------------------------------------------------------------
        if ("000".equals(checkResponseSvo.getRescode())) {
            String payCd = "";
            String bankCd = "";
            switch (inSvo.getPayType()) {
                case "SEL" -> payCd = "01";
                case "BUY" -> payCd = "02";
                case "020" -> payCd = "03";
                default -> {
                    payCd = "04";
                    bankCd = inSvo.getPayType();
                }
            }
            Optional<TbWoCntrPaymentList> payEntity;
            if ("01,02,03".contains(payCd)) {
                payEntity = tbWoCntrPaymentListRepository.findById_LoanNoAndPayCd(loanNo, payCd);
            } else {
                payEntity = tbWoCntrPaymentListRepository.findById_LoanNoAndPayCdAndBankCd(loanNo, payCd, bankCd);
            }
            TbWoCntrPaymentListDto payDto = TbWoCntrPaymentListMapper.INSTANCE.toDto(payEntity.get());
            payDto.setStatCd("02");
            tbWoCntrPaymentListRepository.save(TbWoCntrPaymentListMapper.INSTANCE.toEntity(payDto));
            entityManager.flush();
        }
        return "000".equals(checkResponseSvo.getRescode());
    }
}

