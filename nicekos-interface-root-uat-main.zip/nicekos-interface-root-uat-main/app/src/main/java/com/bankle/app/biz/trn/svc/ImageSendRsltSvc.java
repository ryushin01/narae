package com.bankle.app.biz.trn.svc;


import com.bankle.app.biz.trn.vo.ImageSendRsltSvo;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import com.bankle.common.wooriApi.socket.woori.sendSvc.SendB700Svc;
import com.bankle.common.wooriApi.socket.woori.sendSvc.vo.SendB700Svo;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class ImageSendRsltSvc {

    private final SendB700Svc sendB700Svc;

    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;

    private final BizUtil bizUtil;

    @Transactional
    public boolean save(@Valid ImageSendRsltSvo.ImageSendRsltInSvo inSvo) throws Exception {

        //------------------------------------------------------------------
        // 원장 조회
        //------------------------------------------------------------------
        String loanNo = inSvo.getLoanNo();
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(inSvo.getLoanNo())
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));
        var tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);

        //------------------------------------------------------------------
        // 전문 전송
        //------------------------------------------------------------------
        SendB700Svo.SendB700InSvo sendInSvo =  SendB700Svo.SendB700InSvo.builder()
                .loanNo(loanNo) //여신번호
                .trLn(inSvo.getTrLn())
                .trnName("이미지파일 서류 전송 결과 통지")
                .trCd(inSvo.getTrCd())
                .trTpCd(inSvo.getTrTpCd())
                .loNo(inSvo.getLoNo())
                .trSq(bizUtil.getSeq(Sequence.TRANS))
                .imgTp(inSvo.getImgTp())
                .imgCheckYn(inSvo.getImgCheckYn())
                .imgKey(inSvo.getImgKey())
                .imgPageCnt(inSvo.getImgPageCnt())
                .seqNo(inSvo.getSeqNo())
                .imgFileName(inSvo.getImgFileName())
                .resultCd(inSvo.getResultCd())
                .insGbn(tbWoCntrMasterDto.getInsDvsn())
                .build();
        CheckResponseSvo checkResponseSvo = sendB700Svc.sendAndResponse(sendInSvo);
        return "000".equals(checkResponseSvo.getRescode());
    }
}

