package com.bankle.app.biz.trn.vo;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TransSvo {

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class trnasOutSvo {

        private String loanNo;

        private LocalDateTime chgDgm;

        private BigDecimal tgLen;

        private String tgDsc;

        private String bnkTgNo;

        private String faTgNo;

        private String kosTgSndNo;

        private LocalDateTime tgSndDtm;

        private LocalDateTime tgRcvDtm;

        private String resCd;

        private String rsrvItmH;

        private String lndDsc;

        private String lndKndCd;

        private String fndUseCd;

        private String bnkLndProdtCd;

        private String bnkLndProdtNm;

        private String stndAplYn;

        private String mvLwyrCnfmYn;

        private String rgstrUnqNo1;

        private String rgstrUnqNo2;

        private String rgstrUnqNo3;

        private String rgstrUnqNo4;

        private String rgstrUnqNo5;

        private String rlesDsc;

        private String trgtRlesDsc;

        private String trgtRlesAddr;

        private String bfAskDt;

        private String lndPlnDt;

        private BigDecimal slPrc;

        private String scrtevlAmt;

        private String isrnEntrAmt;

        private BigDecimal lndAmt;

        private BigDecimal bnkfxcltRgstrRnk;

        private String dbrtNm;

        private String dbtrBirthDt;

        private String dbtrAddr;

        private String dbtrPhno;

        private String dbtrHpno;

        private String pwpsNm;

        private String pwpsBirthDt;

        private String pwpsAddr;

        private String pwpsPhno;

        private String pwpsHpno;

        private String rmkFct;

        private String lndHndgSlfDsc;

        private String bnkBrnchNm;

        private String bnkDrctrNm;

        private String bnkBrnchPhno;

        private String bnkDrctrHp;

        private String bnkBrnchFax;

        private String bnkBrnchAddr;

        private String slmnCmpyNm;

        private String slmnNm;

        private String slmnPhno;

        private String rfrLnAprvNo;

        private String rgstrMtdDsc;

        private String odprtRpyEane;

        private String eltnEstbsLwyrNm;

        private String eltnEstbsLwyrBizNo;

        private String slCntrctEane;

        private String slCntrctFlnm;

        private String afrgstrScrtYn;

        private String bnkBrnchCd;

        private String rsrvItmB;

        private LocalDateTime regDtm;

        private String trgtRlesAddr2;

        private String addrSrchYn;

        private String cnvntLwyrYn;

        private String lnAprvNo2;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Trns6100OutSvo {

        private String loanNo;
        private LocalDateTime chgDtm;
        private BigDecimal tgLen;
        private String tgDsc;
        private String bnkTgNo;
        private String faTgNo;
        private String kosTgSndNo;
        private LocalDateTime tgSndDtm;
        private LocalDateTime tgRcvDtm;
        private String resCd;
        private String rsrvItmH;
        private String bnkTtlReqNo;
        private String ttlArdEntrEane;
        private String ttlEntrcmpy;
        private String ttlScrtNo;
        private String lndDsc;
        private String lndKndCd;
        private String fndUseCd;
        private String bnkLndPrdtCd;
        private String bnkLndPrdtNm;
        private String grntDsc;
        private String stndAplYn;
        private String rrcpCnfmReqYn;
        private String mvhrCnfmReqYn;
        private String bfSrvtrgtReqyn;
        private String afSrvtrgtReqYn;
        private String rgstrUnqNo1;
        private String rgstrUnqNo2;
        private String rgstrUnqNo3;
        private String rgstrUnqNo4;
        private String rgstrUnqNo5;
        private String rlesDsc;
        private String trgtRlesDsc;
        private String trgtRlesAddr;
        private String sscptAskDt;
        private String lndPlnDt;
        private String lndExprdDt;
        private BigDecimal slPrc;
        private BigDecimal isrnEntrAmt;
        private BigDecimal lndPrd;
        private BigDecimal lndAmt;
        private BigDecimal bnkFxcltRgstrRnk;
        private BigDecimal bnkFxcltBndMaxAmt;
        private String dbtrNm;
        private String dbtrBirthDt;
        private String dbtrAddr;
        private String dbtrPhno;
        private String dbtrHpno;
        private String pwpsNm;
        private String pwpsBirthDt;
        private String pwpsAddr;
        private String pwpsPhno;
        private String pwpsHpno;
        private String rmkFct;
        private String lndHndgSlfDsc;
        private String bnkBrnchNm;
        private String bnkDrctrNm;
        private String bnkBrnchPhno;
        private String bnkDrctrHp;
        private String bnkBrnchFax;
        private String bnkBrnchAddr;
        private String slmnCmpyNm;
        private String slmnNm;
        private String slmnPhno;
        private String lwfmNm;
        private String lwfmBizNo;
        private String dbtrWdngPlnYn;
        private String rrcpCnfmYn;
        private String spusNm;
        private String wdngPlnDt;
        private String rschWkDdlnReqDt;
        private BigDecimal isrnPrmm;
        private String rfrLnAprvNo;
        private String rgstrMtdDsc;
        private String rgstrReqNo;
        private String odprtRpyEane;
        private String eltnEstbsLwyrNm;
        private String eltnEstbsLywrBizNo;
        private String eltnRpyLoaAplYn;
        private String eltnRpyLoaSqn;
        private String eltnRpyLoaCtfcNo;
        private BigDecimal whlRpyCnt;
        private BigDecimal whlRpyAmt;
        private BigDecimal ebnkRpyTotAmt;
        private BigDecimal dfbnkRpyTotAmt;
        private String rpyTrgtRnkNo1;
        private String rpyTrgtAcptDt1;
        private String rpyTrgtAcptNo1;
        private BigDecimal rpyTrgtBndAmt1;
        private String rpyTrgtRnkNo2;
        private String rpyTrgtAcptDt2;
        private String rpyTrgtAcptNo2;
        private BigDecimal rpyTrgtBndAmt2;
        private String rpyTrgtRnkNo3;
        private String rpyTrgtAcptDt3;
        private String rpyTrgtAcptNo3;
        private BigDecimal rpyTrgtBndAmt3;
        private String rpyTrgtRnkNo4;
        private String rpyTrgtAcptDt4;
        private String rpyTrgtAcptNo4;
        private BigDecimal rpyTrgtBndAmt4;
        private String rpyTrgtRnkNo5;
        private String rpyTrgtAcptDt5;
        private String rpyTrgtAcptNo5;
        private BigDecimal rpyTrgtBndAmt5;
        private String afrgstrScrtYn;
        private String slmnLndProc;
        private String srMembNo;
        private BigDecimal trAmt;
        private String sllNm1;
        private String sllBrDay1;
        private String sllNm2;
        private String sllBrDay2;
        private BigDecimal ownLoanMaxAmt;
        private BigDecimal ownLoanPlnAmt;
        private String ownLoanBnkNm1;
        private String ownLoanBnkNm2;
        private String ownLoanBnkNm3;
        private String ownLoanBnkNm4;
        private String ownLoanBnkNm5;
        private String cnsgnNm;
        private String trstNm;
        private String bnfrNm;
        private String nowLessNm;
        private String rsrvItmB;
        private LocalDateTime regDtm;
        private String oblMLnAprvNo;
        private Integer oblTotCnt;
        private Integer oblGrpRnkNo;
        private String lnAprvNo2;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Trns6300OutSvo {
        private String loanNo;
        private LocalDateTime chgDtm;
        private BigDecimal tgLen;
        private String tgDsc;
        private BigDecimal bnkTgNo;
        private BigDecimal faTgNo;
        private BigDecimal kosTgSndNo;
        private LocalDateTime tgSndDtm;
        private LocalDateTime tgRcvDtm;
        private String resCd;
        private String rsrvItmH;
        private String bnkTtlReqNo;
        private String lndPrgsStc;
        private String prgsDt;
        private String sbmtDocLst;
        private BigDecimal mvhrHshldrRno;
        private String mvhrTrgtThngAddr;
        private String mvhrHshldrNmMvinDt;
        private String mvhrdtm;
        private String rsrvItmB;
        private LocalDateTime regDtm;
        private String lnAprvNo2;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class TrnsDb6300OutSvo {
        private String loanNo;
        private LocalDateTime chgDtm;
        private BigDecimal tgLen;
        private String tgDsc;
        private String resCd;
        private String lndAgncCd;
        private String bnkTgTrnsDtm;
        private String dbTgTrnsDtm;
        private String bnkTgNo;
        private BigDecimal dbTgNo;
        private String rsrvItmH;
        private String bnkAskNo;
        private String dbMngNo;
        private LocalDateTime kosTgTrnsDtm;
        private String kosTgNo;
        private String nttnYn;
        private String endNotiDt;
        private String endNotiTm;
        private String bnkDrctrNm;
        private String bnkDrctrPhno;
        private String rsrvItmB;
        private LocalDateTime regDtm;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class TrnsLoanExeOutSvo {

        private String loanNo;

        private String trLn;

        private String trCd;

        private String trTpCd;

        private String loNo;

        private String trSq;

        private String reqDttm;

        private String resDttm;

        private String resCd;

        private String approvalNum;

        private String exeDtm;

        private String procDvsn;

        private String exeAmt;

        private String categoryCd;

        private String docTax;

        private String debtDcAmt;

        private String etcAmt;

        private String filler;

    }


    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class TrnsPayRsltOutSvo {
        private String loanNo;
        private String trLn;            // 전문길이
        private String trCd;            // 전문종별코드
        private String trTpCd;          // 거래구분코드
        private String loNo;            // 관리번호
        //        private String trSq;            // 식별번호
//        private String reqDttm;         // 송신일자
//        private String resDttm;         // 수신일자
//        private String resCd;           // 응답코드
//        private String approvalNum;     // 여신승인신청번호
        private String payType;         // 지급구분
        private String payBankCd;       // 지급요청 은행코드
        private String payAmt;          // 지급요청 금액
        private String transResultCd;   // 이체 결과 코드
        private String filler;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class TrnAskDbOutSvo {
        private String loanNo;
        private String newLoanNo;
        private LocalDateTime chgDtm;
        private BigDecimal tgLen;
        private String tgDsc;
        private String resCd;
        private String lndAgncCd;
        private String bnkTgTrnsDtm;
        private String dbTgTrnsDtm;
        private String bnkTgNo;
        private BigDecimal dbTgNo;
        private String rsrvItmH;
        private String bnkAskNo;
        private String dbMngNo;
        private String kosTgTrnsDtm;
        private String kosTgNo;
        private String procDvsnCd;
        private String rthIsrnEntrYn;
        private String rthIsrnEntrCmpy;
        private String rthIsrnScrtNo;
        private String pstNo;
        private String crtdnCd;
        private String trgtAddr;
        private String trgtDtlAddr;
        private String rgstrUnqNo1;
        private String rgstrUnqNo2;
        private String rgstrUnqNo3;
        private String lndKndCd;
        private String fndYn;
        private String prdtNm;
        private String prdtCd;
        private String grntAgncCd;
        private String srvTrgtYn;
        private String stndTrgtYn;
        private String rrcpChrgTrgtYn;
        private String rvsnCntrctChrgTrgtYn;
        private String sscptAskDt;
        private String lndPlnDt;
        private String rntlPrdEndDt;
        private String lndExprdDt;
        private BigDecimal lndPrd;
        private BigDecimal lndAmt;
        private BigDecimal isrnEntrAmt;
        private BigDecimal objtEbnkRgstrRnk;
        private BigDecimal objtEbnkBndMaxAmt;
        private BigDecimal mggFnlOdprtAmt;
        private BigDecimal trolFnlOdprtAmt;
        private String srvcEndDt;
        private String dbtrNm;
        private String dbtrRrno;
        private String dbtrPstNo;
        private String dbtrAddr;
        private String dbtrPhno;
        private String dbtrHpno;
        private String wdngPlnYn;
        private String wdngPlnDt;
        private String hshldrCnddtYn;
        private String unmrdHshldr25agLstnYn;
        private String acptDsc;
        private String lwfmNm;
        private String lwfmBizno;
        private String askBrnchCd;
        private String askBrnchNm;
        private String askBrnchDrctrNm;
        private String askBrnchPhno;
        private String bnkLesDsc;
        private String fndLesDsc;
        private String cndtlCnts;
        private String isrnPrmm;
        private String rsrvItmB;
        private LocalDateTime regDtm;
        private String loanAprvNo2;
    }


    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class TrnsImageSendRsltOutSvo {
        private String loanNo;
        private String trLn;       // 전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정
        private String trCd;       // 전문종별코드
        private String trTpCd;     // 거래구분코드
        private String loNo;       // 관리번호
        //        private String trSq;       // 식별번호
//        private String reqDttm;    // 송신일자
//        private String resDttm;    // 수신일자
//        private String resCd;      // 응답코드
//        private String approvalNum; // 여신승인신청번호
        private String imgTp;      // 이미지구분
        private String imgCheckYn; // 이미지확인여부
        private String imgKey;     // 이미지 키
        private String imgPageCnt; // 이미지 페이지 수
        private String seqNo;      // 시퀀스번호
        private String imgFileName;// 이미지 파일명
        private String resultCd;   // 처리결과
//        private String filler;     // 공란
    }
}
