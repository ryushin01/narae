package com.bankle.app.biz.trn.vo;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class SendLndStatCvo {
    @Getter
    @Setter
    public static class SendLndStatReqCvo {
        private String loanNo;
        private String newLoanNo;
        private LocalDateTime chgDtm;
        private BigDecimal tgLen;
        private String tgDsc;
        private BigDecimal bnkTgNo;
        private BigDecimal faTgNo;
        private BigDecimal kosTgSndNo;
        private LocalDateTime tgSndDtm;
        private LocalDateTime tgRcvDtm;
        private String resCd;
        private String rsrvItmH;
        private String bnkTtlReqNo;
        private String lndPrgsStc;
        private String prgsDt;
        private String sbmtDocLst;
        private BigDecimal mvhrHshldrRno;
        private String mvhrTrgtThngAddr;
        private String mvhrHshldrNmMvinDt;
        private String mvhrdtm;
        private String rsrvItmB;
        private LocalDateTime regDtm;
        private String lnAprvNo2;
    }
}
