package com.bankle.app.biz.trn.ctrl;

import com.bankle.app.biz.cntr.vo.CntrMasterCvo;
import com.bankle.app.biz.trn.svc.SendDbLndStatSvc;
import com.bankle.app.biz.trn.vo.SendDbLndStatCvo;
import com.bankle.app.biz.trn.vo.SendDbLndStatSvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "5.DB 진행 상태 전문(W3000) 발송", description = "DB 진행 상태 전문(W3000) 발송 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class SendDbLndStatCtrl {

    private final CustomeModelMapper customeModelMapper;
    private final SendDbLndStatSvc sendDbLndStatSvc;

    @Operation(summary = "DB 진행 상태 전문(W3000) 발송", description = "DB 진행 상태 전문(W3000) 발송 서비스")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "DB 진행 상태 전문(W3000) 발송 성공", content = @Content(schema = @Schema(implementation = CntrMasterCvo.FndByLoanNoResCvo.class))),
    })
    @PostMapping("/trn/senddblndstat")
    public ResponseEntity<?> save(@RequestBody SendDbLndStatCvo.SendDbLndStatReqCvo reqCvo) throws Exception {
        try {
            boolean valid = sendDbLndStatSvc
                    .save(customeModelMapper
                            .mapping(reqCvo, SendDbLndStatSvo.SendDbLndStatInSvo.class));
            if (valid) {
                return ResData.SUCCESS(reqCvo, "성공");
            } else {
                return ResData.FAIL(reqCvo, "실패");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }
}
