package com.bankle.app.biz.trn.ctrl;


import com.bankle.app.biz.cntr.vo.CntrMasterCvo;
import com.bankle.app.biz.trn.svc.SendFaPreAskSvc;
import com.bankle.app.biz.trn.vo.SendFaPreAskCvo;
import com.bankle.app.biz.trn.vo.SendFaPreAskSvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "1. 원장", description = "원장 관리 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class SendFaPreAskCtrl {

    private final SendFaPreAskSvc sendFaPreAskSvc;

    private final CustomeModelMapper customeModelMapper;

    @Operation(summary = "사전 의뢰 전문 전송(F6500)", description = "사전 의뢰 전문 전송(F6500) 서비스")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "사전 의뢰 전문 전송(F6500) 성공", content = @Content(schema = @Schema(implementation = CntrMasterCvo.FndByLoanNoResCvo.class))),
    })
    @PostMapping("/trn/sendfapreask")
    public ResponseEntity<?> save(@RequestBody SendFaPreAskCvo.SendFaPreAskReqCvo reqCvo) throws Exception {
        try {
            boolean valid = sendFaPreAskSvc
                    .save(customeModelMapper
                            .mapping(reqCvo, SendFaPreAskSvo.SendFaPreAskInSvo.class));
            if (valid) {
                return ResData.SUCCESS(reqCvo, "성공");
            } else {
                return ResData.FAIL(reqCvo, "실패");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }
}

