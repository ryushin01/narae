package com.bankle.app.biz.cntr.dao;

import com.bankle.common.exception.DefaultException;
import com.querydsl.core.types.Projections;
import com.bankle.app.biz.cntr.vo.CntrSvo;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import java.util.List;

import static com.bankle.common.entity.QTbWoCntrMaster.tbWoCntrMaster;

@Slf4j
@Repository
@RequiredArgsConstructor
public class CntrDtlDao {

    private final JPAQueryFactory jpaQueryFactory;

    public static BooleanExpression eqLoanNo(String loanNo) {
        return StringUtils.hasText(loanNo) ? tbWoCntrMaster.loanNo.eq(loanNo) : null;
    }

    public List<CntrSvo.CntrDtlOutSvo> selCntrDetailOutSvo(CntrSvo.CntrDtlInSvo inSvo) {
        try {
            return jpaQueryFactory.select(
                            Projections.bean(CntrSvo.CntrDtlOutSvo.class
                                    ,tbWoCntrMaster.loanNo        // 여신 번호
                                    ,tbWoCntrMaster.bizNo                 // 사업자 번호
                                    ,tbWoCntrMaster.isrnGbCd
                                    ,tbWoCntrMaster.bnkBrnchCd
                                    ,tbWoCntrMaster.bnkGbCd
                                    ,tbWoCntrMaster.bnkBrnchNm
                                    ,tbWoCntrMaster.bnkDrctrNm
                                    ,tbWoCntrMaster.bnkBrnchPhno
                                    ,tbWoCntrMaster.lndKndCd
                                    ,tbWoCntrMaster.statCd
                                    ,tbWoCntrMaster.lndStatCd
                                    ,tbWoCntrMaster.rgstrGbCd
                                    ,tbWoCntrMaster.lndPrdtNm
                                    ,tbWoCntrMaster.dbtrNm
                                    ,tbWoCntrMaster.dbtrBirthDt
                                    ,tbWoCntrMaster.dbtrAddr
                                    ,tbWoCntrMaster.dbtrHpno
                                    ,tbWoCntrMaster.pwpsNm
                                    ,tbWoCntrMaster.pwpsBirthDt
                                    ,tbWoCntrMaster.pwpsHpno
                                    ,tbWoCntrMaster.execPlnAmt
                                    ,tbWoCntrMaster.execPlnDt
                                    ,tbWoCntrMaster.execAmt
                                    ,tbWoCntrMaster.execDt
                                    ,tbWoCntrMaster.slPrc
                                    ,tbWoCntrMaster.isrnEntrAmt
                                    ,tbWoCntrMaster.lwyrDiffBankCd1
                                    ,tbWoCntrMaster.lwyrDiffBankCd2
                                    ,tbWoCntrMaster.lwyrDiffBankCd3
                                    ,tbWoCntrMaster.lwyrDiffBankCd4
                                    ,tbWoCntrMaster.lwyrDiffBankCd5
                                    ,tbWoCntrMaster.lwyrDiffBankCd6
                                    ,tbWoCntrMaster.lwyrDiffBankCd7
                                    ,tbWoCntrMaster.lwyrDiffBankCd8
                                    ,tbWoCntrMaster.lwyrDiffBankCd9
                                    ,tbWoCntrMaster.lwyrDiffBankCd10
                                    ,tbWoCntrMaster.ersuClsMsg
                                    ,tbWoCntrMaster.ebtsLwyrBizno
                                    ,tbWoCntrMaster.regoNm
                                    ,tbWoCntrMaster.rgstrAcptDtm
                                    ,tbWoCntrMaster.imgKey
                                    ,tbWoCntrMaster.kndCd
                                    ,tbWoCntrMaster.lndThngAddr
                                    ,tbWoCntrMaster.ccrstAcptNum
                                    ,tbWoCntrMaster.clsctSctrtBprRegYn
                                    ,tbWoCntrMaster.ccrstBprRegYn
                                    ,tbWoCntrMaster.blncFpymnRcpt
                                    ,tbWoCntrMaster.regifBprRegYn
                                    ,tbWoCntrMaster.elregBizNo
                                    ,tbWoCntrMaster.rdnmInclAddr
                                    ,tbWoCntrMaster.rdnmStndAddr
                                    ,tbWoCntrMaster.grpNo
                                    ,tbWoCntrMaster.rmk
                                    ,tbWoCntrMaster.insDvsn
                                    ,tbWoCntrMaster.trnInCnt
                                    ,tbWoCntrMaster.refndAcctRegYn
                                    ,tbWoCntrMaster.refndAcctRegDate
                                    ,tbWoCntrMaster.eltnSecuredYn
                                    ,tbWoCntrMaster.execAmtChangYn
                                    ,tbWoCntrMaster.estmRegYn
                                    ,tbWoCntrMaster.rgstrRegYn
                                    ,tbWoCntrMaster.payRegYn
                                    ,tbWoCntrMaster.estmCnfmYn
                                    ,tbWoCntrMaster.lndAmtPayYn
                                    ,tbWoCntrMaster.revisionCheckYn
                                    ,tbWoCntrMaster.estbsCntrFnYn
                                    ,tbWoCntrMaster.slCntrctEane
                                    ,tbWoCntrMaster.slCntrctFlnm
                                    ,tbWoCntrMaster.mvhhdSbmtYn
                                    ,tbWoCntrMaster.rrcpSbmtYn
                                    ,tbWoCntrMaster.rtalSbmtYn
                                    ,tbWoCntrMaster.cndtCntrYn
                                    ,tbWoCntrMaster.rgstrAcptSbmtYn
                                    ,tbWoCntrMaster.cnvntLwyrYn
                                    ,tbWoCntrMaster.rschWkDdlnReqDt
                                    ,tbWoCntrMaster.sscptAskDt
                                    ,tbWoCntrMaster.rrcpCnfmReqYn
                                    ,tbWoCntrMaster.mvhhdCnfmReqYn
                                    ,tbWoCntrMaster.rvsnCntrctChrgTrgtYn
                                    ,tbWoCntrMaster.stndAplYn
                                    ,tbWoCntrMaster.befDbsmtCnclCd
                                    ,tbWoCntrMaster.elregYn
                                    ,tbWoCntrMaster.bnkTtlReqNo
                                    ,tbWoCntrMaster.fndUseCd
                                    ,tbWoCntrMaster.offRgstrYn
                                    ,tbWoCntrMaster.a300Send
                                    )
                    )
                    .from(tbWoCntrMaster)
                    .where(tbWoCntrMaster.loanNo.eq(inSvo.getLoanNo()))
                    .fetch();

        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }
}
