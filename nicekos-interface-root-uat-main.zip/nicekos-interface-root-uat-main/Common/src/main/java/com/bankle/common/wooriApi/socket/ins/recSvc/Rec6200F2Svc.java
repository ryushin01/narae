package com.bankle.common.wooriApi.socket.ins.recSvc;

import com.bankle.common.dto.TbWoTrnFa6200F2Dto;
import com.bankle.common.dto.TbWoTrnFa6200F2IdDto;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoTrnFa6200F2Mapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoTrnFa6200F2Repository;
import com.bankle.common.wooriApi.socket.ins.commonSvc.InsCmnSvc;
import com.bankle.common.wooriApi.socket.ins.commonSvc.vo.InsCmnSvo;
import com.bankle.common.wooriApi.socket.ins.recSvc.vo.Rec6200F2Svo;
import com.bankle.common.wooriApi.socket.ins.socketData.T6200F2;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.WooriCmnSvo;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;



@Slf4j
@Component
@RequiredArgsConstructor
public class Rec6200F2Svc {

    private final String BNK_CD = "020";
    private final String TR_DSC = "100";
    private final String REQ_TG_FN_YN = "Y";
    private final String RES_TG_FN_YN = "N";
    private final String COMM_TG_DSC = "F2000";
    private final String TG_DSC = "6210";

    private final InsCmnSvc insCmnSvc;

    private final TbWoTrnFa6200F2Repository tbWoTrnFa6200F2Repository;

    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;

    private final EntityManager entityManager;

    @Transactional
    public void receive(Rec6200F2Svo.recInVo rec6200F2InVo) {

        log.debug("Rec6200F2Svo.rec6200F2InVo > " + rec6200F2InVo);
        log.debug("KOS_TG_SND_NO >>" + rec6200F2InVo.getT6200F2().getKOS_TG_SND_NO());
        T6200F2 t6200F2 = rec6200F2InVo.getT6200F2();
        //------------------------------------------------------------------
        // 보험사 공통전문 수신 => TB_WO_TRN_COMM_MASTER
        //------------------------------------------------------------------
        String seq = t6200F2.getKOS_TG_SND_NO();
        InsCmnSvo.insCmnInVo insCmnInVo = new InsCmnSvo.insCmnInVo();
        insCmnInVo.setTgSqn(seq);
        insCmnInVo.setLoanNo(t6200F2.getLN_APRV_NO());
        insCmnInVo.setTgDsc(COMM_TG_DSC);
        insCmnInVo.setTrDsc(TR_DSC);
        insCmnInVo.setBnkCd(BNK_CD);
        insCmnInVo.setReqDtm(LocalDateTime.now());
        insCmnInVo.setReqTgCnts(t6200F2.dataToString());
        insCmnInVo.setReqTgLog(t6200F2.print());
        insCmnInVo.setReqTgFnYn(REQ_TG_FN_YN);
        insCmnInVo.setResTgFnYn(RES_TG_FN_YN);
        insCmnSvc.insReceive(insCmnInVo);
        entityManager.flush();

        log.debug("보험사 공통전문 수신 => TbWoTrnFa6200F2Dto");
        //if (rec6200F2InVo.getT6200F2().getRES_CD().equals("000")) {
        String loanNo = rec6200F2InVo.getT6200F2().getLN_APRV_NO().substring(0, 11);
        var idBuilder = TbWoTrnFa6200F2IdDto.builder();
        idBuilder.loanNo(loanNo);
        idBuilder.chgDtm(LocalDateTime.now());
        TbWoTrnFa6200F2IdDto idDto = idBuilder.build();
        var mainBuilder = TbWoTrnFa6200F2Dto.builder();
        mainBuilder.tgLen(StringUtils.hasText(t6200F2.getTG_LEN().trim()) ?
                new BigDecimal(t6200F2.getTG_LEN().trim()) : BigDecimal.valueOf(0));
        mainBuilder.tgDsc(t6200F2.getTG_DSC().trim());
        mainBuilder.bnkTgNo(t6200F2.getBNK_TG_NO().trim());
        mainBuilder.faTgNo(t6200F2.getFA_TG_NO().trim());
        mainBuilder.kosTgSndNo(t6200F2.getKOS_TG_SND_NO().trim());
        mainBuilder.tgSndDtm(t6200F2.getTG_SND_DTM().trim());
        mainBuilder.tgRcvDtm(t6200F2.getTG_RCV_DTM().trim());
        mainBuilder.resCd(t6200F2.getRES_CD().trim());
        mainBuilder.rsrvItmH(t6200F2.getRSRV_ITM_H().trim());
        mainBuilder.bnkTtlReqNo(t6200F2.getBNK_TTL_REQ_NO().trim());
        mainBuilder.procDsc(t6200F2.getPROC_DSC().trim());
        mainBuilder.lndKndCd(t6200F2.getLND_KND_CD().trim());
        mainBuilder.fndUseCd(t6200F2.getFND_USE_CD().trim());
        mainBuilder.lndPmntCnfmSlfCd(t6200F2.getLND_PMNT_CNFM_SLF_CD().trim());
        mainBuilder.rcptInfoCnfmSlfCd(t6200F2.getRCPT_INFO_CNFM_SLF_CD().trim());
        mainBuilder.thdyRgstrAcptNoInptYn(t6200F2.getTHDY_RGSTR_ACPT_NO_INPT_YN().trim());
        mainBuilder.estbsRgstrAcptNo1(t6200F2.getESTBS_RGSTR_ACPT_NO_1().trim());
        mainBuilder.estbsRgstrAcptNo2(t6200F2.getESTBS_RGSTR_ACPT_NO_2().trim());
        mainBuilder.estbsRgstrAcptNo3(t6200F2.getESTBS_RGSTR_ACPT_NO_3().trim());
        mainBuilder.ersrAcptNo1(t6200F2.getERSR_ACPT_NO_1().trim());
        mainBuilder.ersrAcptNo2(t6200F2.getERSR_ACPT_NO_2().trim());
        mainBuilder.ersrAcptNo3(t6200F2.getERSR_ACPT_NO_3().trim());
        mainBuilder.rmkB1(t6200F2.getRMK_B1().trim());
        mainBuilder.bnkFxcltEstbsFnYn(t6200F2.getBNK_FXCLT_ESTBS_FN_YN().trim());
        mainBuilder.bnkFxcltRnkMthYn(t6200F2.getBNK_FXCLT_RNK_MTH_YN().trim());
        mainBuilder.bnkFxcltEstbsNoMthYn(t6200F2.getBNK_FXCLT_ESTBS_NO_MTH_YN().trim());
        mainBuilder.rgstAtcpThngAddr(t6200F2.getRGST_ATCP_THNG_ADDR().trim());
        mainBuilder.rgstrUnqNo1(t6200F2.getRGSTR_UNQ_NO_1().trim());
        mainBuilder.rgstrUnqNo2(t6200F2.getRGSTR_UNQ_NO_2().trim());
        mainBuilder.rgstrUnqNo3(t6200F2.getRGSTR_UNQ_NO_3().trim());
        mainBuilder.rgstrUnqNo4(t6200F2.getRGSTR_UNQ_NO_4().trim());
        mainBuilder.rgstrUnqNo5(t6200F2.getRGSTR_UNQ_NO_5().trim());
        mainBuilder.bnkFxcltRgstrAcptDt(t6200F2.getBNK_FXCLT_RGSTR_ACPT_DT().trim());
        mainBuilder.ownOwnshMvRgstrAcptDt(t6200F2.getOWN_OWNSH_MV_RGSTR_ACPT_DT().trim());
        mainBuilder.ownNm1(t6200F2.getOWN_NM_1().trim());
        mainBuilder.ownNm2(t6200F2.getOWN_NM_2().trim());
        mainBuilder.ownNm3(t6200F2.getOWN_NM_3().trim());
        mainBuilder.id(idDto);
        mainBuilder.dbtrRrcpSbmtYn(t6200F2.getDBTR_RRCP_SBMT_YN().trim());
        mainBuilder.dbtrFrcSbmtYn(t6200F2.getDBTR_FRC_SBMT_YN().trim());
        mainBuilder.rrcpDbtrSlfRgstYn(t6200F2.getRRCP_DBTR_SLF_RGST_YN().trim());
        mainBuilder.rrcpSpusRgstYn(t6200F2.getRRCP_SPUS_RGST_YN().trim());
        mainBuilder.frcSpusCnfmYn(t6200F2.getFRC_SPUS_CNFM_YN().trim());
        mainBuilder.dbtrTgrcSbmtYn(t6200F2.getDBTR_TGRC_SBMT_YN().trim());
        mainBuilder.tgrcDbtrSlfMvinYn(t6200F2.getTGRC_DBTR_SLF_MVIN_YN().trim());
        mainBuilder.tgrcDbtrOtsdSprtHshldEane(t6200F2.getTGRC_DBTR_OTSD_SPRT_HSHLD_EANE().trim());
        mainBuilder.exedtMvMvinEane(t6200F2.getEXEDT_MV_MVIN_EANE().trim());
        mainBuilder.bnkDbtrTgrcMthYn(t6200F2.getBNK_DBTR_TGRC_MTH_YN().trim());
        mainBuilder.rschAgncNm(t6200F2.getRSCH_AGNC_NM().trim());
        mainBuilder.srchrNm(t6200F2.getSRCHR_NM().trim());
        mainBuilder.srchrPhno(t6200F2.getSRCHR_PHNO().trim());
        mainBuilder.rschDtm(t6200F2.getRSCH_DTM().trim());
        TbWoTrnFa6200F2Dto mainDto = mainBuilder.build();
        tbWoTrnFa6200F2Repository.save(TbWoTrnFa6200F2Mapper.INSTANCE.toEntity(mainDto));
        entityManager.flush();
        //}
        var cntrEntity = tbWoCntrMasterRepository
                .findByLoanNo(rec6200F2InVo.getLoanNo()).orElseGet(TbWoCntrMaster::new);
        var cntrDto = TbWoCntrMasterMapper.INSTANCE.toDto(cntrEntity);
        log.debug("TbWoCntrMasterDto ->>" + cntrDto.toString());

        String resCd = "999";
        if (StringUtils.hasText(cntrDto.getLoanNo())) {
            resCd = "000";
        }

        log.debug("보험사 공통전문 수신 resCd ->>" + resCd);
        t6200F2.setRES_CD(resCd);
        t6200F2.setTG_DSC(TG_DSC);
        insCmnSvc.insSendResponse(InsCmnSvo.insCmnInVo.builder()
                .tgSqn(rec6200F2InVo.getTgSqn())
                .tgDsc(COMM_TG_DSC)
                .resTgCnts(t6200F2.dataToString())
                .resTgLog(t6200F2.print())
                .resCd(resCd)
                //.resTgFnYn("Y")
                .build());
    }
}
