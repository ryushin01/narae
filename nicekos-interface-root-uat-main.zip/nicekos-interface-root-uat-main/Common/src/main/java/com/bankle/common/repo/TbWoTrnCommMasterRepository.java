package com.bankle.common.repo;

import com.bankle.common.entity.TbWoTrnCommMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbWoTrnCommMasterRepository extends JpaRepository<TbWoTrnCommMaster, String> {

    Optional<TbWoTrnCommMaster> findByTgSqn(String tgSqn);

    List<TbWoTrnCommMaster> findByLnAprvNo(String loanNo);

    boolean existsByLnAprvNo(String loanNo);

}