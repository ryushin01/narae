package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import java.util.Objects;

@Getter
@Setter
@Embeddable
public class TbWoCntrPaymentListId implements java.io.Serializable {
    private static final long serialVersionUID = 6106494638319152867L;
    @Size(max = 11)
    @NotNull
    @Column(name = "LOAN_NO", nullable = false, length = 11)
    private String loanNo;

    @NotNull
    @Column(name = "NO", nullable = false)
    private Integer no;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        TbWoCntrPaymentListId entity = (TbWoCntrPaymentListId) o;
        return Objects.equals(this.no, entity.no) &&
                Objects.equals(this.loanNo, entity.loanNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(no, loanNo);
    }

}