package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_TRN_RSLT")
public class TbWoTrnRslt {
    @EmbeddedId
    private TbWoTrnRsltId id;

    @Size(max = 3)
    @Column(name = "RES_CD", length = 3)
    private String resCd;
}