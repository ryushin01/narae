package com.bankle.common.wooriApi.socket.ins.commonSvc;


import com.bankle.common.dto.TbWoTrnCommMasterDto;
import com.bankle.common.entity.TbWoTrnCommMaster;
import com.bankle.common.enums.Sequence;
import com.bankle.common.mapper.TbWoTrnCommMasterMapper;
import com.bankle.common.repo.TbWoTrnCommMasterRepository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.wooriApi.socket.ins.commonSvc.vo.InsCmnSvo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.swing.text.html.Option;
import java.time.LocalDateTime;
import java.util.Optional;

/**
*
*@Package       : com.withuslaw.common.socket.ins.commonSvc
*@name          : InsCmnSvc.java
*@date          : 2023-10-11 오후 5:34
*@author        : Juheon Kim
*@version       : 1.0.0
**/
@Slf4j
@Service
@RequiredArgsConstructor
public class InsCmnSvc {

    private final TbWoTrnCommMasterRepository tbWoTrnCommMasterRepository;

    private final BizUtil bizUtil;

    private final EntityManager entityManager;

    @org.springframework.transaction.annotation.Transactional(propagation = Propagation.REQUIRES_NEW)
    public String insSend(InsCmnSvo.insCmnInVo insCmnInVo) {
        log.debug("InsCmnSvc.insSend > insCmnInVo : " + insCmnInVo);
        String seq = insCmnInVo.getTgSqn();
         tbWoTrnCommMasterRepository.save(TbWoTrnCommMasterMapper.INSTANCE.toEntity(
                TbWoTrnCommMasterDto.builder()
                        .tgSqn(seq)
                        .bnkCd(insCmnInVo.getBnkCd())
                        .tgDsc(insCmnInVo.getTgDsc())
                        .trDsc(insCmnInVo.getTrDsc())
                        .reqDtm(LocalDateTime.now())
                        .reqTgCnts(insCmnInVo.getReqTgCnts())
                        .reqTgLog(insCmnInVo.getReqTgLog())
                        .reqTgFnYn(insCmnInVo.getReqTgFnYn())
                        .resDtm(insCmnInVo.getResDtm())
                        .resTgCnts(insCmnInVo.getResTgCnts())
                        .resTgLog(insCmnInVo.getResTgLog())
                        .resCd(insCmnInVo.getResCd())
                        .resTgFnYn(insCmnInVo.getResTgFnYn())
                        .lnAprvNo(insCmnInVo.getLoanNo())
                        .crtMembNo("SYSTEM")
                        .crtDtm(LocalDateTime.now())
                        .chgMembNo("SYSTEM")
                        .chgDtm(LocalDateTime.now())
                        .trnsStc("0")
                        .resendCt(0)
                        .build()));
        entityManager.flush();
         return seq;

    }

    @Transactional(rollbackFor = {Exception.class})
    public void insRecResponse(InsCmnSvo.insCmnInVo insCmnInVo) {
        log.debug("InsCmnSvc.insRecResponse > insCmnInVo : " + insCmnInVo);
        Optional<TbWoTrnCommMaster> trnEntity = tbWoTrnCommMasterRepository.findByTgSqn(insCmnInVo.getTgSqn());
        if (trnEntity.isPresent()) {
            TbWoTrnCommMasterDto trnDto = TbWoTrnCommMasterMapper.INSTANCE.toDto(trnEntity.get());
            log.debug("trnDto >> " + trnDto.toString());
            trnDto.setResTgCnts(insCmnInVo.getResTgCnts());
            trnDto.setResTgLog(insCmnInVo.getResTgLog());
            trnDto.setResCd(insCmnInVo.getResCd());
            trnDto.setResTgFnYn(insCmnInVo.getResTgFnYn());
            trnDto.setChgDtm(LocalDateTime.now());
            tbWoTrnCommMasterRepository.save(TbWoTrnCommMasterMapper.INSTANCE.toEntity(trnDto));
        } else {
            log.debug("insRecResponse 대상 없음!");
        }
    }

    @Transactional(rollbackFor = {Exception.class})
    public void insSendResponse(InsCmnSvo.insCmnInVo insCmnInVo) {
        log.debug("InsCmnSvc.insSendResponse > insCmnInVo : " + insCmnInVo);
        Optional<TbWoTrnCommMaster> trnEntity = tbWoTrnCommMasterRepository.findByTgSqn(insCmnInVo.getTgSqn());
        if (trnEntity.isPresent()) {
            TbWoTrnCommMasterDto trnDto = TbWoTrnCommMasterMapper.INSTANCE.toDto(trnEntity.get());
            log.debug("trnDto >> " + trnDto.toString());
            trnDto.setResTgCnts(insCmnInVo.getResTgCnts());
            trnDto.setResTgLog(insCmnInVo.getResTgLog());
            trnDto.setResCd(insCmnInVo.getResCd());
            trnDto.setResTgFnYn(insCmnInVo.getResTgFnYn());
            trnDto.setResTgFnYn("Y");
            trnDto.setChgDtm(LocalDateTime.now());
            trnDto.setTrnsStc("0");
            trnDto.setResendCt(0);
            tbWoTrnCommMasterRepository.save(TbWoTrnCommMasterMapper.INSTANCE.toEntity(trnDto));
            entityManager.flush();
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void insReceive(InsCmnSvo.insCmnInVo insCmnInVo) {
        log.debug("tbWoTrnCommMasterRepository.save START!!!");
        tbWoTrnCommMasterRepository.save(TbWoTrnCommMasterMapper.INSTANCE.toEntity(
                TbWoTrnCommMasterDto.builder()
                        .tgSqn(insCmnInVo.getTgSqn().trim())
                        .bnkCd(insCmnInVo.getBnkCd().trim())
                        .tgDsc(insCmnInVo.getTgDsc().trim())
                        .trDsc(insCmnInVo.getTrDsc().trim())
                        .reqDtm(LocalDateTime.now())
                        .reqTgCnts(insCmnInVo.getReqTgCnts())
                        .reqTgLog(insCmnInVo.getReqTgLog())
                        .reqTgFnYn(insCmnInVo.getReqTgFnYn().trim())
                        //.resDtm(LocalDateTime.now())
                        //.resTgCnts(insCmnInVo.getResTgCnts())
                        //.resTgLog(insCmnInVo.getResTgLog())
                        //.resTgFnYn(insCmnInVo.getResTgFnYn().trim())
                        .lnAprvNo(insCmnInVo.getLoanNo().trim())
                        .crtDtm(LocalDateTime.now())
                        .crtMembNo("SYSTEM")
                        .chgDtm(LocalDateTime.now())
                        .chgMembNo("SYSTEM")
                        .build()
        ));
        entityManager.flush();
        log.debug("tbWoTrnCommMasterRepository.save End!!!");
    }

    @Transactional(rollbackFor = {Exception.class})
    public CheckResponseSvo checkResponse(String seq) throws Exception {
        log.debug("CheckResponseSvo checkResponse(String seq) > " + seq);
        String resCd = null;
        CheckResponseSvo tempMap = new CheckResponseSvo();
        Thread.sleep(1000);
        entityManager.flush();
        if (seq != null) {
            int reTryCnt = 0;
            while (resCd == null) {
                Optional<TbWoTrnCommMaster> trnEntity = tbWoTrnCommMasterRepository.findByTgSqn(seq);
                if (trnEntity.isPresent()) {
                    TbWoTrnCommMasterDto trnDto = TbWoTrnCommMasterMapper.INSTANCE.toDto(trnEntity.get());
                    resCd = trnDto.getResCd();
                    log.debug("CheckResponseSvo checkResponse resCd  > " + resCd);
                    tempMap.setRescode(resCd);
                    if (resCd != null && "".equals(resCd.trim())) {
                        resCd = null;
                    }
                    reTryCnt++;
                    if (reTryCnt == 31) {
                        break;
                    }
                } else {
                    reTryCnt++;
                    if (reTryCnt == 31) {
                        break;
                    }
                }
                entityManager.clear();
                Thread.sleep(2000);
            }

            if (resCd == null || "null".equals(resCd) || "".equals(resCd)) {
                tempMap.setRescode("999");
                //tempMap.setRescode("000");
                Optional<TbWoTrnCommMaster> tbWoTrnCommMaster = tbWoTrnCommMasterRepository.findByTgSqn(seq);
                if (tbWoTrnCommMaster.isPresent()) {
                    TbWoTrnCommMasterDto tbWoTrnCommMasterDto = TbWoTrnCommMasterMapper.INSTANCE.toDto(tbWoTrnCommMaster.get());
                    tbWoTrnCommMasterDto.setResDtm(LocalDateTime.now());
                    tbWoTrnCommMasterDto.setResTgCnts(null);
                    tbWoTrnCommMasterDto.setResTgLog(null);
                    tbWoTrnCommMasterDto.setResCd("999");
                    tbWoTrnCommMasterDto.setChgDtm(LocalDateTime.now());
                    tbWoTrnCommMasterDto.setTrnsStc("9");
                    tbWoTrnCommMasterDto.setResendCt(0);
                    tbWoTrnCommMasterDto.setChgMembNo("SYSTEM");
                    tbWoTrnCommMasterRepository.save(TbWoTrnCommMasterMapper.INSTANCE.toEntity(tbWoTrnCommMasterDto));
                }
            }
        }
        return tempMap;
    }
}
