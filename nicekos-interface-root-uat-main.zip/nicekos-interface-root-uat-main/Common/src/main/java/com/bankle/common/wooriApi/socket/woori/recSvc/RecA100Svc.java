package com.bankle.common.wooriApi.socket.woori.recSvc;


import com.bankle.common.dto.TbWoCntrPaymentListDto;
import com.bankle.common.dto.TbWoCntrPaymentListIdDto;
import com.bankle.common.dto.TbWoTrnRsltDto;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.entity.TbWoTrnRslt;
import com.bankle.common.enums.PayCode;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoCntrPaymentListMapper;
import com.bankle.common.mapper.TbWoTrnRsltMapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoCntrPaymentListRepository;
import com.bankle.common.repo.TbWoTrnRsltRepository;
import com.bankle.common.wooriApi.socket.woori.commonSvc.WooriCmnSvc;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.WooriCmnSvo;
import com.bankle.common.wooriApi.socket.woori.recSvc.vo.RecA100Svo;
import com.bankle.common.wooriApi.socket.woori.socketData.A1X0;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class RecA100Svc {

    private final WooriCmnSvc wooriCmnSvc;

    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;
    private final TbWoCntrPaymentListRepository tbWoCntrPaymentListRepository;
    private final TbWoTrnRsltRepository tbWoTrnRsltRepository;

    private final String TR_CD = "A110";

    @Transactional(rollbackFor = {Exception.class})
    public void receive(RecA100Svo.receiveVo receiveVo) {
        try {
            wooriCmnSvc.wooriReceive(WooriCmnSvo.receiveVo.builder()
                    .trSeq(receiveVo.getTrSeq())
                    .trnKnd(TR_CD)
                    .trnName(receiveVo.getTrnName())
                    .reqData(receiveVo.getReqData())
                    .reqDataLog(receiveVo.getReqDataLog())
                    .approvalNum(receiveVo.getApprovalNum())
                    .membNo(receiveVo.getLoNo())
                    .reptMembNo(receiveVo.getLoNo())
                    .loanNo(receiveVo.getLoanNo())
                    .loNo(receiveVo.getLoNo())
                    .tgDsc(receiveVo.getTgDsc())
                    .build());

            var cntrEntity = tbWoCntrMasterRepository
                    .findByLoanNo(receiveVo.getLoanNo()).orElseGet(TbWoCntrMaster::new);
            var cntrDto = TbWoCntrMasterMapper.INSTANCE.toDto(cntrEntity);
            log.debug("TbWoCntrMasterDto ->>" + cntrDto.toString());

            String resCd = "999";
            log.debug("===============================================================");
            log.debug("FIND RESCD !!!");
            log.debug("===============================================================");
            log.debug("receiveVo.getLoanNo() : {}", receiveVo.getLoanNo());
            log.debug("receiveVo.getTrnKnd() : {}", receiveVo.getTrnKnd());
            Optional<TbWoTrnRslt> fndResCd = tbWoTrnRsltRepository.findByIdLoanNoAndIdTgDsc(receiveVo.getLoanNo(), receiveVo.getTrnKnd());
            if (fndResCd.isPresent()) {
                TbWoTrnRsltDto rsltDto = TbWoTrnRsltMapper.INSTANCE.toDto(fndResCd.get());
                resCd = rsltDto.getResCd();
            } else {
                resCd = "000";
            }

            A1X0 data = receiveVo.getA1X0();
            data.setTR_CD(TR_CD);
            data.setRES_CD(resCd);

            log.debug("resCd : {}", resCd);
            log.debug("A1X0 Data Pring===>{}", data.print());

            List<TbWoCntrPaymentListDto> payListDto = new ArrayList<TbWoCntrPaymentListDto>();

            log.debug("BUYER AMT => {}", data.getBOW_PAY_RQ_AMT().trim());
            //paymentlist 테이블에 적재
            var payMainBuilder01 = TbWoCntrPaymentListDto.builder();
            var payIdBuilder01 = TbWoCntrPaymentListIdDto.builder().build().builder();
            payIdBuilder01.loanNo(receiveVo.getLoanNo());
            payIdBuilder01.no(1);
            payMainBuilder01.id(payIdBuilder01.build());
            TbWoCntrPaymentListIdDto payIdDto01 = payIdBuilder01.build();
            payMainBuilder01.payCd(PayCode.BUYER.value());
            payMainBuilder01.bankCd("000");
            payMainBuilder01.payAmt(
                    BigDecimal.ZERO.compareTo(new BigDecimal(data.getBOW_PAY_RQ_AMT().trim())) == 0
                            ? BigDecimal.ZERO
                            : new BigDecimal(data.getBOW_PAY_RQ_AMT().trim()));
            if(BigDecimal.ZERO.compareTo(new BigDecimal(data.getBOW_PAY_RQ_AMT().trim())) == 0) {
                payMainBuilder01.statCd("02");
            } else {
                payMainBuilder01.statCd("01");
            }
            payMainBuilder01.delYn("N");
            payMainBuilder01.gpsInfo(" ");
            payMainBuilder01.crtDtm(LocalDateTime.now());
            payMainBuilder01.crtMembNo("SYSTEM");
            payMainBuilder01.chgDtm(LocalDateTime.now());
            payMainBuilder01.chgMembNo("SYSTEM");
            payMainBuilder01.id(payIdDto01);
            TbWoCntrPaymentListDto payMainDto01 = payMainBuilder01.build();

            payListDto.add(payMainDto01);
            log.debug("payMainBuilder01!!");

            /*========================================================================================================*/
            //no.2
            log.debug("BUYER AMT => {}", data.getSELL_PAY_RQ_AMT().trim());
            var payMainBuilder02 = TbWoCntrPaymentListDto.builder();
            var payIdBuilder02 = TbWoCntrPaymentListIdDto.builder().build().builder();
            payIdBuilder02.loanNo(receiveVo.getLoanNo());
            payIdBuilder02.no(2);
            payMainBuilder02.id(payIdBuilder02.build());
            TbWoCntrPaymentListIdDto payIdDto02 = payIdBuilder02.build();
            payMainBuilder02.payCd(PayCode.SELLER.value());
            payMainBuilder02.bankCd("000");
            payMainBuilder02.payAmt(
                    BigDecimal.ZERO.compareTo(new BigDecimal(data.getSELL_PAY_RQ_AMT().trim())) == 0
                            ? BigDecimal.ZERO
                            : new BigDecimal(data.getSELL_PAY_RQ_AMT().trim())
            );
            if(BigDecimal.ZERO.compareTo(new BigDecimal(data.getSELL_PAY_RQ_AMT().trim())) == 0) {
                payMainBuilder02.statCd("02");
            } else {
                payMainBuilder02.statCd("01");
            }
            payMainBuilder02.delYn("N");
            payMainBuilder02.gpsInfo(" ");
            payMainBuilder02.crtDtm(LocalDateTime.now());
            payMainBuilder02.crtMembNo("SYSTEM");
            payMainBuilder02.chgDtm(LocalDateTime.now());
            payMainBuilder02.chgMembNo("SYSTEM");
            payMainBuilder02.id(payIdDto02);
            TbWoCntrPaymentListDto payMainDto02 = payMainBuilder02.build();

            payListDto.add(payMainDto02);
            log.debug("payMainBuilder02!!");
            /*========================================================================================================*/
            //no.3
            var payMainBuilder03 = TbWoCntrPaymentListDto.builder();
            var payIdBuilder03 = TbWoCntrPaymentListIdDto.builder().build().builder();
            payIdBuilder03.loanNo(receiveVo.getLoanNo());
            payIdBuilder03.no(3);
            payMainBuilder03.id(payIdBuilder03.build());
            TbWoCntrPaymentListIdDto payIdDto03 = payIdBuilder03.build();
            payMainBuilder03.payCd(PayCode.WOORI.value());
            payMainBuilder03.bankCd("020");
            payMainBuilder03.payAmt(new BigDecimal(data.getMY_BK_TOT_AMT().trim()));
            if(BigDecimal.ZERO.compareTo(new BigDecimal(data.getMY_BK_TOT_AMT().trim())) == 0) {
                payMainBuilder03.statCd("02");
            } else {
                payMainBuilder03.statCd("01");
            }
            payMainBuilder03.delYn("N");
            payMainBuilder03.gpsInfo(" ");
            payMainBuilder03.crtDtm(LocalDateTime.now());
            payMainBuilder03.crtMembNo("SYSTEM");
            payMainBuilder03.chgDtm(LocalDateTime.now());
            payMainBuilder03.chgMembNo("SYSTEM");
            payMainBuilder03.id(payIdDto03);
            TbWoCntrPaymentListDto payMainDto03 = payMainBuilder03.build();

            payListDto.add(payMainDto03);

            log.debug("payMainBuilder03!!");

            //no.4
            if (StringUtils.hasText(data.getOT_BK_1_CD().trim())) {
                TbWoCntrPaymentListDto pay04 = TbWoCntrPaymentListDto.builder()
                        .payCd(PayCode.OTHER.value())
                        .bankCd(data.getOT_BK_1_CD().trim())
                        .payAmt(new BigDecimal(data.getOT_BK_1_AMT().trim()))
                        .statCd(BigDecimal.ZERO.compareTo(new BigDecimal(data.getOT_BK_1_AMT().trim())) == 0 ? "02" : "01")
                        .delYn("N")
                        .crtDtm(LocalDateTime.now())
                        .crtMembNo("SYSTEM")
                        .chgDtm(LocalDateTime.now())
                        .chgMembNo("SYSTEM")
                        .id(TbWoCntrPaymentListIdDto.builder()
                                .loanNo(receiveVo.getLoanNo())
                                .no(4)
                                .build())
                        .build();

                payListDto.add(pay04);

                log.debug("payMainBuilder04!!");
            }

            //no.5
            if (StringUtils.hasText(data.getOT_BK_2_CD().trim())) {
                TbWoCntrPaymentListDto pay05 = TbWoCntrPaymentListDto.builder()
                        .payCd(PayCode.OTHER.value())
                        .bankCd(data.getOT_BK_2_CD().trim())
                        .payAmt(new BigDecimal(data.getOT_BK_2_AMT().trim()))
                        .statCd(BigDecimal.ZERO.compareTo(new BigDecimal(data.getOT_BK_2_AMT().trim())) == 0 ? "02" : "01")
                        .delYn("N")
                        .crtDtm(LocalDateTime.now())
                        .crtMembNo("SYSTEM")
                        .chgDtm(LocalDateTime.now())
                        .chgMembNo("SYSTEM")
                        .id(TbWoCntrPaymentListIdDto.builder()
                                .loanNo(receiveVo.getLoanNo())
                                .no(5)
                                .build())
                        .build();

                payListDto.add(pay05);

                log.debug("payMainBuilder05!!");
            }

            //no.6
            if (StringUtils.hasText(data.getOT_BK_3_CD().trim())) {
                TbWoCntrPaymentListDto pay06 = TbWoCntrPaymentListDto.builder()
                        .payCd(PayCode.OTHER.value())
                        .bankCd(data.getOT_BK_3_CD().trim())
                        .payAmt(new BigDecimal(data.getOT_BK_3_AMT().trim()))
                        .statCd(BigDecimal.ZERO.compareTo(new BigDecimal(data.getOT_BK_3_AMT().trim())) == 0 ? "02" : "01")
                        .delYn("N")
                        .crtDtm(LocalDateTime.now())
                        .crtMembNo("SYSTEM")
                        .chgDtm(LocalDateTime.now())
                        .chgMembNo("SYSTEM")
                        .id(TbWoCntrPaymentListIdDto.builder()
                                .loanNo(receiveVo.getLoanNo())
                                .no(6)
                                .build())
                        .build();

                payListDto.add(pay06);

                log.debug("payMainBuilder06!!");
            }

            //no.7
            if (StringUtils.hasText(data.getOT_BK_4_CD().trim())) {
                TbWoCntrPaymentListDto pay07 = TbWoCntrPaymentListDto.builder()
                        .payCd(PayCode.OTHER.value())
                        .bankCd(data.getOT_BK_4_CD().trim())
                        .payAmt(new BigDecimal(data.getOT_BK_4_AMT().trim()))
                        .statCd(BigDecimal.ZERO.compareTo(new BigDecimal(data.getOT_BK_4_AMT().trim())) == 0 ? "02" : "01")
                        .delYn("N")
                        .crtDtm(LocalDateTime.now())
                        .crtMembNo("SYSTEM")
                        .chgDtm(LocalDateTime.now())
                        .chgMembNo("SYSTEM")
                        .id(TbWoCntrPaymentListIdDto.builder()
                                .loanNo(receiveVo.getLoanNo())
                                .no(7)
                                .build())
                        .build();

                payListDto.add(pay07);

                log.debug("payMainBuilder07!!");
            }


            tbWoCntrPaymentListRepository.saveAll(
                    payListDto.stream().map(TbWoCntrPaymentListMapper.INSTANCE::toEntity).toList()
            );
            tbWoCntrPaymentListRepository.flush();

            log.debug("resCd ->>" + resCd);
            log.debug("A1X0 data ->>" + data);
            if (!StringUtils.hasText(data.getLO_NO().trim())) {
                data.setLO_NO("0000000000000");
            }
            wooriCmnSvc.wooriSendResponse(WooriCmnSvo.sendVo.builder()
                    .seq(receiveVo.getTrSeq())
                    //.trTp(receiveVo.getTpCd())
                    .resData(data.dataToString())
                    .resDataLog(data.print())
                    .resCode(resCd)
                    .build());
        } catch (Exception e) {
            e.printStackTrace();
            log.debug("============Exception 발생============");
            log.debug("Exception:::::,{}", e.getMessage());
            log.debug("============Exception 발생============");
        }
    }
}
