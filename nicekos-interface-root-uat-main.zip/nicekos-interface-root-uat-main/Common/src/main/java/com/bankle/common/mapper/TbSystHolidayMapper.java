package com.bankle.common.mapper;

import com.bankle.common.entity.TbSystHoliday;
import com.bankle.common.dto.TbSystHolidayDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbSystHolidayMapper extends DefaultMapper<TbSystHolidayDto, TbSystHoliday> {
    TbSystHolidayMapper INSTANCE = Mappers.getMapper(TbSystHolidayMapper.class);
}