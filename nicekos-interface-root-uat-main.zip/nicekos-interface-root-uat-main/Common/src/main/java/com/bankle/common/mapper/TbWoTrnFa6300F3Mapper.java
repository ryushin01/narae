package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoTrnFa6300F3Dto;
import com.bankle.common.entity.TbWoTrnFa6300F3;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoTrnFa6300F3Mapper extends DefaultMapper<TbWoTrnFa6300F3Dto, TbWoTrnFa6300F3> {
    TbWoTrnFa6300F3Mapper INSTANCE = Mappers.getMapper(TbWoTrnFa6300F3Mapper.class);
}