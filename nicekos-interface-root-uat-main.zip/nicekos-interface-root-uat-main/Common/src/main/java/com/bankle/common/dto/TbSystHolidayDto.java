package com.bankle.common.dto;

import com.bankle.common.entity.TbSystHoliday;
import jakarta.validation.constraints.Size;
import lombok.Value;

import java.io.Serializable;

/**
 * DTO for {@link TbSystHoliday}
 */
@Value
public class TbSystHolidayDto implements Serializable {
    String dtm;
    @Size(max = 1)
    String holYn;
}