package com.bankle.common.enums;

import lombok.*;

import java.util.Arrays;

/**
 *  ASIS DVI_CODE 대체 사용 - 01 : 차주 , 02: 매도인, 03 : 당행 , 04: 타행
 * @Package     : com.withuslaw.common.enums
 * @name        : PayCode.java
 * @date        : 10/26/23 10:21 AM
 * @author      : tigerBK
 * @version     : 1.0.0
**/
@Getter
public enum PayCode {
	BUYER("01"),
	SELLER("02"),
	WOORI("03"),
	OTHER("04");
	
	private String payCd;
	
	PayCode(String payCd) {
		this.payCd = payCd;
	}
	
	public String value() {
		return payCd;
	}
	
	public static PayCode findByCode(String code) {
		return Arrays.stream(PayCode.values())
			.filter(payCd -> payCd.getPayCd().equals(code.toUpperCase()))
			.findFirst()
			.orElse(OTHER);
	}
}
